// t10I13__spl_versions16__spl_exportTypes11__spl_topicls17__spl_topicLevelsI21__spl_topicLevelCounts17__spl_allowFilterI13__spl_channelI17__spl_maxChannelsI14__spl_randomIds11__spl_class


#include "BeJxdjkEKAjEMRa9kVPQAA0LApfsSOgELmaQ0cZy5vYtiEZfv8eD_1gAPCKSWvklZuXkwdLp15q9bisVd2gK7CasnicP3BO68sjkf4d5O9NEZLIva_0FQluYzE_1SZUFv81C29SVI5y7a6SzLTiPD1nI_1QNUwUZA.h"
#include <sstream>

#define SELF BeJxdjkEKAjEMRa9kVPQAA0LApfsSOgELmaQ0cZy5vYtiEZfv8eD_1gAPCKSWvklZuXkwdLp15q9bisVd2gK7CasnicP3BO68sjkf4d5O9NEZLIva_0FQluYzE_1SZUFv81C29SVI5y7a6SzLTiPD1nI_1QNUwUZA

using namespace SPL;

TupleMappings* SELF::mappings_ = SELF::initMappings();

static void addMapping(TupleMappings & tm, TypeOffset & offset,
                       std::string const & name, uint32_t index)
{
    tm.nameToIndex_.insert(std::make_pair(name, index)); 
    tm.indexToName_.push_back(name);
    tm.indexToTypeOffset_.push_back(offset);    
}

static Tuple * initer() { return new SELF(); }

TupleMappings* SELF::initMappings()
{
    instantiators_.insert(std::make_pair("tuple<int64 __spl_version,rstring __spl_exportType,rstring __spl_topic,list<rstring> __spl_topicLevels,int64 __spl_topicLevelCount,rstring __spl_allowFilter,int64 __spl_channel,int64 __spl_maxChannels,int64 __spl_randomId,rstring __spl_class>",&initer));
    TupleMappings * tm = new TupleMappings();
#define MY_OFFSETOF(member, base) \
    ((uintptr_t)&reinterpret_cast<Self*>(base)->member) - (uintptr_t)base
   
    // initialize the mappings 
    
    {
        std::string s("__spl_version");
        TypeOffset t(MY_OFFSETOF(__spl_version_, tm), 
                     Meta::Type::typeOf<SPL::int64 >(), 
                     &typeid(SPL::int64));
        addMapping(*tm, t, s, 0);
    }
    
    {
        std::string s("__spl_exportType");
        TypeOffset t(MY_OFFSETOF(__spl_exportType_, tm), 
                     Meta::Type::typeOf<SPL::rstring >(), 
                     &typeid(SPL::rstring));
        addMapping(*tm, t, s, 1);
    }
    
    {
        std::string s("__spl_topic");
        TypeOffset t(MY_OFFSETOF(__spl_topic_, tm), 
                     Meta::Type::typeOf<SPL::rstring >(), 
                     &typeid(SPL::rstring));
        addMapping(*tm, t, s, 2);
    }
    
    {
        std::string s("__spl_topicLevels");
        TypeOffset t(MY_OFFSETOF(__spl_topicLevels_, tm), 
                     Meta::Type::typeOf<SPL::list<SPL::rstring > >(), 
                     &typeid(SPL::list<SPL::rstring >));
        addMapping(*tm, t, s, 3);
    }
    
    {
        std::string s("__spl_topicLevelCount");
        TypeOffset t(MY_OFFSETOF(__spl_topicLevelCount_, tm), 
                     Meta::Type::typeOf<SPL::int64 >(), 
                     &typeid(SPL::int64));
        addMapping(*tm, t, s, 4);
    }
    
    {
        std::string s("__spl_allowFilter");
        TypeOffset t(MY_OFFSETOF(__spl_allowFilter_, tm), 
                     Meta::Type::typeOf<SPL::rstring >(), 
                     &typeid(SPL::rstring));
        addMapping(*tm, t, s, 5);
    }
    
    {
        std::string s("__spl_channel");
        TypeOffset t(MY_OFFSETOF(__spl_channel_, tm), 
                     Meta::Type::typeOf<SPL::int64 >(), 
                     &typeid(SPL::int64));
        addMapping(*tm, t, s, 6);
    }
    
    {
        std::string s("__spl_maxChannels");
        TypeOffset t(MY_OFFSETOF(__spl_maxChannels_, tm), 
                     Meta::Type::typeOf<SPL::int64 >(), 
                     &typeid(SPL::int64));
        addMapping(*tm, t, s, 7);
    }
    
    {
        std::string s("__spl_randomId");
        TypeOffset t(MY_OFFSETOF(__spl_randomId_, tm), 
                     Meta::Type::typeOf<SPL::int64 >(), 
                     &typeid(SPL::int64));
        addMapping(*tm, t, s, 8);
    }
    
    {
        std::string s("__spl_class");
        TypeOffset t(MY_OFFSETOF(__spl_class_, tm), 
                     Meta::Type::typeOf<SPL::rstring >(), 
                     &typeid(SPL::rstring));
        addMapping(*tm, t, s, 9);
    }
    
    return tm;
}

void SELF::deserialize(std::istream & istr, bool withSuffix)
{
   std::string s;
   char c;

   istr >> c; if (!istr) { return; }
   if (c != '{') { istr.setstate(std::ios_base::failbit); return; }
   
   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "__spl_version") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, __spl_version_);
   else
     istr >> __spl_version_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "__spl_exportType") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, __spl_exportType_);
   else
     istr >> __spl_exportType_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "__spl_topic") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, __spl_topic_);
   else
     istr >> __spl_topic_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "__spl_topicLevels") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, __spl_topicLevels_);
   else
     istr >> __spl_topicLevels_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "__spl_topicLevelCount") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, __spl_topicLevelCount_);
   else
     istr >> __spl_topicLevelCount_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "__spl_allowFilter") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, __spl_allowFilter_);
   else
     istr >> __spl_allowFilter_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "__spl_channel") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, __spl_channel_);
   else
     istr >> __spl_channel_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "__spl_maxChannels") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, __spl_maxChannels_);
   else
     istr >> __spl_maxChannels_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "__spl_randomId") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, __spl_randomId_);
   else
     istr >> __spl_randomId_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "__spl_class") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, __spl_class_);
   else
     istr >> __spl_class_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   
   if (c != '}') { istr.setstate(std::ios_base::failbit); return; }
}

void SELF::deserializeWithNanAndInfs(std::istream & istr, bool withSuffix)
{
   std::string s;
   char c;

   istr >> c; if (!istr) { return; }
   if (c != '{') { istr.setstate(std::ios_base::failbit); return; }
   
   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "__spl_version") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, __spl_version_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "__spl_exportType") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, __spl_exportType_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "__spl_topic") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, __spl_topic_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "__spl_topicLevels") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, __spl_topicLevels_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "__spl_topicLevelCount") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, __spl_topicLevelCount_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "__spl_allowFilter") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, __spl_allowFilter_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "__spl_channel") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, __spl_channel_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "__spl_maxChannels") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, __spl_maxChannels_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "__spl_randomId") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, __spl_randomId_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "__spl_class") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, __spl_class_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   
   if (c != '}') { istr.setstate(std::ios_base::failbit); return; }
}

void SELF::serialize(std::ostream & ostr) const
{
    ostr << '{'
         << "__spl_version=" << get___spl_version()  << ","
         << "__spl_exportType=" << get___spl_exportType()  << ","
         << "__spl_topic=" << get___spl_topic()  << ","
         << "__spl_topicLevels=" << get___spl_topicLevels()  << ","
         << "__spl_topicLevelCount=" << get___spl_topicLevelCount()  << ","
         << "__spl_allowFilter=" << get___spl_allowFilter()  << ","
         << "__spl_channel=" << get___spl_channel()  << ","
         << "__spl_maxChannels=" << get___spl_maxChannels()  << ","
         << "__spl_randomId=" << get___spl_randomId()  << ","
         << "__spl_class=" << get___spl_class()  
         << '}';
}

void SELF::serializeWithPrecision(std::ostream & ostr) const
{
    ostr << '{';
    SPL::serializeWithPrecision(ostr << "__spl_version=", get___spl_version()) << ",";
    SPL::serializeWithPrecision(ostr << "__spl_exportType=", get___spl_exportType()) << ",";
    SPL::serializeWithPrecision(ostr << "__spl_topic=", get___spl_topic()) << ",";
    SPL::serializeWithPrecision(ostr << "__spl_topicLevels=", get___spl_topicLevels()) << ",";
    SPL::serializeWithPrecision(ostr << "__spl_topicLevelCount=", get___spl_topicLevelCount()) << ",";
    SPL::serializeWithPrecision(ostr << "__spl_allowFilter=", get___spl_allowFilter()) << ",";
    SPL::serializeWithPrecision(ostr << "__spl_channel=", get___spl_channel()) << ",";
    SPL::serializeWithPrecision(ostr << "__spl_maxChannels=", get___spl_maxChannels()) << ",";
    SPL::serializeWithPrecision(ostr << "__spl_randomId=", get___spl_randomId()) << ",";
    SPL::serializeWithPrecision(ostr << "__spl_class=", get___spl_class()) ;
    ostr << '}';
}

SELF& SELF::clear()
{
    get___spl_version() = 0;
    SPL::rstring().swap(get___spl_exportType());
    SPL::rstring().swap(get___spl_topic());
    if (get___spl_topicLevels().size() < 1024) {
        get___spl_topicLevels().clear();
    }
    else {
        SPL::list<SPL::rstring >().swap(get___spl_topicLevels());
    }
    get___spl_topicLevelCount() = 0;
    SPL::rstring().swap(get___spl_allowFilter());
    get___spl_channel() = 0;
    get___spl_maxChannels() = 0;
    get___spl_randomId() = 0;
    SPL::rstring().swap(get___spl_class());

    return *this;
}

void SELF::normalizeBoundedSetsAndMaps()
{
    SPL::normalizeBoundedSetsAndMaps(*this);
}


