#include "SPL/Runtime/Function/SPLFunctions.h"
#include "./setTopicNameProperties.h"
#include "../../../../../../type/BeJxdjkEKAjEMRa9kVPQAA0LApfsSOgELmaQ0cZy5vYtiEZfv8eD_1gAPCKSWvklZuXkwdLp15q9bisVd2gK7CasnicP3BO68sjkf4d5O9NEZLIva_0FQluYzE_1SZUFv81C29SVI5y7a6SzLTiPD1nI_1QNUwUZA.h"
#include "../../../../../../type/BeJyrNI03TS0qyi8yKU8syjPJzEvLN01JTSpNNy0pSkxOBQC5eQu5.h"
#include "../../../../../../type/BeJyrNI43TS0qyi8yKU8syjPJzEvLBwBGbAc3.h"
#include "../../../../../../function/com/ibm/streamsx/topology/topic/checkTopicName.h"
namespace com { namespace ibm { namespace streamsx { namespace topology { namespace topic { 
/* stateful */ SPL::int32 setTopicNameProperties (const SPL::rstring& exportType, const SPL::rstring& topicName, const SPL::boolean& allowFilter, const SPL::rstring& id$class)
{
    ::SPL::Functions::Utility::appTrc(SPL::BeJyrNI03TS0qyi8yKU8syjPJzEvLN01JTSpNNy0pSkxOBQC5eQu5::debug, (SPL::rstring("Setting Topic name:") + topicName), SPL::rstring("/opt/ibm/InfoSphere_Streams/4.2.0.0/toolkits/com.ibm.streamsx.topology/com.ibm.streamsx.topology.topic/topics.spl"), SPL::uint32(66U));
    if (SPL::boolean(!::com::ibm::streamsx::topology::topic::checkTopicName(topicName))) 
        {
            ::SPL::Functions::Utility::appLog(SPL::BeJyrNI43TS0qyi8yKU8syjPJzEvLBwBGbAc3::error, (SPL::rstring("Topic name is invalid:") + topicName), SPL::rstring("/opt/ibm/InfoSphere_Streams/4.2.0.0/toolkits/com.ibm.streamsx.topology/com.ibm.streamsx.topology.topic/topics.spl"), SPL::uint32(68U));
            ::SPL::Functions::Utility::appTrc(SPL::BeJyrNI03TS0qyi8yKU8syjPJzEvLN01JTSpNNy0pSkxOBQC5eQu5::error, (SPL::rstring("Topic name is invalid:") + topicName), SPL::rstring("/opt/ibm/InfoSphere_Streams/4.2.0.0/toolkits/com.ibm.streamsx.topology/com.ibm.streamsx.topology.topic/topics.spl"), SPL::uint32(69U));
            ::SPL::Functions::Utility::Assert((SPL::boolean)true, (SPL::rstring("Topic name is invalid:") + topicName), SPL::rstring("/opt/ibm/InfoSphere_Streams/4.2.0.0/toolkits/com.ibm.streamsx.topology/com.ibm.streamsx.topology.topic/topics.spl"), SPL::uint32(70U));
            ::SPL::Functions::Utility::abort(SPL::rstring("/opt/ibm/InfoSphere_Streams/4.2.0.0/toolkits/com.ibm.streamsx.topology/com.ibm.streamsx.topology.topic/topics.spl"), SPL::uint32(71U));
            return SPL::int32(-1);
        }
    const SPL::list<SPL::rstring > id$levels = ::SPL::Functions::String::tokenize(topicName, SPL::rstring("/"), (SPL::boolean)true);
    const SPL::int32 id$rc = ::SPL::Functions::Utility::setOutputPortExportProperties(SPL::BeJxdjkEKAjEMRa9kVPQAA0LApfsSOgELmaQ0cZy5vYtiEZfv8eD_1gAPCKSWvklZuXkwdLp15q9bisVd2gK7CasnicP3BO68sjkf4d5O9NEZLIva_0FQluYzE_1SZUFv81C29SVI5y7a6SzLTiPD1nI_1QNUwUZA(SPL::int64(3LL), exportType, topicName, id$levels, ::SPL::spl_cast<SPL::int64, SPL::int32 >::cast(::SPL::Functions::Collections::size(id$levels)), (allowFilter ? SPL::rstring("true") : SPL::rstring("false")), ::SPL::spl_cast<SPL::int64, SPL::int32 >::cast(::SPL::Functions::Utility::getChannel()), ::SPL::spl_cast<SPL::int64, SPL::int32 >::cast(::SPL::Functions::Utility::getMaxChannels()), ::SPL::spl_cast<SPL::int64, SPL::float64 >::cast((::SPL::Functions::Math::random() * SPL::float64(2147483647.0))), id$class), SPL::uint32(0U));
    ::SPL::Functions::Utility::appTrc(SPL::BeJyrNI03TS0qyi8yKU8syjPJzEvLN01JTSpNNy0pSkxOBQC5eQu5::debug, (((SPL::rstring("Set Topic name:") + topicName) + SPL::rstring(" = ")) + ::SPL::spl_cast<SPL::rstring, SPL::int32 >::cast(id$rc)), SPL::rstring("/opt/ibm/InfoSphere_Streams/4.2.0.0/toolkits/com.ibm.streamsx.topology/com.ibm.streamsx.topology.topic/topics.spl"), SPL::uint32(90U));
    if ((id$rc != SPL::int32(0))) 
        {
            ::SPL::Functions::Utility::appLog(SPL::BeJyrNI43TS0qyi8yKU8syjPJzEvLBwBGbAc3::error, (((SPL::rstring("Setting topic name failed:") + topicName) + SPL::rstring(" rc=")) + ::SPL::spl_cast<SPL::rstring, SPL::int32 >::cast(id$rc)), SPL::rstring("/opt/ibm/InfoSphere_Streams/4.2.0.0/toolkits/com.ibm.streamsx.topology/com.ibm.streamsx.topology.topic/topics.spl"), SPL::uint32(92U));
            ::SPL::Functions::Utility::Assert((SPL::boolean)true, (((SPL::rstring("Setting topic name failed:") + topicName) + SPL::rstring(" rc=")) + ::SPL::spl_cast<SPL::rstring, SPL::int32 >::cast(id$rc)), SPL::rstring("/opt/ibm/InfoSphere_Streams/4.2.0.0/toolkits/com.ibm.streamsx.topology/com.ibm.streamsx.topology.topic/topics.spl"), SPL::uint32(93U));
            ::SPL::Functions::Utility::abort(SPL::rstring("/opt/ibm/InfoSphere_Streams/4.2.0.0/toolkits/com.ibm.streamsx.topology/com.ibm.streamsx.topology.topic/topics.spl"), SPL::uint32(94U));
        }
    return id$rc;
}
} } } } } 
