#include "SPL/Runtime/Function/SPLFunctions.h"
#include "./populate.h"
#include <SPL_JNIFunctions_com_ibm_streamsx_health_ingest_types_resolver.h>
namespace com { namespace ibm { namespace streamsx { namespace health { namespace analyze { namespace vital { 
SPL::BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ populate (SPL::BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ& patient, const SPL::BeJwtjFsOgzAMBK_1UPID2ApXyTS8QxRaKBDFiHSRuD4X8zs6serWwmWBes6SoWUqgnnjPifFZL8BFA6lrEqRuiX_1Hyng_1ViDjNo6UyzTeo_1pgFddtjwPKC3wSYmOa9G_0_13R7nynBVlqHxE_1atDPk& obs)
{
    if (::SPL::JNIFunctions::com::ibm::streamsx::health::ingest::types::resolver::SPL_JNIFunctions::isHeartRate(obs.get_reading().get_readingType().get_code())) 
        {
            patient.get_heartRate() = ::SPL::spl_cast<SPL::float32, SPL::float64 >::cast(obs.get_reading().get_value());
        }
    if (::SPL::JNIFunctions::com::ibm::streamsx::health::ingest::types::resolver::SPL_JNIFunctions::isBPSystolic(obs.get_reading().get_readingType().get_code())) 
        {
            patient.get_bpSystolic() = ::SPL::spl_cast<SPL::int32, SPL::float64 >::cast(obs.get_reading().get_value());
        }
    if (::SPL::JNIFunctions::com::ibm::streamsx::health::ingest::types::resolver::SPL_JNIFunctions::isBPDiastolic(obs.get_reading().get_readingType().get_code())) 
        {
            patient.get_bpDiastolic() = ::SPL::spl_cast<SPL::int32, SPL::float64 >::cast(obs.get_reading().get_value());
        }
    if (::SPL::JNIFunctions::com::ibm::streamsx::health::ingest::types::resolver::SPL_JNIFunctions::isTemperature(obs.get_reading().get_readingType().get_code())) 
        {
            patient.get_temperature() = ::SPL::spl_cast<SPL::float32, SPL::float64 >::cast(obs.get_reading().get_value());
        }
    if (::SPL::JNIFunctions::com::ibm::streamsx::health::ingest::types::resolver::SPL_JNIFunctions::isSpO2(obs.get_reading().get_readingType().get_code())) 
        {
            patient.get_spO2() = ::SPL::spl_cast<SPL::int32, SPL::float64 >::cast(obs.get_reading().get_value());
        }
    return patient;
}
} } } } } } 
