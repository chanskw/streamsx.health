#ifndef SPL_FUNCTION_com_ibm_streamsx_health_analyze_vital_generated_addToMessages_h
#define SPL_FUNCTION_com_ibm_streamsx_health_analyze_vital_generated_addToMessages_h

#include "../../../../../../../../type/BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ.h"
namespace com {
    namespace ibm {
        namespace streamsx {
            namespace health {
                namespace analyze {
                    namespace vital {
                        namespace generated {
                            void addToMessages (SPL::BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ& obj, const SPL::ustring& arg0);
                        }
                    }
                }
            }
        }
    }
}

#endif // SPL_FUNCTION_com_ibm_streamsx_health_analyze_vital_generated_addToMessages_h
