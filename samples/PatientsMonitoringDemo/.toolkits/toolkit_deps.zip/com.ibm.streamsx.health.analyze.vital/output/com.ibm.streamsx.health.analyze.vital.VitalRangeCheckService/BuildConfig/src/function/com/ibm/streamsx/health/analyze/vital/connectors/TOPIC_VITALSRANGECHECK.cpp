#include "SPL/Runtime/Function/SPLFunctions.h"
#include "./TOPIC_VITALSRANGECHECK.h"
namespace com { namespace ibm { namespace streamsx { namespace health { namespace analyze { namespace vital { namespace connectors { 
SPL::rstring TOPIC_VITALSRANGECHECK ()
{
    return SPL::rstring("analyze.vitalscheck");
}
} } } } } } } 
