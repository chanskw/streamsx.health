// eJztV9uSojoULV7nK6ipebCrLAXxypnpKmy0veCt0R71hYoSNQoJkiDC1Pz7iYj2ZbrP1DlPPVWHvoUtWdnZWYu1m3pOLmDIQSxS1buAMuIKsiDxL1kSPudyef69CvCSIYLzS_0Lm0cLNU_0ZD4NJjfgOBwzZ5gIETxTB_1QAw4eQzDIWAIYpbbfP6PGB7xAgcw_0AyBRR7M12EndJBEu9q2MaqD2q4cruMobCj_0ZlRbt8z7ZkFpb6ulcXU4u1eaj_1XmbIJspuHQaYzx3cwsUFei0WIxboGNsqhZMlpSo_0yHXs_1Wp7pyrEYQ9pS1LeOi51rSIJJLeNCRwQIaB0pGwagw84s2iguBuRtu9OPMuysbb2dZbXTDrTaqTy25wx6m_08lKR6atHQq9jTGdIFBtzR4t6bC8P_1QUbdzecqiDaY7orOMZZdk2t81pMG81O5ZcwRyiFMNJ1da1UbNsScXhuuuEvjJalkpSSIJFV4GMHWkNFy157jW1ijkY6Jbc0HWvt9dGb2Xo98xiIdqFXn87IjGqMnNX7O_1NY9tYzNumqRjjRkUeaw2NtCZd3XsHghS65SI1drhvjOedeFfr1EeaNF7PlHcnnNcct6NJbWD0cC_025H6PF0qfh4v47VmrhtRFu_0Ct5frjETV3ci9aHg29vKNmaxIbk0OvO5FYH1X6cTjRyH314S54C5ptm3SwjrVevWvJk2FbL2jeNBqb1dHxAXTrehO1zIdAL06rMS1T6H8P3e91SMsm_0T7ZrzHeDtGqOTeq9aZWdvzG_1iFA_1LxbEV5b8iPSt31SnkTxGBJL9tZN22bbcNi9U0Jz5g5A7d6SLFl5qOAI1x_0dfevYsGTA9OHu3VQ5o3iqtUZrYxa1ZpczYdTeMOduxxcqj9mUq85wbWXuysCb3pVop7TtdJG3d_0r1fdsphbNthejGxmtP58v1YlKpKsjfrpx9fduhpQmqrOT4fq_1L4KiElRnR43onahS83cGSa9ixi2w986kjlWtxZ1787rvTYhlvVwk3ZIEyrtgv3ln7PeAJ5tBQVRd4X5OBzyWP8DorJncfTyPi7Z_0XsCzwN_1cXRSgmf6XzBhaEOBBgIYnJ51iAMFMK51Dh15Dy521dEPIb4sKLkQDbRTi_1RuzqLLnUWShwPQfSfGpKtEcwYuS0PR26JJ9jvFw7xOjJmnLcmnKvAHKpNeXO1mQDBgRMMExMkv8gj_1jX2n9woQqu4Cfu_1uOTyK8lwZSJz09cRPZFwW1b_1Camm8utIbPI4pi5SUbXJzI3fyVAaCVmMqqaIDVTq6e8oSCOAy83G0Azr18R2Rfr3YjfvokJkW9uxAT3dP24jk7XRyXkaR_08ApxDqspJpKoXFvGNJzRS1ZRHqpoQSVWfGqXMTVrHy3VCSyqNgQszvC5iWlzqOdYSUHaWafBCppcjvOVp8EcyL0r7Ev_1fJXrpxhLE7K_0c_0AX8H3mAMPdR1vsNF853r5BtIv54zoCP1giKDLoeP6wPnGLmXFaRBgsXMTFzyjibiE7m0Z9iuEEOzEjPCv8zGUGHwj9Rkq9ZlgOvhPG_1Mv5Xxm_0UUXhXGT8_1CUJB4EctsIA3GV_1Pv5_08NHsZOmQJTqfctm9FGx7QEl4_1ejrYd2dTEvhLOOb_1CVxDZ5ATHOeozSNm8kyKwVu7clFk9BUkjSjf1RVjSWx4nZ_0grxwCTjMPwAme1gqIe33sVvCQLaSfJP0Ped3_1fLyjTdoeWUBW6rfCtUpKQQRrmE1bZhE4XIDZc3zh6YjbKHHQ8hoxozSQFIqH_0IvBZw9crk8RXztA_1wTqIO7TqUXfii6klEdpNo2IJ2u_13viEuG28IulK1BsUrognInJEFvjwVpB4yf8GhyfJAt


#include "./Custom_3.h"
using namespace SPL::_Operator::VitalsCheck_7;

#include <SPL/Runtime/Function/SPLFunctions.h>
#include <SPL/Runtime/Operator/Port/Punctuation.h>

#include <string>

#define MY_OPERATOR_SCOPE SPL::_Operator::VitalsCheck_7
#define MY_BASE_OPERATOR Custom_3_Base
#define MY_OPERATOR Custom_3$OP



static SPL::Operator * initer() { return new MY_OPERATOR_SCOPE::MY_OPERATOR(); }
bool MY_BASE_OPERATOR::globalInit_ = MY_BASE_OPERATOR::globalIniter();
bool MY_BASE_OPERATOR::globalIniter() {
    instantiators_.insert(std::make_pair("VitalsCheck_7::Custom_3",&initer));
    return true;
}

template<class T> static void initRTC (SPL::Operator& o, T& v, const char * n) {
    SPL::ValueHandle vh = v;
    o.getContext().getRuntimeConstantValue(vh, n);
}

MY_BASE_OPERATOR::MY_BASE_OPERATOR()
 : Operator() {
    uint32_t index = getIndex();
    initRTC(*this, lit$0, "lit$0");
    initRTC(*this, lit$1, "lit$1");
    initRTC(*this, lit$2, "lit$2");
    initRTC(*this, lit$3, "lit$3");
    state$patientMap = lit$3;
    SPLAPPTRC(L_DEBUG, "Variable: state$patientMap Value: " << state$patientMap,SPL_OPER_DBG);
    (void) getParameters(); // ensure thread safety by initializing here
    $oportBitset = OPortBitsetType(std::string("01"));
}
MY_BASE_OPERATOR::~MY_BASE_OPERATOR()
{
    for (ParameterMapType::const_iterator it = paramValues_.begin(); it != paramValues_.end(); it++) {
        const ParameterValueListType& pvl = it->second;
        for (ParameterValueListType::const_iterator it2 = pvl.begin(); it2 != pvl.end(); it2++) {
            delete *it2;
        }
    }
}

void MY_BASE_OPERATOR::tupleLogic(Tuple & tuple, uint32_t port) {
    IPort0Type & iport$0 = static_cast<IPort0Type  &>(tuple);
    AutoPortMutex $apm($svMutex, *this);
    
{
    const SPL::rstring id$patientId = iport$0.get_obx().get_patientId();
    if ((::SPL::Functions::Collections::has(state$patientMap, id$patientId) == lit$0)) 
        {
            SPL::BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ id$p(::com::ibm::streamsx::health::analyze::vital::newPatient());
            id$p.get_name() = ::SPL::spl_cast<SPL::ustring, SPL::rstring >::cast(id$patientId);
            ::com::ibm::streamsx::health::analyze::vital::populate(id$p, iport$0.get_obx());
            ::SPL::Functions::Collections::insertM(state$patientMap, id$patientId, id$p);
            do { SPL::BeJwli0sKAjEQBa9k6wgzywE3rhQ9gHSGF23Ij85T8PYG3FVBFYUidtAnwlETnCYS2sm0sybbTHah3b9_1icsL6rwpMdDXD3x8yeeM3gd1n4pm_0Oy15nOJ1abeLvsoQuQ2Yr4diz2uSkPhDxYpC6L temp = SPL::BeJwli0sKAjEQBa9k6wgzywE3rhQ9gHSGF23Ij85T8PYG3FVBFYUidtAnwlETnCYS2sm0sybbTHah3b9_1icsL6rwpMdDXD3x8yeeM3gd1n4pm_0Oy15nOJ1abeLvsoQuQ2Yr4diz2uSkPhDxYpC6L(id$p); submit (temp, lit$1); } while(0);
        }
    else
        {
            SPL::BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ id$p(state$patientMap.at(id$patientId));
            ::com::ibm::streamsx::health::analyze::vital::populate(id$p, iport$0.get_obx());
            ::SPL::Functions::Collections::insertM(state$patientMap, id$patientId, id$p);
            do { SPL::BeJwli0sKAjEQBa9k6wgzywE3rhQ9gHSGF23Ij85T8PYG3FVBFYUidtAnwlETnCYS2sm0sybbTHah3b9_1icsL6rwpMdDXD3x8yeeM3gd1n4pm_0Oy15nOJ1abeLvsoQuQ2Yr4diz2uSkPhDxYpC6L temp = SPL::BeJwli0sKAjEQBa9k6wgzywE3rhQ9gHSGF23Ij85T8PYG3FVBFYUidtAnwlETnCYS2sm0sybbTHah3b9_1icsL6rwpMdDXD3x8yeeM3gd1n4pm_0Oy15nOJ1abeLvsoQuQ2Yr4diz2uSkPhDxYpC6L(id$p); submit (temp, lit$2); } while(0);
        }
}

}


void MY_BASE_OPERATOR::processRaw(Tuple & tuple, uint32_t port) {
    tupleLogic (tuple, port);
    static_cast<MY_OPERATOR_SCOPE::MY_OPERATOR*>(this)->MY_OPERATOR::process(tuple, port);
}


void MY_BASE_OPERATOR::punctLogic(Punctuation const & punct, uint32_t port) {
}

void MY_BASE_OPERATOR::punctPermitProcessRaw(Punctuation const & punct, uint32_t port) {
    {
        punctNoPermitProcessRaw(punct, port);
    }
}

void MY_BASE_OPERATOR::punctNoPermitProcessRaw(Punctuation const & punct, uint32_t port) {
    switch(punct) {
    case Punctuation::WindowMarker:
        punctLogic(punct, port);
        process(punct, port);
        break;
    case Punctuation::FinalMarker:
        punctLogic(punct, port);
        
        if (punct == Punctuation::FinalMarker) {
            process(punct, port);
            bool forward = false;
            {
                AutoPortMutex $apm($fpMutex, *this);
                $oportBitset.reset(port);
                if ($oportBitset.none()) {
                    $oportBitset.set(1);
                    forward=true;
                }
            }
            if(forward)
                submit(punct, 0);
            return;
        }
        process(punct, port);
        break;
    case Punctuation::DrainMarker:
    case Punctuation::ResetMarker:
    case Punctuation::ResumeMarker:
        break;
    case Punctuation::SwitchMarker:
        break;
    default:
        break;
    }
}

void MY_BASE_OPERATOR::processRaw(Punctuation const & punct, uint32_t port) {
    switch(port) {
    case 0:
        punctNoPermitProcessRaw(punct, port);
        break;
    }
}



void MY_BASE_OPERATOR::checkpointStateVariables(NetworkByteBuffer & opstate) const {
    opstate << state$patientMap;
}

void MY_BASE_OPERATOR::restoreStateVariables(NetworkByteBuffer & opstate) {
    opstate >> state$patientMap;
}

void MY_BASE_OPERATOR::checkpointStateVariables(Checkpoint & ckpt) {
    ckpt << state$patientMap;
}

void MY_BASE_OPERATOR::resetStateVariables(Checkpoint & ckpt) {
    ckpt >> state$patientMap;
}

void MY_BASE_OPERATOR::resetStateVariablesToInitialState() {
    state$patientMap = lit$3;
    SPLAPPTRC(L_DEBUG, "Variable: state$patientMap Value: " << state$patientMap,SPL_OPER_DBG);
}

bool MY_BASE_OPERATOR::hasStateVariables() const {
    return true;
}

void MY_BASE_OPERATOR::resetToInitialStateRaw() {
    AutoMutex $apm($svMutex);
    StateHandler *sh = getContext().getStateHandler();
    if (sh != NULL) {
        sh->resetToInitialState();
    }
    resetStateVariablesToInitialState();
}

void MY_BASE_OPERATOR::checkpointRaw(Checkpoint & ckpt) {
    AutoMutex $apm($svMutex);
    StateHandler *sh = getContext().getStateHandler();
    if (sh != NULL) {
        sh->checkpoint(ckpt);
    }
    checkpointStateVariables(ckpt);
}

void MY_BASE_OPERATOR::resetRaw(Checkpoint & ckpt) {
    AutoMutex $apm($svMutex);
    StateHandler *sh = getContext().getStateHandler();
    if (sh != NULL) {
        sh->reset(ckpt);
    }
    resetStateVariables(ckpt);
}



