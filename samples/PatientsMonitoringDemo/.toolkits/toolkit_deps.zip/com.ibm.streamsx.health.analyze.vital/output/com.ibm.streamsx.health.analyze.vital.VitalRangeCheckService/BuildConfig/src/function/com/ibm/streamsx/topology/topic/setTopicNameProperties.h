#ifndef SPL_FUNCTION_com_ibm_streamsx_topology_topic_setTopicNameProperties_h
#define SPL_FUNCTION_com_ibm_streamsx_topology_topic_setTopicNameProperties_h

namespace com {
    namespace ibm {
        namespace streamsx {
            namespace topology {
                namespace topic {
                    /* stateful */ SPL::int32 setTopicNameProperties (const SPL::rstring& exportType, const SPL::rstring& topicName, const SPL::boolean& allowFilter, const SPL::rstring& id$class);
                }
            }
        }
    }
}

#endif // SPL_FUNCTION_com_ibm_streamsx_topology_topic_setTopicNameProperties_h
