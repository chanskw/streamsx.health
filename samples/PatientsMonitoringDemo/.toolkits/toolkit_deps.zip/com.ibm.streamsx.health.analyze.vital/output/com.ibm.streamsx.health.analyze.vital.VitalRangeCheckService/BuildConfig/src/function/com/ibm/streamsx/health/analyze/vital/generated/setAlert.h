#ifndef SPL_FUNCTION_com_ibm_streamsx_health_analyze_vital_generated_setAlert_h
#define SPL_FUNCTION_com_ibm_streamsx_health_analyze_vital_generated_setAlert_h

#include "../../../../../../../../type/BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ.h"
namespace com {
    namespace ibm {
        namespace streamsx {
            namespace health {
                namespace analyze {
                    namespace vital {
                        namespace generated {
                            void setAlert (SPL::BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ& obj);
                        }
                    }
                }
            }
        }
    }
}

#endif // SPL_FUNCTION_com_ibm_streamsx_health_analyze_vital_generated_setAlert_h
