// eJzdWG1zmkoUHr72VzCdfjDTXGHBF_0S2mcGoiUaiBE01X5hFVt0EFgKLxLT573dBYpLGpvXednQuOo4c9pw959lznt1DFLjFmGIX06WqHscR9T0OcCL7VLj3xaKw_0k5jMqHYJ8LE9wRse0JEQwS96E6YI_0jSuQAJdJf3SFhgCl1hhggKIUWOAB1n4OsoiuAMRcX5_099hM0JUc1FIX5qjywAJddRJXCxGZ9p106jD2k0lmd0vk6Yczo3a7NQ8aUly_01opD5T_0_0ERuXdZb4yF2qEYStzkgx2NTijwxWtr24BTOZbtmATyJupUwCXSnMWrId8oSIV2eOYCUAs8Se0tQJr0OgDbqLiLfiA1pHJYcfC_1F5k1_13rgbB8eV7g8dVZqpo3p9ZIFORbut3iXDBZkPalrTG10mkjgYerh0XrOVxrihi616R3MssT2XyknzrD28VjpIwheDL3hkiQu56laXSlIfy43ZUqwZuj2qnpQTIhlSzSwl3tUgROjLpWkvXFn0jqlhiSUys1sETHqGQafzq_0lx5eItV5NrzchcpRej2_0G0gU1HW0j6vDsaYqicji_0ZF5OThS5rg_1Y1C3xhmkY07gTdCnDM69YovjptdSxQJcxE_0R4NFaehGa0K86M_1O3OTUDYm5bKY_0LF9JiNK76IaKVngKmhpVbPXa1ig2WgE_0q1mbHZyGZ63fflcC_1v3zUWnawHnvKsHve6gLTr6QjeVZX2iHd_0gWSilBgAXUZZOH_1wFDDmz31XVfV0TjpNEjhXoB3Hl59T1IZUlLpOBlYwVbojJbCWTVjJM1qPkV5LSBr3yBvuVDeOqr6wpryS1DXpAfDUMbPIfSJsClTcJN4UBNsUBKpuE1U3qeTDxczdrL2WcMPc99MhY0PEwEWaYrimsmFNYBL3ARZHQhxQjQiPdJ5j66VwN5PlCkfq_0e4NplHJgkXFg8TsDxZwDiysOdCCFHPEJSvk5ZWkc_0OE6L_1aT_1DiPC7P95Os7nl1PRVecIWr5Vg5N4YD_1zOfhZE_1w05O_1M0085QuFH6tn9wy1kF6wIczcJz6rmYMDPlNPr6_1rf_0mlqgx1lo02_03nEXVVXwKtqjryqZtCr6nr_1YYPzDegNb3Kf_1_1NUL_1bPN_0Y7zIIFz6Z9eALtZ6jZQQNDtvO7eMJwO8pMyQf8t2_18zzXN5XeK0sEfQHw7GEq_1C_13tFvrhl9OUIi9I54hDtMatvHPYKjuHbbtEXRW4sn2irhSru0_1U2s4R_1wlsUdCT1oCBP8GlWxIc2Dli229B4Ne49LniihLAHnAp2D2ZbsemOeaVX8L8OyL_0vNIt7wHs1V3C7vj8V36veyI_0XTl2YtxrJ9_0EnI9i28OUL6SR5IuuMPEDn8yxiwoiW5WHd_1mpOauDx1i3aHQLQfqS5S_1ADtdPWG2hr6pfMHH8RIfhDQp_1XBWPsaQB44k1YZv0p2y6fjp_1DNP3PKp6Cd0YHf2bOF76kYLZJg66Kxx8BI8FU3uRxQw5wK1bCI7GrA37lDVvPKu_1Q5v1XQgSHqaVcbiSPztcrCWPh4bDvG3k1yT9JAm1Bas1ZtTFLOq8lTzivbzUD3MJT6CH1jeh73ttMvXzmdJ9dm3xGSkdZV2e_17rL279kz_1o8wPn_1A8xFBvo_1gFLCAf


#ifndef SPL_OPER_INSTANCE_VITALSCHECK_7_HEALTHRULES_2_RULEOUT_H_
#define SPL_OPER_INSTANCE_VITALSCHECK_7_HEALTHRULES_2_RULEOUT_H_

#include <SPL/Runtime/Serialization/NetworkByteBuffer.h>
#include <SPL/Runtime/Operator/Operator.h>
#include <SPL/Runtime/Operator/ParameterValue.h>
#include <SPL/Runtime/Operator/OperatorContext.h>
#include <SPL/Runtime/Operator/OperatorMetrics.h>
#include <SPL/Runtime/Operator/Port/AutoPortMutex.h>
#include <SPL/Runtime/Operator/State/StateHandler.h>
#include <SPL/Runtime/ProcessingElement/PE.h>
#include <SPL/Runtime/Type/SPLType.h>
#include <SPL/Runtime/Utility/CV.h>
using namespace UTILS_NAMESPACE;

#include "../../../function/com/ibm/streamsx/health/analyze/vital/generated/addToMessages.h"
#include "../../../function/com/ibm/streamsx/health/analyze/vital/generated/setAlert.h"
#include "../../../type/BeJwli0sKAjEQBa9k6wgzywE3rhQ9gHSGF23Ij85T8PYG3FVBFYUidtAnwlETnCYS2sm0sybbTHah3b9_1icsL6rwpMdDXD3x8yeeM3gd1n4pm_0Oy15nOJ1abeLvsoQuQ2Yr4diz2uSkPhDxYpC6L.h"
#include "../../../type/BeJwli8EKAjEMBX_1J6Aq7xwUvnhT9AEmXVw20TUmi4N9b8DYDM0FBJAd_0Ih25wEKIUj8Je2iRTWiX_0v37l7y8wBY3Dgy09QMbX7G5wn2Q29S4wmZTreeWVSbvl30mCtQ_04ngbFn1cOQQtfhZfC6R.h"
#include "../../../type/BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ.h"
#include "../../../type/BeJyrNIo3NArPzEvJL_1dNLMpOLTI0dMvMS8yBcACkegr2.h"

#include <bitset>

#define MY_OPERATOR ruleOut$OP
#define MY_BASE_OPERATOR ruleOut_Base
#define MY_OPERATOR_SCOPE SPL::_Operator::VitalsCheck_7::HealthRules_2

namespace SPL {
namespace _Operator {
namespace VitalsCheck_7 {
namespace HealthRules_2 {

class MY_BASE_OPERATOR : public Operator
{
public:
    
    typedef SPL::BeJwli0sKAjEQBa9k6wgzywE3rhQ9gHSGF23Ij85T8PYG3FVBFYUidtAnwlETnCYS2sm0sybbTHah3b9_1icsL6rwpMdDXD3x8yeeM3gd1n4pm_0Oy15nOJ1abeLvsoQuQ2Yr4diz2uSkPhDxYpC6L IPort0Type;
    typedef SPL::BeJwli8EKAjEMBX_1J6Aq7xwUvnhT9AEmXVw20TUmi4N9b8DYDM0FBJAd_0Ih25wEKIUj8Je2iRTWiX_0v37l7y8wBY3Dgy09QMbX7G5wn2Q29S4wmZTreeWVSbvl30mCtQ_04ngbFn1cOQQtfhZfC6R OPort0Type;
    
    MY_BASE_OPERATOR();
    
    ~MY_BASE_OPERATOR();
    
    inline void tupleLogic(Tuple & tuple, uint32_t port);
    void processRaw(Tuple & tuple, uint32_t port);
    
    inline void punctLogic(Punctuation const & punct, uint32_t port);
    void processRaw(Punctuation const & punct, uint32_t port);
    void punctPermitProcessRaw(Punctuation const & punct, uint32_t port);
    void punctNoPermitProcessRaw(Punctuation const & punct, uint32_t port);
    
    inline void submit(Tuple & tuple, uint32_t port)
    {
        Operator::submit(tuple, port);
    }
    inline void submit(Punctuation const & punct, uint32_t port)
    {
        Operator::submit(punct, port);
    }
    
    
    
    SPL::float32 lit$0;
    SPL::ustring lit$1;
    SPL::int32 lit$2;
    SPL::int32 lit$3;
    SPL::ustring lit$4;
    SPL::float32 lit$5;
    SPL::ustring lit$6;
    SPL::int32 lit$7;
    SPL::int32 lit$8;
    SPL::ustring lit$9;
    SPL::int32 lit$10;
    SPL::ustring lit$11;
    SPL::float32 lit$12;
    SPL::float32 lit$13;
    SPL::ustring lit$14;
    SPL::float32 lit$15;
    SPL::float32 lit$16;
    SPL::ustring lit$17;
    SPL::uint32 lit$18;
    SPL::uint32 lit$19;
    
    SPL::BeJwli8EKAjEMBX_1J6Aq7xwUvnhT9AEmXVw20TUmi4N9b8DYDM0FBJAd_0Ih25wEKIUj8Je2iRTWiX_0v37l7y8wBY3Dgy09QMbX7G5wn2Q29S4wmZTreeWVSbvl30mCtQ_04ngbFn1cOQQtfhZfC6R state$ovar;
    
protected:
    Mutex $svMutex;
    typedef std::bitset<2> OPortBitsetType;
    OPortBitsetType $oportBitset;
    Mutex $fpMutex;
    void checkpointStateVariables(NetworkByteBuffer & opstate) const;
    void restoreStateVariables(NetworkByteBuffer & opstate);
    void checkpointStateVariables(Checkpoint & ckpt);
    void resetStateVariables(Checkpoint & ckpt);
    void resetStateVariablesToInitialState();
    bool hasStateVariables() const;
    void resetToInitialStateRaw();
    void checkpointRaw(Checkpoint & ckpt);
    void resetRaw(Checkpoint & ckpt);
private:
    static bool globalInit_;
    static bool globalIniter();
    ParameterMapType paramValues_;
    ParameterMapType& getParameters() { return paramValues_;}
    void addParameterValue(std::string const & param, ConstValueHandle const& value)
    {
        ParameterMapType::iterator it = paramValues_.find(param);
        if (it == paramValues_.end())
            it = paramValues_.insert (std::make_pair (param, ParameterValueListType())).first;
        it->second.push_back(&ParameterValue::create(value));
    }
    void addParameterValue(std::string const & param)
    {
        ParameterMapType::iterator it = paramValues_.find(param);
        if (it == paramValues_.end())
            it = paramValues_.insert (std::make_pair (param, ParameterValueListType())).first;
        it->second.push_back(&ParameterValue::create());
    }
};


class MY_OPERATOR : public MY_BASE_OPERATOR 
{
public:
   MY_OPERATOR() {}
   
       void getCheckpoint(NetworkByteBuffer & opstate) { checkpointStateVariables(opstate); }
       void restoreCheckpoint(NetworkByteBuffer & opstate) { restoreStateVariables(opstate); }
   
   
}; 

} // namespace VitalsCheck_7
} // namespace HealthRules_2
} // namespace _Operator
} // namespace SPL

#undef MY_OPERATOR_SCOPE
#undef MY_BASE_OPERATOR
#undef MY_OPERATOR
#endif // SPL_OPER_INSTANCE_VITALSCHECK_7_HEALTHRULES_2_RULEOUT_H_

