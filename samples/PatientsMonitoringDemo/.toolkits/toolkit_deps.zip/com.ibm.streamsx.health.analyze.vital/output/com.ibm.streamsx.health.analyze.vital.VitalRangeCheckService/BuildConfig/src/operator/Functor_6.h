// eJzNU12PmkAUDf9k0_1ShTTYgyqJumk1g0RVBVwW66gsZZcSBYQaZQYRfX3RdN21N0zRpsuEBcj_1OvZxzLkuxmEEMOKIE4Pv7fk7WnGaCLDTqRxU_0iaLEyxRKOhwW2chRmmVcpONoSivU4U6sjHfOwbRXS9NxWrbba8uu1tPowLOMVNx_0_0q2fNi1VYXZMxra7HFZxd6hPtYYbLlrXq1_0nuWbpdZ_1tERlVvjweaVPdWBar6krLptewUJxfGzR2p8yJ5VG5PtiGGjNn4FW2tx9ZXoOPUXtcFZ5Gnzqzx_1w3XB712XNYaSPd8mVvYhpNLZ2XrtOZHmbA0o0_0Gjiz3FDmnYqpDGYvRfKiQ6Y69MXbhYREE7TpL_02O3tdUnPV2sxzNfXlQktCXvyMjGlPVKysXUl9Ow34Q8KiYWI_0twlkkz6D75Dd8uTVrk5Lo3_1FucOj5MuDGJL6_0ZxEd9_0z2BltH0fqW31Cm5pbjx7ieorp8Dgm3k6C1TGSQzh_1v2PAuGloo3WFd35n4rlhEbWrY29ScL9fhymt3WiiLNninR0N256H2Rq6edoYMDq2ivaBGpQ_1LXjON977cJThQeLjIGG6o3Wq4VF6yZK6oJNqczHC0lCBtaQIlxjMIEgaCBBEpRPwtcBC3EGC_0lRhIUgyZNKmtWW_1MRpSg2piIhAZMqCRySnGMOJPWNBHRKhF_1ARBB7eeyguIecYClAHAgEErgcYejuVFKM_165ITgT_0_17_0A2ssICF7JU5QhADu0RoKPK_0p_0ZbVf1zTcYOC27dPTNenSzaDByF9Jc4MhHNWqPkJ6rdD8_0xPIOyUd2tPXUKvc4_0oZ4xzNyJcVW44u_10ZjJWMw_0TSvaYBfLg5d55wN5iCY_0ce4Px9Sk6Th5M29Ko2H9PXQlLr0xTo6nDm5G_1EORN6SV20uv0nVW5_0Uvb2f2nzVnYUSf74h_1N_04yl6P4LL6m_0BS5kYQu5flPjytXbiDxbiG9b



#ifndef SPL_OPER_INSTANCE_FUNCTOR_6_H_
#define SPL_OPER_INSTANCE_FUNCTOR_6_H_

#include <SPL/Runtime/Operator/Operator.h>
#include <SPL/Runtime/Operator/ParameterValue.h>
#include <SPL/Runtime/Operator/OperatorContext.h>
#include <SPL/Runtime/Operator/OperatorMetrics.h>
#include <SPL/Runtime/Operator/Port/AutoPortMutex.h>
#include <SPL/Runtime/Operator/State/StateHandler.h>
#include <SPL/Runtime/ProcessingElement/PE.h>
#include <SPL/Runtime/Type/SPLType.h>
#include <SPL/Runtime/Utility/CV.h>
using namespace UTILS_NAMESPACE;

#include "../type/BeJwrMS42ykwpNjQozi8tSk4NqSxILbZISS3LTE71TAEAoHUKDp.h"
#include "../type/BeJwrMSo2K64sLknNLTZJzk9JBQA0TgY3.h"
#include "../type/BeJwrMSo2ykwpNjTIyU9OLMnMz_1NMAQBDZwbz.h"
#include "../type/BeJwrMfE0KikuMSo2K64sLknNLTZJzk9JNTQsSk1MycxLD6ksSHUzLUvMKU0tNi7NzwUAoG8RCu.h"
#include "../type/BeJwtjFsOgzAMBK_1UPID2ApXyTS8QxRaKBDFiHSRuD4X8zs6serWwmWBes6SoWUqgnnjPifFZL8BFA6lrEqRuiX_1Hyng_1ViDjNo6UyzTeo_1pgFddtjwPKC3wSYmOa9G_0_13R7nynBVlqHxE_1atDPk.h"
#include "../type/BeJwtjFsOwjAMBK9EHhS4AFK_04QIhtlCkNo66TtXentLmd3Zm1apXC5sJ5jJKipqlBBqIl5wYj7oDLhpIXZcgbU783irjflqBjJs5Ui7f1zGqD1ax3w7YoDzBJyE2pkv_19nld4tgYrsl069zJZ4WrmX46njfp.h"

#include <bitset>

#define MY_OPERATOR Functor_6$OP
#define MY_BASE_OPERATOR Functor_6_Base
#define MY_OPERATOR_SCOPE SPL::_Operator

namespace SPL {
namespace _Operator {

class MY_BASE_OPERATOR : public Operator
{
public:
    
    typedef SPL::BeJwtjFsOgzAMBK_1UPID2ApXyTS8QxRaKBDFiHSRuD4X8zs6serWwmWBes6SoWUqgnnjPifFZL8BFA6lrEqRuiX_1Hyng_1ViDjNo6UyzTeo_1pgFddtjwPKC3wSYmOa9G_0_13R7nynBVlqHxE_1atDPk IPort0Type;
    typedef SPL::BeJwtjFsOwjAMBK9EHhS4AFK_04QIhtlCkNo66TtXentLmd3Zm1apXC5sJ5jJKipqlBBqIl5wYj7oDLhpIXZcgbU783irjflqBjJs5Ui7f1zGqD1ax3w7YoDzBJyE2pkv_19nld4tgYrsl069zJZ4WrmX46njfp OPort0Type;
    
    MY_BASE_OPERATOR();
    
    ~MY_BASE_OPERATOR();
    
    inline void tupleLogic(Tuple const & tuple, uint32_t port);
    void processRaw(Tuple const & tuple, uint32_t port);
    
    inline void punctLogic(Punctuation const & punct, uint32_t port);
    void processRaw(Punctuation const & punct, uint32_t port);
    void punctPermitProcessRaw(Punctuation const & punct, uint32_t port);
    void punctNoPermitProcessRaw(Punctuation const & punct, uint32_t port);
    
    inline void submit(Tuple & tuple, uint32_t port)
    {
        Operator::submit(tuple, port);
    }
    inline void submit(Punctuation const & punct, uint32_t port)
    {
        Operator::submit(punct, port);
    }
    
    
    
    
    
protected:
    Mutex $svMutex;
    typedef std::bitset<2> OPortBitsetType;
    OPortBitsetType $oportBitset;
    Mutex $fpMutex;
    void checkpointStateVariables(NetworkByteBuffer & opstate) const;
    void restoreStateVariables(NetworkByteBuffer & opstate);
    void checkpointStateVariables(Checkpoint & ckpt);
    void resetStateVariables(Checkpoint & ckpt);
    void resetStateVariablesToInitialState();
    bool hasStateVariables() const;
    void resetToInitialStateRaw();
    void checkpointRaw(Checkpoint & ckpt);
    void resetRaw(Checkpoint & ckpt);
private:
    static bool globalInit_;
    static bool globalIniter();
    ParameterMapType paramValues_;
    ParameterMapType& getParameters() { return paramValues_;}
    void addParameterValue(std::string const & param, ConstValueHandle const& value)
    {
        ParameterMapType::iterator it = paramValues_.find(param);
        if (it == paramValues_.end())
            it = paramValues_.insert (std::make_pair (param, ParameterValueListType())).first;
        it->second.push_back(&ParameterValue::create(value));
    }
    void addParameterValue(std::string const & param)
    {
        ParameterMapType::iterator it = paramValues_.find(param);
        if (it == paramValues_.end())
            it = paramValues_.insert (std::make_pair (param, ParameterValueListType())).first;
        it->second.push_back(&ParameterValue::create());
    }
};


class MY_OPERATOR : public MY_BASE_OPERATOR
{
public:
   MY_OPERATOR() {}
  
   void process(Tuple const & tuple, uint32_t port);
   void process(Punctuation const & punct, uint32_t port);
   
}; 

} // namespace _Operator
} // namespace SPL

#undef MY_OPERATOR_SCOPE
#undef MY_BASE_OPERATOR
#undef MY_OPERATOR
#endif // SPL_OPER_INSTANCE_FUNCTOR_6_H_

