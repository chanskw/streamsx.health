#ifndef SPL_FUNCTION_com_ibm_streamsx_health_analyze_vital_populate_h
#define SPL_FUNCTION_com_ibm_streamsx_health_analyze_vital_populate_h

#include "../../../../../../../type/BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ.h"
#include "../../../../../../../type/BeJwrMS42ykwpNjQozi8tSk4NqSxILbZISS3LTE71TAEAoHUKDp.h"
#include "../../../../../../../type/BeJwrMSo2K64sLknNLTZJzk9JBQA0TgY3.h"
#include "../../../../../../../type/BeJwrMSo2ykwpNjTIyU9OLMnMz_1NMAQBDZwbz.h"
#include "../../../../../../../type/BeJwrMfE0KikuMSo2K64sLknNLTZJzk9JNTQsSk1MycxLD6ksSHUzLUvMKU0tNi7NzwUAoG8RCu.h"
#include "../../../../../../../type/BeJwtjFsOgzAMBK_1UPID2ApXyTS8QxRaKBDFiHSRuD4X8zs6serWwmWBes6SoWUqgnnjPifFZL8BFA6lrEqRuiX_1Hyng_1ViDjNo6UyzTeo_1pgFddtjwPKC3wSYmOa9G_0_13R7nynBVlqHxE_1atDPk.h"
namespace com {
    namespace ibm {
        namespace streamsx {
            namespace health {
                namespace analyze {
                    namespace vital {
                        SPL::BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ populate (SPL::BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ& patient, const SPL::BeJwtjFsOgzAMBK_1UPID2ApXyTS8QxRaKBDFiHSRuD4X8zs6serWwmWBes6SoWUqgnnjPifFZL8BFA6lrEqRuiX_1Hyng_1ViDjNo6UyzTeo_1pgFddtjwPKC3wSYmOa9G_0_13R7nynBVlqHxE_1atDPk& obs);
                    }
                }
            }
        }
    }
}

#endif // SPL_FUNCTION_com_ibm_streamsx_health_analyze_vital_populate_h
