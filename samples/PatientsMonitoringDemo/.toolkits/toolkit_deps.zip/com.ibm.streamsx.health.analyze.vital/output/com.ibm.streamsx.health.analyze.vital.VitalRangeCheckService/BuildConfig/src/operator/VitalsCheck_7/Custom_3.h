// eJztV9uSojoULV7nK6ipebCrLAXxypnpKmy0veCt0R71hYoSNQoJkiDC1Pz7iYj2ZbrP1DlPPVWHvoUtWdnZWYu1m3pOLmDIQSxS1buAMuIKsiDxL1kSPudyef69CvCSIYLzS_0Lm0cLNU_0ZD4NJjfgOBwzZ5gIETxTB_1QAw4eQzDIWAIYpbbfP6PGB7xAgcw_0AyBRR7M12EndJBEu9q2MaqD2q4cruMobCj_0ZlRbt8z7ZkFpb6ulcXU4u1eaj_1XmbIJspuHQaYzx3cwsUFei0WIxboGNsqhZMlpSo_0yHXs_1Wp7pyrEYQ9pS1LeOi51rSIJJLeNCRwQIaB0pGwagw84s2iguBuRtu9OPMuysbb2dZbXTDrTaqTy25wx6m_08lKR6atHQq9jTGdIFBtzR4t6bC8P_1QUbdzecqiDaY7orOMZZdk2t81pMG81O5ZcwRyiFMNJ1da1UbNsScXhuuuEvjJalkpSSIJFV4GMHWkNFy157jW1ijkY6Jbc0HWvt9dGb2Xo98xiIdqFXn87IjGqMnNX7O_1NY9tYzNumqRjjRkUeaw2NtCZd3XsHghS65SI1drhvjOedeFfr1EeaNF7PlHcnnNcct6NJbWD0cC_025H6PF0qfh4v47VmrhtRFu_0Ct5frjETV3ci9aHg29vKNmaxIbk0OvO5FYH1X6cTjRyH314S54C5ptm3SwjrVevWvJk2FbL2jeNBqb1dHxAXTrehO1zIdAL06rMS1T6H8P3e91SMsm_0T7ZrzHeDtGqOTeq9aZWdvzG_1iFA_1LxbEV5b8iPSt31SnkTxGBJL9tZN22bbcNi9U0Jz5g5A7d6SLFl5qOAI1x_0dfevYsGTA9OHu3VQ5o3iqtUZrYxa1ZpczYdTeMOduxxcqj9mUq85wbWXuysCb3pVop7TtdJG3d_0r1fdsphbNthejGxmtP58v1YlKpKsjfrpx9fduhpQmqrOT4fq_1L4KiElRnR43onahS83cGSa9ixi2w986kjlWtxZ1787rvTYhlvVwk3ZIEyrtgv3ln7PeAJ5tBQVRd4X5OBzyWP8DorJncfTyPi7Z_0XsCzwN_1cXRSgmf6XzBhaEOBBgIYnJ51iAMFMK51Dh15Dy521dEPIb4sKLkQDbRTi_1RuzqLLnUWShwPQfSfGpKtEcwYuS0PR26JJ9jvFw7xOjJmnLcmnKvAHKpNeXO1mQDBgRMMExMkv8gj_1jX2n9woQqu4Cfu_1uOTyK8lwZSJz09cRPZFwW1b_1Camm8utIbPI4pi5SUbXJzI3fyVAaCVmMqqaIDVTq6e8oSCOAy83G0Azr18R2Rfr3YjfvokJkW9uxAT3dP24jk7XRyXkaR_08ApxDqspJpKoXFvGNJzRS1ZRHqpoQSVWfGqXMTVrHy3VCSyqNgQszvC5iWlzqOdYSUHaWafBCppcjvOVp8EcyL0r7Ev_1fJXrpxhLE7K_0c_0AX8H3mAMPdR1vsNF853r5BtIv54zoCP1giKDLoeP6wPnGLmXFaRBgsXMTFzyjibiE7m0Z9iuEEOzEjPCv8zGUGHwj9Rkq9ZlgOvhPG_1Mv5Xxm_0UUXhXGT8_1CUJB4EctsIA3GV_1Pv5_08NHsZOmQJTqfctm9FGx7QEl4_1ejrYd2dTEvhLOOb_1CVxDZ5ATHOeozSNm8kyKwVu7clFk9BUkjSjf1RVjSWx4nZ_0grxwCTjMPwAme1gqIe33sVvCQLaSfJP0Ped3_1fLyjTdoeWUBW6rfCtUpKQQRrmE1bZhE4XIDZc3zh6YjbKHHQ8hoxozSQFIqH_0IvBZw9crk8RXztA_1wTqIO7TqUXfii6klEdpNo2IJ2u_13viEuG28IulK1BsUrognInJEFvjwVpB4yf8GhyfJAt


#ifndef SPL_OPER_INSTANCE_VITALSCHECK_7_CUSTOM_3_H_
#define SPL_OPER_INSTANCE_VITALSCHECK_7_CUSTOM_3_H_

#include <SPL/Runtime/Serialization/NetworkByteBuffer.h>
#include <SPL/Runtime/Operator/Operator.h>
#include <SPL/Runtime/Operator/ParameterValue.h>
#include <SPL/Runtime/Operator/OperatorContext.h>
#include <SPL/Runtime/Operator/OperatorMetrics.h>
#include <SPL/Runtime/Operator/Port/AutoPortMutex.h>
#include <SPL/Runtime/Operator/State/StateHandler.h>
#include <SPL/Runtime/ProcessingElement/PE.h>
#include <SPL/Runtime/Type/SPLType.h>
#include <SPL/Runtime/Utility/CV.h>
using namespace UTILS_NAMESPACE;

#include "../../function/com/ibm/streamsx/health/analyze/vital/newPatient.h"
#include "../../function/com/ibm/streamsx/health/analyze/vital/populate.h"
#include "../../type/BeJwli0sKAjEQBa9k6wgzywE3rhQ9gHSGF23Ij85T8PYG3FVBFYUidtAnwlETnCYS2sm0sybbTHah3b9_1icsL6rwpMdDXD3x8yeeM3gd1n4pm_0Oy15nOJ1abeLvsoQuQ2Yr4diz2uSkPhDxYpC6L.h"
#include "../../type/BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ.h"
#include "../../type/BeJwrMS42ykwpNjQozi8tSk4NqSxILbZISS3LTE71TAEAoHUKDp.h"
#include "../../type/BeJwrMSo2K64sLknNLTZJzk9JBQA0TgY3.h"
#include "../../type/BeJwrMSo2ykwpNjTIyU9OLMnMz_1NMAQBDZwbz.h"
#include "../../type/BeJwrMfE0KikuMSo2K64sLknNLTZJzk9JNTQsSk1MycxLD6ksSHUzLUvMKU0tNi7NzwUAoG8RCu.h"
#include "../../type/BeJwtjFsOgzAMBK_1UPID2ApXyTS8QxRaKBDFiHSRuD4X8zs6serWwmWBes6SoWUqgnnjPifFZL8BFA6lrEqRuiX_1Hyng_1ViDjNo6UyzTeo_1pgFddtjwPKC3wSYmOa9G_0_13R7nynBVlqHxE_1atDPk.h"
#include "../../type/BeJwtjFsOwjAMBK9EHhS4AFK_04QIhtlCkNo66TtXentLmd3Zm1apXC5sJ5jJKipqlBBqIl5wYj7oDLhpIXZcgbU783irjflqBjJs5Ui7f1zGqD1ax3w7YoDzBJyE2pkv_19nld4tgYrsl069zJZ4WrmX46njfp.h"

#include <bitset>

#define MY_OPERATOR Custom_3$OP
#define MY_BASE_OPERATOR Custom_3_Base
#define MY_OPERATOR_SCOPE SPL::_Operator::VitalsCheck_7

namespace SPL {
namespace _Operator {
namespace VitalsCheck_7 {

class MY_BASE_OPERATOR : public Operator
{
public:
    
    typedef SPL::BeJwtjFsOwjAMBK9EHhS4AFK_04QIhtlCkNo66TtXentLmd3Zm1apXC5sJ5jJKipqlBBqIl5wYj7oDLhpIXZcgbU783irjflqBjJs5Ui7f1zGqD1ax3w7YoDzBJyE2pkv_19nld4tgYrsl069zJZ4WrmX46njfp IPort0Type;
    typedef SPL::BeJwli0sKAjEQBa9k6wgzywE3rhQ9gHSGF23Ij85T8PYG3FVBFYUidtAnwlETnCYS2sm0sybbTHah3b9_1icsL6rwpMdDXD3x8yeeM3gd1n4pm_0Oy15nOJ1abeLvsoQuQ2Yr4diz2uSkPhDxYpC6L OPort0Type;
    
    MY_BASE_OPERATOR();
    
    ~MY_BASE_OPERATOR();
    
    inline void tupleLogic(Tuple & tuple, uint32_t port);
    void processRaw(Tuple & tuple, uint32_t port);
    
    inline void punctLogic(Punctuation const & punct, uint32_t port);
    void processRaw(Punctuation const & punct, uint32_t port);
    void punctPermitProcessRaw(Punctuation const & punct, uint32_t port);
    void punctNoPermitProcessRaw(Punctuation const & punct, uint32_t port);
    
    inline void submit(Tuple & tuple, uint32_t port)
    {
        Operator::submit(tuple, port);
    }
    inline void submit(Punctuation const & punct, uint32_t port)
    {
        Operator::submit(punct, port);
    }
    
    
    
    SPL::boolean lit$0;
    SPL::uint32 lit$1;
    SPL::uint32 lit$2;
    SPL::map<SPL::rstring, SPL::BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ > lit$3;
    
    SPL::map<SPL::rstring, SPL::BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ > state$patientMap;
    
protected:
    Mutex $svMutex;
    typedef std::bitset<2> OPortBitsetType;
    OPortBitsetType $oportBitset;
    Mutex $fpMutex;
    void checkpointStateVariables(NetworkByteBuffer & opstate) const;
    void restoreStateVariables(NetworkByteBuffer & opstate);
    void checkpointStateVariables(Checkpoint & ckpt);
    void resetStateVariables(Checkpoint & ckpt);
    void resetStateVariablesToInitialState();
    bool hasStateVariables() const;
    void resetToInitialStateRaw();
    void checkpointRaw(Checkpoint & ckpt);
    void resetRaw(Checkpoint & ckpt);
private:
    static bool globalInit_;
    static bool globalIniter();
    ParameterMapType paramValues_;
    ParameterMapType& getParameters() { return paramValues_;}
    void addParameterValue(std::string const & param, ConstValueHandle const& value)
    {
        ParameterMapType::iterator it = paramValues_.find(param);
        if (it == paramValues_.end())
            it = paramValues_.insert (std::make_pair (param, ParameterValueListType())).first;
        it->second.push_back(&ParameterValue::create(value));
    }
    void addParameterValue(std::string const & param)
    {
        ParameterMapType::iterator it = paramValues_.find(param);
        if (it == paramValues_.end())
            it = paramValues_.insert (std::make_pair (param, ParameterValueListType())).first;
        it->second.push_back(&ParameterValue::create());
    }
};


class MY_OPERATOR : public MY_BASE_OPERATOR 
{
public:
   MY_OPERATOR() {}
   
       void getCheckpoint(NetworkByteBuffer & opstate) { checkpointStateVariables(opstate); }
       void restoreCheckpoint(NetworkByteBuffer & opstate) { restoreStateVariables(opstate); }
   
   
}; 

} // namespace VitalsCheck_7
} // namespace _Operator
} // namespace SPL

#undef MY_OPERATOR_SCOPE
#undef MY_BASE_OPERATOR
#undef MY_OPERATOR
#endif // SPL_OPER_INSTANCE_VITALSCHECK_7_CUSTOM_3_H_

