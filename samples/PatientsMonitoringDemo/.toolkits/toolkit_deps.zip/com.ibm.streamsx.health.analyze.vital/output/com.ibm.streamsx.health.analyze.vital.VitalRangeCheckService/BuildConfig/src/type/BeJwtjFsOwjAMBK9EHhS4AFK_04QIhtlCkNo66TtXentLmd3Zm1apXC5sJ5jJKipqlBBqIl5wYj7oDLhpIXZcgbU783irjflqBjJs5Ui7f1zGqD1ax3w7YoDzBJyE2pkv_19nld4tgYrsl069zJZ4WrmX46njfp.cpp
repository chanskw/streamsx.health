// t2t4t2s2ids10locationId6devices9patientIdt3s2ids10sourceTypes8deviceId13readingSourcet4I2tst2s6systems4code11readingTypeF5values3uom7reading3obxs3pid


#include "BeJwtjFsOwjAMBK9EHhS4AFK_04QIhtlCkNo66TtXentLmd3Zm1apXC5sJ5jJKipqlBBqIl5wYj7oDLhpIXZcgbU783irjflqBjJs5Ui7f1zGqD1ax3w7YoDzBJyE2pkv_19nld4tgYrsl069zJZ4WrmX46njfp.h"
#include <sstream>

#define SELF BeJwtjFsOwjAMBK9EHhS4AFK_04QIhtlCkNo66TtXentLmd3Zm1apXC5sJ5jJKipqlBBqIl5wYj7oDLhpIXZcgbU783irjflqBjJs5Ui7f1zGqD1ax3w7YoDzBJyE2pkv_19nld4tgYrsl069zJZ4WrmX46njfp

using namespace SPL;

TupleMappings* SELF::mappings_ = SELF::initMappings();

static void addMapping(TupleMappings & tm, TypeOffset & offset,
                       std::string const & name, uint32_t index)
{
    tm.nameToIndex_.insert(std::make_pair(name, index)); 
    tm.indexToName_.push_back(name);
    tm.indexToTypeOffset_.push_back(offset);    
}

static Tuple * initer() { return new SELF(); }

TupleMappings* SELF::initMappings()
{
    instantiators_.insert(std::make_pair("tuple<tuple<tuple<rstring id,rstring locationId> device,rstring patientId,tuple<rstring id,rstring sourceType,rstring deviceId> readingSource,tuple<int64 ts,tuple<rstring system,rstring code> readingType,float64 value,rstring uom> reading> obx,rstring pid>",&initer));
    TupleMappings * tm = new TupleMappings();
#define MY_OFFSETOF(member, base) \
    ((uintptr_t)&reinterpret_cast<Self*>(base)->member) - (uintptr_t)base
   
    // initialize the mappings 
    
    {
        std::string s("obx");
        TypeOffset t(MY_OFFSETOF(obx_, tm), 
                     Meta::Type::typeOf<SPL::BeJwtjFsOgzAMBK_1UPID2ApXyTS8QxRaKBDFiHSRuD4X8zs6serWwmWBes6SoWUqgnnjPifFZL8BFA6lrEqRuiX_1Hyng_1ViDjNo6UyzTeo_1pgFddtjwPKC3wSYmOa9G_0_13R7nynBVlqHxE_1atDPk >(), 
                     &typeid(SPL::BeJwtjFsOgzAMBK_1UPID2ApXyTS8QxRaKBDFiHSRuD4X8zs6serWwmWBes6SoWUqgnnjPifFZL8BFA6lrEqRuiX_1Hyng_1ViDjNo6UyzTeo_1pgFddtjwPKC3wSYmOa9G_0_13R7nynBVlqHxE_1atDPk));
        addMapping(*tm, t, s, 0);
    }
    
    {
        std::string s("pid");
        TypeOffset t(MY_OFFSETOF(pid_, tm), 
                     Meta::Type::typeOf<SPL::rstring >(), 
                     &typeid(SPL::rstring));
        addMapping(*tm, t, s, 1);
    }
    
    return tm;
}

void SELF::deserialize(std::istream & istr, bool withSuffix)
{
   std::string s;
   char c;

   istr >> c; if (!istr) { return; }
   if (c != '{') { istr.setstate(std::ios_base::failbit); return; }
   
   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "obx") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, obx_);
   else
     istr >> obx_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "pid") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, pid_);
   else
     istr >> pid_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   
   if (c != '}') { istr.setstate(std::ios_base::failbit); return; }
}

void SELF::deserializeWithNanAndInfs(std::istream & istr, bool withSuffix)
{
   std::string s;
   char c;

   istr >> c; if (!istr) { return; }
   if (c != '{') { istr.setstate(std::ios_base::failbit); return; }
   
   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "obx") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, obx_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "pid") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, pid_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   
   if (c != '}') { istr.setstate(std::ios_base::failbit); return; }
}

void SELF::serialize(std::ostream & ostr) const
{
    ostr << '{'
         << "obx=" << get_obx()  << ","
         << "pid=" << get_pid()  
         << '}';
}

void SELF::serializeWithPrecision(std::ostream & ostr) const
{
    ostr << '{';
    SPL::serializeWithPrecision(ostr << "obx=", get_obx()) << ",";
    SPL::serializeWithPrecision(ostr << "pid=", get_pid()) ;
    ostr << '}';
}

SELF& SELF::clear()
{
    get_obx().clear();
    SPL::rstring().swap(get_pid());

    return *this;
}

void SELF::normalizeBoundedSetsAndMaps()
{
    SPL::normalizeBoundedSetsAndMaps(*this);
}


