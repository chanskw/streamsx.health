// t1t11i3ageb5alerti11bpDiastolici10bpSystolicf9heartRatef9hrAveragelr8messagesr4namer8roomInfoi4spO2f11temperature9o_Patient


#include "BeJwli8EKAjEMBX_1J6Aq7xwUvnhT9AEmXVw20TUmi4N9b8DYDM0FBJAd_0Ih25wEKIUj8Je2iRTWiX_0v37l7y8wBY3Dgy09QMbX7G5wn2Q29S4wmZTreeWVSbvl30mCtQ_04ngbFn1cOQQtfhZfC6R.h"
#include <sstream>

#define SELF BeJwli8EKAjEMBX_1J6Aq7xwUvnhT9AEmXVw20TUmi4N9b8DYDM0FBJAd_0Ih25wEKIUj8Je2iRTWiX_0v37l7y8wBY3Dgy09QMbX7G5wn2Q29S4wmZTreeWVSbvl30mCtQ_04ngbFn1cOQQtfhZfC6R

using namespace SPL;

TupleMappings* SELF::mappings_ = SELF::initMappings();

static void addMapping(TupleMappings & tm, TypeOffset & offset,
                       std::string const & name, uint32_t index)
{
    tm.nameToIndex_.insert(std::make_pair(name, index)); 
    tm.indexToName_.push_back(name);
    tm.indexToTypeOffset_.push_back(offset);    
}

static Tuple * initer() { return new SELF(); }

TupleMappings* SELF::initMappings()
{
    instantiators_.insert(std::make_pair("tuple<tuple<int32 age,boolean alert,int32 bpDiastolic,int32 bpSystolic,float32 heartRate,float32 hrAverage,list<ustring> messages,ustring name,ustring roomInfo,int32 spO2,float32 temperature> o_Patient>",&initer));
    TupleMappings * tm = new TupleMappings();
#define MY_OFFSETOF(member, base) \
    ((uintptr_t)&reinterpret_cast<Self*>(base)->member) - (uintptr_t)base
   
    // initialize the mappings 
    
    {
        std::string s("o_Patient");
        TypeOffset t(MY_OFFSETOF(o_Patient_, tm), 
                     Meta::Type::typeOf<SPL::BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ >(), 
                     &typeid(SPL::BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ));
        addMapping(*tm, t, s, 0);
    }
    
    return tm;
}

void SELF::deserialize(std::istream & istr, bool withSuffix)
{
   std::string s;
   char c;

   istr >> c; if (!istr) { return; }
   if (c != '{') { istr.setstate(std::ios_base::failbit); return; }
   
   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "o_Patient") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, o_Patient_);
   else
     istr >> o_Patient_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   
   if (c != '}') { istr.setstate(std::ios_base::failbit); return; }
}

void SELF::deserializeWithNanAndInfs(std::istream & istr, bool withSuffix)
{
   std::string s;
   char c;

   istr >> c; if (!istr) { return; }
   if (c != '{') { istr.setstate(std::ios_base::failbit); return; }
   
   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "o_Patient") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, o_Patient_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   
   if (c != '}') { istr.setstate(std::ios_base::failbit); return; }
}

void SELF::serialize(std::ostream & ostr) const
{
    ostr << '{'
         << "o_Patient=" << get_o_Patient()  
         << '}';
}

void SELF::serializeWithPrecision(std::ostream & ostr) const
{
    ostr << '{';
    SPL::serializeWithPrecision(ostr << "o_Patient=", get_o_Patient()) ;
    ostr << '}';
}

SELF& SELF::clear()
{
    get_o_Patient().clear();

    return *this;
}

void SELF::normalizeBoundedSetsAndMaps()
{
    SPL::normalizeBoundedSetsAndMaps(*this);
}


