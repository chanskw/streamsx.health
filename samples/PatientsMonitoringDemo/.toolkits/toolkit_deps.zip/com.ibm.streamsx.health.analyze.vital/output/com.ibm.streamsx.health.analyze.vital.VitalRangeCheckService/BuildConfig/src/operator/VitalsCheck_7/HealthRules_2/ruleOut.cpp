// eJzdWG1zmkoUHr72VzCdfjDTXGHBF_0S2mcGoiUaiBE01X5hFVt0EFgKLxLT573dBYpLGpvXednQuOo4c9pw959lznt1DFLjFmGIX06WqHscR9T0OcCL7VLj3xaKw_0k5jMqHYJ8LE9wRse0JEQwS96E6YI_0jSuQAJdJf3SFhgCl1hhggKIUWOAB1n4OsoiuAMRcX5_099hM0JUc1FIX5qjywAJddRJXCxGZ9p106jD2k0lmd0vk6Yczo3a7NQ8aUly_01opD5T_0_0ERuXdZb4yF2qEYStzkgx2NTijwxWtr24BTOZbtmATyJupUwCXSnMWrId8oSIV2eOYCUAs8Se0tQJr0OgDbqLiLfiA1pHJYcfC_1F5k1_13rgbB8eV7g8dVZqpo3p9ZIFORbut3iXDBZkPalrTG10mkjgYerh0XrOVxrihi616R3MssT2XyknzrD28VjpIwheDL3hkiQu56laXSlIfy43ZUqwZuj2qnpQTIhlSzSwl3tUgROjLpWkvXFn0jqlhiSUys1sETHqGQafzq_0lx5eItV5NrzchcpRej2_0G0gU1HW0j6vDsaYqicji_0ZF5OThS5rg_1Y1C3xhmkY07gTdCnDM69YovjptdSxQJcxE_0R4NFaehGa0K86M_1O3OTUDYm5bKY_0LF9JiNK76IaKVngKmhpVbPXa1ig2WgE_0q1mbHZyGZ63fflcC_1v3zUWnawHnvKsHve6gLTr6QjeVZX2iHd_0gWSilBgAXUZZOH_1wFDDmz31XVfV0TjpNEjhXoB3Hl59T1IZUlLpOBlYwVbojJbCWTVjJM1qPkV5LSBr3yBvuVDeOqr6wpryS1DXpAfDUMbPIfSJsClTcJN4UBNsUBKpuE1U3qeTDxczdrL2WcMPc99MhY0PEwEWaYrimsmFNYBL3ARZHQhxQjQiPdJ5j66VwN5PlCkfq_0e4NplHJgkXFg8TsDxZwDiysOdCCFHPEJSvk5ZWkc_0OE6L_1aT_1DiPC7P95Os7nl1PRVecIWr5Vg5N4YD_1zOfhZE_1w05O_1M0085QuFH6tn9wy1kF6wIczcJz6rmYMDPlNPr6_1rf_0mlqgx1lo02_03nEXVVXwKtqjryqZtCr6nr_1YYPzDegNb3Kf_1_1NUL_1bPN_0Y7zIIFz6Z9eALtZ6jZQQNDtvO7eMJwO8pMyQf8t2_18zzXN5XeK0sEfQHw7GEq_1C_13tFvrhl9OUIi9I54hDtMatvHPYKjuHbbtEXRW4sn2irhSru0_1U2s4R_1wlsUdCT1oCBP8GlWxIc2Dli229B4Ne49LniihLAHnAp2D2ZbsemOeaVX8L8OyL_0vNIt7wHs1V3C7vj8V36veyI_0XTl2YtxrJ9_0EnI9i28OUL6SR5IuuMPEDn8yxiwoiW5WHd_1mpOauDx1i3aHQLQfqS5S_1ADtdPWG2hr6pfMHH8RIfhDQp_1XBWPsaQB44k1YZv0p2y6fjp_1DNP3PKp6Cd0YHf2bOF76kYLZJg66Kxx8BI8FU3uRxQw5wK1bCI7GrA37lDVvPKu_1Q5v1XQgSHqaVcbiSPztcrCWPh4bDvG3k1yT9JAm1Bas1ZtTFLOq8lTzivbzUD3MJT6CH1jeh73ttMvXzmdJ9dm3xGSkdZV2e_17rL279kz_1o8wPn_1A8xFBvo_1gFLCAf


#include "./ruleOut.h"
using namespace SPL::_Operator::VitalsCheck_7::HealthRules_2;

#include <SPL/Runtime/Function/SPLFunctions.h>
#include <SPL/Runtime/Operator/Port/Punctuation.h>

#include <string>

#define MY_OPERATOR_SCOPE SPL::_Operator::VitalsCheck_7::HealthRules_2
#define MY_BASE_OPERATOR ruleOut_Base
#define MY_OPERATOR ruleOut$OP



static SPL::Operator * initer() { return new MY_OPERATOR_SCOPE::MY_OPERATOR(); }
bool MY_BASE_OPERATOR::globalInit_ = MY_BASE_OPERATOR::globalIniter();
bool MY_BASE_OPERATOR::globalIniter() {
    instantiators_.insert(std::make_pair("VitalsCheck_7::HealthRules_2::ruleOut",&initer));
    return true;
}

template<class T> static void initRTC (SPL::Operator& o, T& v, const char * n) {
    SPL::ValueHandle vh = v;
    o.getContext().getRuntimeConstantValue(vh, n);
}

MY_BASE_OPERATOR::MY_BASE_OPERATOR()
 : Operator() {
    uint32_t index = getIndex();
    initRTC(*this, lit$0, "lit$0");
    initRTC(*this, lit$1, "lit$1");
    initRTC(*this, lit$2, "lit$2");
    initRTC(*this, lit$3, "lit$3");
    initRTC(*this, lit$4, "lit$4");
    initRTC(*this, lit$5, "lit$5");
    initRTC(*this, lit$6, "lit$6");
    initRTC(*this, lit$7, "lit$7");
    initRTC(*this, lit$8, "lit$8");
    initRTC(*this, lit$9, "lit$9");
    initRTC(*this, lit$10, "lit$10");
    initRTC(*this, lit$11, "lit$11");
    initRTC(*this, lit$12, "lit$12");
    initRTC(*this, lit$13, "lit$13");
    initRTC(*this, lit$14, "lit$14");
    initRTC(*this, lit$15, "lit$15");
    initRTC(*this, lit$16, "lit$16");
    initRTC(*this, lit$17, "lit$17");
    initRTC(*this, lit$18, "lit$18");
    initRTC(*this, lit$19, "lit$19");
    (void) getParameters(); // ensure thread safety by initializing here
    $oportBitset = OPortBitsetType(std::string("01"));
}
MY_BASE_OPERATOR::~MY_BASE_OPERATOR()
{
    for (ParameterMapType::const_iterator it = paramValues_.begin(); it != paramValues_.end(); it++) {
        const ParameterValueListType& pvl = it->second;
        for (ParameterValueListType::const_iterator it2 = pvl.begin(); it2 != pvl.end(); it2++) {
            delete *it2;
        }
    }
}

void MY_BASE_OPERATOR::tupleLogic(Tuple & tuple, uint32_t port) {
    IPort0Type & iport$0 = static_cast<IPort0Type  &>(tuple);
    AutoPortMutex $apm($svMutex, *this);
    
{
    state$ovar.get_o_Patient() = iport$0.get_i_Patient();
    if ((state$ovar.get_o_Patient().get_heartRate() < lit$0)) 
        {
            ::com::ibm::streamsx::health::analyze::vital::generated::setAlert(state$ovar.get_o_Patient());
            ::com::ibm::streamsx::health::analyze::vital::generated::addToMessages(state$ovar.get_o_Patient(), lit$1);
        }
    if (((state$ovar.get_o_Patient().get_bpDiastolic() > lit$3) || (state$ovar.get_o_Patient().get_bpSystolic() > lit$2))) 
        {
            ::com::ibm::streamsx::health::analyze::vital::generated::addToMessages(state$ovar.get_o_Patient(), lit$4);
            ::com::ibm::streamsx::health::analyze::vital::generated::setAlert(state$ovar.get_o_Patient());
        }
    if ((state$ovar.get_o_Patient().get_temperature() > lit$5)) 
        {
            ::com::ibm::streamsx::health::analyze::vital::generated::addToMessages(state$ovar.get_o_Patient(), lit$6);
            ::com::ibm::streamsx::health::analyze::vital::generated::setAlert(state$ovar.get_o_Patient());
        }
    if (((state$ovar.get_o_Patient().get_bpDiastolic() < lit$8) || (state$ovar.get_o_Patient().get_bpSystolic() < lit$7))) 
        {
            ::com::ibm::streamsx::health::analyze::vital::generated::addToMessages(state$ovar.get_o_Patient(), lit$9);
            ::com::ibm::streamsx::health::analyze::vital::generated::setAlert(state$ovar.get_o_Patient());
        }
    if ((state$ovar.get_o_Patient().get_spO2() < lit$10)) 
        {
            ::com::ibm::streamsx::health::analyze::vital::generated::addToMessages(state$ovar.get_o_Patient(), lit$11);
            ::com::ibm::streamsx::health::analyze::vital::generated::setAlert(state$ovar.get_o_Patient());
        }
    if (((state$ovar.get_o_Patient().get_heartRate() < lit$13) || (state$ovar.get_o_Patient().get_heartRate() > lit$12))) 
        {
            ::com::ibm::streamsx::health::analyze::vital::generated::addToMessages(state$ovar.get_o_Patient(), lit$14);
            ::com::ibm::streamsx::health::analyze::vital::generated::setAlert(state$ovar.get_o_Patient());
        }
    if (((state$ovar.get_o_Patient().get_temperature() < lit$16) || (state$ovar.get_o_Patient().get_temperature() >= lit$15))) 
        {
            ::com::ibm::streamsx::health::analyze::vital::generated::addToMessages(state$ovar.get_o_Patient(), lit$17);
            ::com::ibm::streamsx::health::analyze::vital::generated::setAlert(state$ovar.get_o_Patient());
        }
    do { SPL::BeJwli8EKAjEMBX_1J6Aq7xwUvnhT9AEmXVw20TUmi4N9b8DYDM0FBJAd_0Ih25wEKIUj8Je2iRTWiX_0v37l7y8wBY3Dgy09QMbX7G5wn2Q29S4wmZTreeWVSbvl30mCtQ_04ngbFn1cOQQtfhZfC6R temp = SPL::BeJwli8EKAjEMBX_1J6Aq7xwUvnhT9AEmXVw20TUmi4N9b8DYDM0FBJAd_0Ih25wEKIUj8Je2iRTWiX_0v37l7y8wBY3Dgy09QMbX7G5wn2Q29S4wmZTreeWVSbvl30mCtQ_04ngbFn1cOQQtfhZfC6R(state$ovar.get_o_Patient()); submit (temp, lit$18); } while(0);
}

}


void MY_BASE_OPERATOR::processRaw(Tuple & tuple, uint32_t port) {
    tupleLogic (tuple, port);
    static_cast<MY_OPERATOR_SCOPE::MY_OPERATOR*>(this)->MY_OPERATOR::process(tuple, port);
}


void MY_BASE_OPERATOR::punctLogic(Punctuation const & punct, uint32_t port) {
    AutoPortMutex $apm($svMutex, *this);
    
{
    if ((SPL::BeJyrNIo3NArPzEvJL_1dNLMpOLTI0dMvMS8yBcACkegr2(punct-1) == SPL::BeJyrNIo3NArPzEvJL_1dNLMpOLTI0dMvMS8yBcACkegr2::WindowMarker)) 
        {
            submit (static_cast<SPL::Punctuation::Value>(SPL::BeJyrNIo3NArPzEvJL_1dNLMpOLTI0dMvMS8yBcACkegr2::WindowMarker.getIndex()+1), lit$19);
        }
}

}

void MY_BASE_OPERATOR::punctPermitProcessRaw(Punctuation const & punct, uint32_t port) {
    {
        punctNoPermitProcessRaw(punct, port);
    }
}

void MY_BASE_OPERATOR::punctNoPermitProcessRaw(Punctuation const & punct, uint32_t port) {
    switch(punct) {
    case Punctuation::WindowMarker:
        punctLogic(punct, port);
        process(punct, port);
        break;
    case Punctuation::FinalMarker:
        punctLogic(punct, port);
        
        if (punct == Punctuation::FinalMarker) {
            process(punct, port);
            bool forward = false;
            {
                AutoPortMutex $apm($fpMutex, *this);
                $oportBitset.reset(port);
                if ($oportBitset.none()) {
                    $oportBitset.set(1);
                    forward=true;
                }
            }
            if(forward)
                submit(punct, 0);
            return;
        }
        process(punct, port);
        break;
    case Punctuation::DrainMarker:
    case Punctuation::ResetMarker:
    case Punctuation::ResumeMarker:
        break;
    case Punctuation::SwitchMarker:
        break;
    default:
        break;
    }
}

void MY_BASE_OPERATOR::processRaw(Punctuation const & punct, uint32_t port) {
    switch(port) {
    case 0:
        punctNoPermitProcessRaw(punct, port);
        break;
    }
}



void MY_BASE_OPERATOR::checkpointStateVariables(NetworkByteBuffer & opstate) const {
    opstate << state$ovar;
}

void MY_BASE_OPERATOR::restoreStateVariables(NetworkByteBuffer & opstate) {
    opstate >> state$ovar;
}

void MY_BASE_OPERATOR::checkpointStateVariables(Checkpoint & ckpt) {
    ckpt << state$ovar;
}

void MY_BASE_OPERATOR::resetStateVariables(Checkpoint & ckpt) {
    ckpt >> state$ovar;
}

void MY_BASE_OPERATOR::resetStateVariablesToInitialState() {
    state$ovar = SPL::BeJwli8EKAjEMBX_1J6Aq7xwUvnhT9AEmXVw20TUmi4N9b8DYDM0FBJAd_0Ih25wEKIUj8Je2iRTWiX_0v37l7y8wBY3Dgy09QMbX7G5wn2Q29S4wmZTreeWVSbvl30mCtQ_04ngbFn1cOQQtfhZfC6R();
}

bool MY_BASE_OPERATOR::hasStateVariables() const {
    return true;
}

void MY_BASE_OPERATOR::resetToInitialStateRaw() {
    AutoMutex $apm($svMutex);
    StateHandler *sh = getContext().getStateHandler();
    if (sh != NULL) {
        sh->resetToInitialState();
    }
    resetStateVariablesToInitialState();
}

void MY_BASE_OPERATOR::checkpointRaw(Checkpoint & ckpt) {
    AutoMutex $apm($svMutex);
    StateHandler *sh = getContext().getStateHandler();
    if (sh != NULL) {
        sh->checkpoint(ckpt);
    }
    checkpointStateVariables(ckpt);
}

void MY_BASE_OPERATOR::resetRaw(Checkpoint & ckpt) {
    AutoMutex $apm($svMutex);
    StateHandler *sh = getContext().getStateHandler();
    if (sh != NULL) {
        sh->reset(ckpt);
    }
    resetStateVariables(ckpt);
}



