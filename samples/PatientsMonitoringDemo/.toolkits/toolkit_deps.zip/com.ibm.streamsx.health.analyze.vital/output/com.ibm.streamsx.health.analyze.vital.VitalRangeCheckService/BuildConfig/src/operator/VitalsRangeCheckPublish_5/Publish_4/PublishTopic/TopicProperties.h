// eJyVUttu4jAQlf8EVX0ACdkNvFR_0Y1m2ZbksKqh9rEw6m0zXsVN7Wha_0vnZC2F6otlWiZOLMnDlzzvhScwdaEVqjtJQ_1UBM4lrCzcPXZCeficP9_0NGnME6ktBK4L4cmBKvxfkYPSlAsVILY7EE9ISocsYyAl67xY_1VqMh7fX49VgurwazC9Gw8vRcMLzk882IFtabbNtDDAVHmgVg7kqYOFsCY4Q_1Ds82pYgvsHPjZstN735LHvY_0fPpFM1kN_1KXg6HLBzcuViXMkyI4dSlbLqZSoqF_072WYMCkDqfC5Do_0GlpQNryrCNPw6yqytkU7Puq3jILV6Uu7lk7LSL_0Y2Akp5XMF2p9tqVzTX1mpQphMbJd1WfPU6wcCqcT2JCx3RZKw6S9jLsvqs9yaPidwW0Jig7go0IkM6uML3tntVlBq8WIQtAkN_0Zg0G1gHjOxRWcApN_1iD5aCsPs_1M3AHw_1OK_135k6RYsYaiCsYFxFL6w5T_1M9OhsxVy8tC7b23ZllP00wVAe2XAT_0ASl4rdqDKM6DbfxXtTuj6DJN4B9v




#ifndef SPL_OPER_INSTANCE_VITALSRANGECHECKPUBLISH_5_PUBLISH_4_PUBLISHTOPIC_TOPICPROPERTIES_H_
#define SPL_OPER_INSTANCE_VITALSRANGECHECKPUBLISH_5_PUBLISH_4_PUBLISHTOPIC_TOPICPROPERTIES_H_

#include <SPL/Runtime/Operator/Operator.h>
#include <SPL/Runtime/Operator/ParameterValue.h>
#include <SPL/Runtime/Operator/OperatorContext.h>
#include <SPL/Runtime/Operator/OperatorMetrics.h>
#include <SPL/Runtime/Operator/Port/AutoPortMutex.h>
#include <SPL/Runtime/Operator/State/StateHandler.h>
#include <SPL/Runtime/ProcessingElement/PE.h>
#include <SPL/Runtime/Type/SPLType.h>
#include <SPL/Runtime/Utility/CV.h>
using namespace UTILS_NAMESPACE;

#include "../../../../function/com/ibm/streamsx/health/analyze/vital/connectors/TOPIC_VITALSRANGECHECK.h"
#include "../../../../function/com/ibm/streamsx/topology/topic/setTopicNameProperties.h"
#include "../../../../type/BeJwrMSw2NMgqzs8LLinKzEsHACrhAWr.h"

#include <bitset>

#define MY_OPERATOR TopicProperties$OP
#define MY_BASE_OPERATOR TopicProperties_Base
#define MY_OPERATOR_SCOPE SPL::_Operator::VitalsRangeCheckPublish_5::Publish_4::PublishTopic

namespace SPL {
namespace _Operator {
namespace VitalsRangeCheckPublish_5 {
namespace Publish_4 {
namespace PublishTopic {

class MY_BASE_OPERATOR : public Operator
{
public:
    
    typedef SPL::BeJwrMSw2NMgqzs8LLinKzEsHACrhAWr IPort0Type;
    typedef SPL::BeJwrMSw2NMgqzs8LLinKzEsHACrhAWr OPort0Type;
    
    MY_BASE_OPERATOR();
    
    ~MY_BASE_OPERATOR();
    
    inline void tupleLogic(Tuple const & tuple, uint32_t port);
    void processRaw(Tuple const & tuple, uint32_t port);
    
    inline void punctLogic(Punctuation const & punct, uint32_t port);
    void processRaw(Punctuation const & punct, uint32_t port);
    void punctPermitProcessRaw(Punctuation const & punct, uint32_t port);
    void punctNoPermitProcessRaw(Punctuation const & punct, uint32_t port);
    
    
    
    SPL::rstring lit$0;
    SPL::boolean lit$1;
    SPL::rstring lit$2;
    
    SPL::int32 state$rc;
    
protected:
    Mutex $svMutex;
    typedef std::bitset<2> OPortBitsetType;
    OPortBitsetType $oportBitset;
    Mutex $fpMutex;
    void checkpointStateVariables(NetworkByteBuffer & opstate) const;
    void restoreStateVariables(NetworkByteBuffer & opstate);
    void checkpointStateVariables(Checkpoint & ckpt);
    void resetStateVariables(Checkpoint & ckpt);
    void resetStateVariablesToInitialState();
    bool hasStateVariables() const;
    void resetToInitialStateRaw();
    void checkpointRaw(Checkpoint & ckpt);
    void resetRaw(Checkpoint & ckpt);
private:
    static bool globalInit_;
    static bool globalIniter();
    ParameterMapType paramValues_;
    ParameterMapType& getParameters() { return paramValues_;}
    void addParameterValue(std::string const & param, ConstValueHandle const& value)
    {
        ParameterMapType::iterator it = paramValues_.find(param);
        if (it == paramValues_.end())
            it = paramValues_.insert (std::make_pair (param, ParameterValueListType())).first;
        it->second.push_back(&ParameterValue::create(value));
    }
    void addParameterValue(std::string const & param)
    {
        ParameterMapType::iterator it = paramValues_.find(param);
        if (it == paramValues_.end())
            it = paramValues_.insert (std::make_pair (param, ParameterValueListType())).first;
        it->second.push_back(&ParameterValue::create());
    }
};


class MY_OPERATOR : public MY_BASE_OPERATOR
{
public:
   MY_OPERATOR() {}
  
   void process(Tuple const & tuple, uint32_t port);
   void process(Punctuation const & punct, uint32_t port);
   
       void getCheckpoint(NetworkByteBuffer & opstate) { checkpointStateVariables(opstate); }
       void restoreCheckpoint(NetworkByteBuffer & opstate) { restoreStateVariables(opstate); }
   
}; 

} // namespace VitalsRangeCheckPublish_5
} // namespace Publish_4
} // namespace PublishTopic
} // namespace _Operator
} // namespace SPL

#undef MY_OPERATOR_SCOPE
#undef MY_BASE_OPERATOR
#undef MY_OPERATOR
#endif // SPL_OPER_INSTANCE_VITALSRANGECHECKPUBLISH_5_PUBLISH_4_PUBLISHTOPIC_TOPICPROPERTIES_H_

