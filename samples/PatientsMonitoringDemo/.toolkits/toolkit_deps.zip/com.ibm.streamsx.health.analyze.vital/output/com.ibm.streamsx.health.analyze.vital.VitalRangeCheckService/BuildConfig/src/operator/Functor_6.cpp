// eJzNU12PmkAUDf9k0_1ShTTYgyqJumk1g0RVBVwW66gsZZcSBYQaZQYRfX3RdN21N0zRpsuEBcj_1OvZxzLkuxmEEMOKIE4Pv7fk7WnGaCLDTqRxU_0iaLEyxRKOhwW2chRmmVcpONoSivU4U6sjHfOwbRXS9NxWrbba8uu1tPowLOMVNx_0_0q2fNi1VYXZMxra7HFZxd6hPtYYbLlrXq1_0nuWbpdZ_1tERlVvjweaVPdWBar6krLptewUJxfGzR2p8yJ5VG5PtiGGjNn4FW2tx9ZXoOPUXtcFZ5Gnzqzx_1w3XB712XNYaSPd8mVvYhpNLZ2XrtOZHmbA0o0_0Gjiz3FDmnYqpDGYvRfKiQ6Y69MXbhYREE7TpL_02O3tdUnPV2sxzNfXlQktCXvyMjGlPVKysXUl9Ow34Q8KiYWI_0twlkkz6D75Dd8uTVrk5Lo3_1FucOj5MuDGJL6_0ZxEd9_0z2BltH0fqW31Cm5pbjx7ieorp8Dgm3k6C1TGSQzh_1v2PAuGloo3WFd35n4rlhEbWrY29ScL9fhymt3WiiLNninR0N256H2Rq6edoYMDq2ivaBGpQ_1LXjON977cJThQeLjIGG6o3Wq4VF6yZK6oJNqczHC0lCBtaQIlxjMIEgaCBBEpRPwtcBC3EGC_0lRhIUgyZNKmtWW_1MRpSg2piIhAZMqCRySnGMOJPWNBHRKhF_1ARBB7eeyguIecYClAHAgEErgcYejuVFKM_165ITgT_0_17_0A2ssICF7JU5QhADu0RoKPK_0p_0ZbVf1zTcYOC27dPTNenSzaDByF9Jc4MhHNWqPkJ6rdD8_0xPIOyUd2tPXUKvc4_0oZ4xzNyJcVW44u_10ZjJWMw_0TSvaYBfLg5d55wN5iCY_0ce4Px9Sk6Th5M29Ko2H9PXQlLr0xTo6nDm5G_1EORN6SV20uv0nVW5_0Uvb2f2nzVnYUSf74h_1N_04yl6P4LL6m_0BS5kYQu5flPjytXbiDxbiG9b


#include "./Functor_6.h"
using namespace SPL::_Operator;

#include <SPL/Runtime/Function/SPLFunctions.h>
#include <SPL/Runtime/Operator/Port/Punctuation.h>

#include <string>

#define MY_OPERATOR_SCOPE SPL::_Operator
#define MY_BASE_OPERATOR Functor_6_Base
#define MY_OPERATOR Functor_6$OP




void MY_OPERATOR_SCOPE::MY_OPERATOR::process(Tuple const & tuple, uint32_t port) 
{
   IPort0Type const & iport$0 = static_cast<IPort0Type const&>(tuple);
   if (! (1) ) 
       return;
   { OPort0Type otuple(iport$0, iport$0.get_patientId()); submit (otuple, 0);
 }
   
}

void MY_OPERATOR_SCOPE::MY_OPERATOR::process(Punctuation const & punct, uint32_t port) 
{
   forwardWindowPunctuation(punct);
}

static SPL::Operator * initer() { return new MY_OPERATOR_SCOPE::MY_OPERATOR(); }
bool MY_BASE_OPERATOR::globalInit_ = MY_BASE_OPERATOR::globalIniter();
bool MY_BASE_OPERATOR::globalIniter() {
    instantiators_.insert(std::make_pair("Functor_6",&initer));
    return true;
}

template<class T> static void initRTC (SPL::Operator& o, T& v, const char * n) {
    SPL::ValueHandle vh = v;
    o.getContext().getRuntimeConstantValue(vh, n);
}

MY_BASE_OPERATOR::MY_BASE_OPERATOR()
 : Operator() {
    uint32_t index = getIndex();
    (void) getParameters(); // ensure thread safety by initializing here
    $oportBitset = OPortBitsetType(std::string("01"));
}
MY_BASE_OPERATOR::~MY_BASE_OPERATOR()
{
    for (ParameterMapType::const_iterator it = paramValues_.begin(); it != paramValues_.end(); it++) {
        const ParameterValueListType& pvl = it->second;
        for (ParameterValueListType::const_iterator it2 = pvl.begin(); it2 != pvl.end(); it2++) {
            delete *it2;
        }
    }
}

void MY_BASE_OPERATOR::tupleLogic(Tuple const & tuple, uint32_t port) {
}


void MY_BASE_OPERATOR::processRaw(Tuple const & tuple, uint32_t port) {
    tupleLogic (tuple, port);
    static_cast<MY_OPERATOR_SCOPE::MY_OPERATOR*>(this)->MY_OPERATOR::process(tuple, port);
}


void MY_BASE_OPERATOR::punctLogic(Punctuation const & punct, uint32_t port) {
}

void MY_BASE_OPERATOR::punctPermitProcessRaw(Punctuation const & punct, uint32_t port) {
    {
        punctNoPermitProcessRaw(punct, port);
    }
}

void MY_BASE_OPERATOR::punctNoPermitProcessRaw(Punctuation const & punct, uint32_t port) {
    switch(punct) {
    case Punctuation::WindowMarker:
        punctLogic(punct, port);
        process(punct, port);
        break;
    case Punctuation::FinalMarker:
        punctLogic(punct, port);
        
        if (punct == Punctuation::FinalMarker) {
            process(punct, port);
            bool forward = false;
            {
                AutoPortMutex $apm($fpMutex, *this);
                $oportBitset.reset(port);
                if ($oportBitset.none()) {
                    $oportBitset.set(1);
                    forward=true;
                }
            }
            if(forward)
                submit(punct, 0);
            return;
        }
        process(punct, port);
        break;
    case Punctuation::DrainMarker:
    case Punctuation::ResetMarker:
    case Punctuation::ResumeMarker:
        break;
    case Punctuation::SwitchMarker:
        break;
    default:
        break;
    }
}

void MY_BASE_OPERATOR::processRaw(Punctuation const & punct, uint32_t port) {
    switch(port) {
    case 0:
        punctNoPermitProcessRaw(punct, port);
        break;
    }
}



void MY_BASE_OPERATOR::checkpointStateVariables(NetworkByteBuffer & opstate) const {
}

void MY_BASE_OPERATOR::restoreStateVariables(NetworkByteBuffer & opstate) {
}

void MY_BASE_OPERATOR::checkpointStateVariables(Checkpoint & ckpt) {
}

void MY_BASE_OPERATOR::resetStateVariables(Checkpoint & ckpt) {
}

void MY_BASE_OPERATOR::resetStateVariablesToInitialState() {
}

bool MY_BASE_OPERATOR::hasStateVariables() const {
    return false;
}

void MY_BASE_OPERATOR::resetToInitialStateRaw() {
    AutoMutex $apm($svMutex);
    StateHandler *sh = getContext().getStateHandler();
    if (sh != NULL) {
        sh->resetToInitialState();
    }
    resetStateVariablesToInitialState();
}

void MY_BASE_OPERATOR::checkpointRaw(Checkpoint & ckpt) {
    AutoMutex $apm($svMutex);
    StateHandler *sh = getContext().getStateHandler();
    if (sh != NULL) {
        sh->checkpoint(ckpt);
    }
    checkpointStateVariables(ckpt);
}

void MY_BASE_OPERATOR::resetRaw(Checkpoint & ckpt) {
    AutoMutex $apm($svMutex);
    StateHandler *sh = getContext().getStateHandler();
    if (sh != NULL) {
        sh->reset(ckpt);
    }
    resetStateVariables(ckpt);
}



