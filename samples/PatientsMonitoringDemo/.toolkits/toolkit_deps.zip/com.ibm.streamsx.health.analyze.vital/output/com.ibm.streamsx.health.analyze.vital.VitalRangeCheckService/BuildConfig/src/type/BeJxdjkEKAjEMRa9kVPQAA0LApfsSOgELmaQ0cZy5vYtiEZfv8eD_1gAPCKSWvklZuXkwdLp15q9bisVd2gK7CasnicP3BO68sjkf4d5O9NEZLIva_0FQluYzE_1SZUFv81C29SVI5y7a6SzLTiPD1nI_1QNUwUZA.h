// t10I13__spl_versions16__spl_exportTypes11__spl_topicls17__spl_topicLevelsI21__spl_topicLevelCounts17__spl_allowFilterI13__spl_channelI17__spl_maxChannelsI14__spl_randomIds11__spl_class


#ifndef BEJXDJKEKAJEMRA9KVPQAA0LAPFSSOGELMAQ0CZY5VYTIEZFV8ED_1GAPCKSWVKLZUXKWDLP15Q9BISVD2GK7CASNICP3BO68SJKF4D5O9NEZLIVA_0FQLUYZE_1SZUFV81C29SVI5Y7A6SZLTIPD1NI_1QNUWUZA_H_
#define BEJXDJKEKAJEMRA9KVPQAA0LAPFSSOGELMAQ0CZY5VYTIEZFV8ED_1GAPCKSWVKLZUXKWDLP15Q9BISVD2GK7CASNICP3BO68SJKF4D5O9NEZLIVA_0FQLUYZE_1SZUFV81C29SVI5Y7A6SZLTIPD1NI_1QNUWUZA_H_

#include <SPL/Runtime/Type/Tuple.h>
#include <SPL/Runtime/Type/PrimitiveType.h>
#include <SPL/Runtime/Type/CollectionType.h>
#include <SPL/Runtime/Serialization/NetworkByteBuffer.h>
#include <SPL/Runtime/Serialization/NativeByteBuffer.h>
#include <SPL/Runtime/Serialization/VirtualByteBuffer.h>



#define SELF BeJxdjkEKAjEMRa9kVPQAA0LApfsSOgELmaQ0cZy5vYtiEZfv8eD_1gAPCKSWvklZuXkwdLp15q9bisVd2gK7CasnicP3BO68sjkf4d5O9NEZLIva_0FQluYzE_1SZUFv81C29SVI5y7a6SzLTiPD1nI_1QNUwUZA

namespace SPL {

class SELF : public Tuple
{
public:
    static const bool facade = false;

    typedef SELF Self;
    
    typedef SPL::int64 __spl_version_type;
    typedef SPL::rstring __spl_exportType_type;
    typedef SPL::rstring __spl_topic_type;
    typedef SPL::list<SPL::rstring > __spl_topicLevels_type;
    typedef SPL::int64 __spl_topicLevelCount_type;
    typedef SPL::rstring __spl_allowFilter_type;
    typedef SPL::int64 __spl_channel_type;
    typedef SPL::int64 __spl_maxChannels_type;
    typedef SPL::int64 __spl_randomId_type;
    typedef SPL::rstring __spl_class_type;

    enum { num_attributes = 10 } ;
    
    SELF() : Tuple(), __spl_version_(), __spl_exportType_(), __spl_topic_(), __spl_topicLevels_(), __spl_topicLevelCount_(), __spl_allowFilter_(), __spl_channel_(), __spl_maxChannels_(), __spl_randomId_(), __spl_class_() {}
    SELF(const Self & ot) : Tuple(), __spl_version_(ot.__spl_version_), __spl_exportType_(ot.__spl_exportType_), __spl_topic_(ot.__spl_topic_), __spl_topicLevels_(ot.__spl_topicLevels_), __spl_topicLevelCount_(ot.__spl_topicLevelCount_), __spl_allowFilter_(ot.__spl_allowFilter_), __spl_channel_(ot.__spl_channel_), __spl_maxChannels_(ot.__spl_maxChannels_), __spl_randomId_(ot.__spl_randomId_), __spl_class_(ot.__spl_class_) 
      { constructPayload(ot); }
    SELF(const __spl_version_type & ___spl_version, const __spl_exportType_type & ___spl_exportType, const __spl_topic_type & ___spl_topic, const __spl_topicLevels_type & ___spl_topicLevels, const __spl_topicLevelCount_type & ___spl_topicLevelCount, const __spl_allowFilter_type & ___spl_allowFilter, const __spl_channel_type & ___spl_channel, const __spl_maxChannels_type & ___spl_maxChannels, const __spl_randomId_type & ___spl_randomId, const __spl_class_type & ___spl_class) : Tuple(), __spl_version_(___spl_version), __spl_exportType_(___spl_exportType), __spl_topic_(___spl_topic), __spl_topicLevels_(___spl_topicLevels), __spl_topicLevelCount_(___spl_topicLevelCount), __spl_allowFilter_(___spl_allowFilter), __spl_channel_(___spl_channel), __spl_maxChannels_(___spl_maxChannels), __spl_randomId_(___spl_randomId), __spl_class_(___spl_class) { }
    SELF(const Tuple & ot, bool typesafe = true) : Tuple() { assignFrom(ot, typesafe); }
    SELF(const ConstValueHandle & ot) : Tuple() { const Tuple & o = ot; assignFrom(o); }

    virtual ~SELF() {}
    
    __spl_version_type & get___spl_version() { return __spl_version_; }
    const __spl_version_type & get___spl_version() const { return __spl_version_; }
    void set___spl_version(const __spl_version_type & ___spl_version) { __spl_version_ = ___spl_version; }
    
    __spl_exportType_type & get___spl_exportType() { return __spl_exportType_; }
    const __spl_exportType_type & get___spl_exportType() const { return __spl_exportType_; }
    void set___spl_exportType(const __spl_exportType_type & ___spl_exportType) { __spl_exportType_ = ___spl_exportType; }
    
    __spl_topic_type & get___spl_topic() { return __spl_topic_; }
    const __spl_topic_type & get___spl_topic() const { return __spl_topic_; }
    void set___spl_topic(const __spl_topic_type & ___spl_topic) { __spl_topic_ = ___spl_topic; }
    
    __spl_topicLevels_type & get___spl_topicLevels() { return __spl_topicLevels_; }
    const __spl_topicLevels_type & get___spl_topicLevels() const { return __spl_topicLevels_; }
    void set___spl_topicLevels(const __spl_topicLevels_type & ___spl_topicLevels) { __spl_topicLevels_ = ___spl_topicLevels; }
    
    __spl_topicLevelCount_type & get___spl_topicLevelCount() { return __spl_topicLevelCount_; }
    const __spl_topicLevelCount_type & get___spl_topicLevelCount() const { return __spl_topicLevelCount_; }
    void set___spl_topicLevelCount(const __spl_topicLevelCount_type & ___spl_topicLevelCount) { __spl_topicLevelCount_ = ___spl_topicLevelCount; }
    
    __spl_allowFilter_type & get___spl_allowFilter() { return __spl_allowFilter_; }
    const __spl_allowFilter_type & get___spl_allowFilter() const { return __spl_allowFilter_; }
    void set___spl_allowFilter(const __spl_allowFilter_type & ___spl_allowFilter) { __spl_allowFilter_ = ___spl_allowFilter; }
    
    __spl_channel_type & get___spl_channel() { return __spl_channel_; }
    const __spl_channel_type & get___spl_channel() const { return __spl_channel_; }
    void set___spl_channel(const __spl_channel_type & ___spl_channel) { __spl_channel_ = ___spl_channel; }
    
    __spl_maxChannels_type & get___spl_maxChannels() { return __spl_maxChannels_; }
    const __spl_maxChannels_type & get___spl_maxChannels() const { return __spl_maxChannels_; }
    void set___spl_maxChannels(const __spl_maxChannels_type & ___spl_maxChannels) { __spl_maxChannels_ = ___spl_maxChannels; }
    
    __spl_randomId_type & get___spl_randomId() { return __spl_randomId_; }
    const __spl_randomId_type & get___spl_randomId() const { return __spl_randomId_; }
    void set___spl_randomId(const __spl_randomId_type & ___spl_randomId) { __spl_randomId_ = ___spl_randomId; }
    
    __spl_class_type & get___spl_class() { return __spl_class_; }
    const __spl_class_type & get___spl_class() const { return __spl_class_; }
    void set___spl_class(const __spl_class_type & ___spl_class) { __spl_class_ = ___spl_class; }
    
    virtual bool equals(const Tuple & ot) const
    {

        if (typeid(*this) != typeid(ot)) { return false; }
        const SELF & o = static_cast<const SELF &>(ot);
        return (*this == o);

    }

    virtual SELF& clear();

    Tuple* clone() const { return new Self(*this); }
    
    void serialize(VirtualByteBuffer & buf) const
    {
        buf << __spl_version_ << __spl_exportType_ << __spl_topic_ << __spl_topicLevels_ << __spl_topicLevelCount_ << __spl_allowFilter_ << __spl_channel_ << __spl_maxChannels_ << __spl_randomId_ << __spl_class_;
    }

    template <class BufferType>
    void serialize(ByteBuffer<BufferType> & buf) const
    {        
        buf << __spl_version_ << __spl_exportType_ << __spl_topic_ << __spl_topicLevels_ << __spl_topicLevelCount_ << __spl_allowFilter_ << __spl_channel_ << __spl_maxChannels_ << __spl_randomId_ << __spl_class_;
    } 
    
    void serialize(NativeByteBuffer & buf) const
    {
        this->serialize<NativeByteBuffer>(buf);
    }

    void serialize(NetworkByteBuffer & buf) const
    {
        this->serialize<NetworkByteBuffer>(buf);
    }
    
    void deserialize(VirtualByteBuffer & buf)
    {
        buf >> __spl_version_ >> __spl_exportType_ >> __spl_topic_ >> __spl_topicLevels_ >> __spl_topicLevelCount_ >> __spl_allowFilter_ >> __spl_channel_ >> __spl_maxChannels_ >> __spl_randomId_ >> __spl_class_;
    }

    template <class BufferType>
    void deserialize(ByteBuffer<BufferType> & buf)
    {        
        buf >> __spl_version_ >> __spl_exportType_ >> __spl_topic_ >> __spl_topicLevels_ >> __spl_topicLevelCount_ >> __spl_allowFilter_ >> __spl_channel_ >> __spl_maxChannels_ >> __spl_randomId_ >> __spl_class_;
    } 

    void deserialize(NativeByteBuffer & buf)
    {
        this->deserialize<NativeByteBuffer>(buf);
    }    

    void deserialize(NetworkByteBuffer & buf)
    {
        this->deserialize<NetworkByteBuffer>(buf);
    }    

    void serialize(std::ostream & ostr) const;

    void serializeWithPrecision(std::ostream & ostr) const;

    void deserialize(std::istream & istr, bool withSuffix = false);
    
    void deserializeWithNanAndInfs(std::istream & istr, bool withSuffix = false);
    
    size_t hashCode() const
    {
        size_t s = 17;
        s = 37 * s + std::tr1::hash<__spl_version_type >()(__spl_version_);
        s = 37 * s + std::tr1::hash<__spl_exportType_type >()(__spl_exportType_);
        s = 37 * s + std::tr1::hash<__spl_topic_type >()(__spl_topic_);
        s = 37 * s + std::tr1::hash<__spl_topicLevels_type >()(__spl_topicLevels_);
        s = 37 * s + std::tr1::hash<__spl_topicLevelCount_type >()(__spl_topicLevelCount_);
        s = 37 * s + std::tr1::hash<__spl_allowFilter_type >()(__spl_allowFilter_);
        s = 37 * s + std::tr1::hash<__spl_channel_type >()(__spl_channel_);
        s = 37 * s + std::tr1::hash<__spl_maxChannels_type >()(__spl_maxChannels_);
        s = 37 * s + std::tr1::hash<__spl_randomId_type >()(__spl_randomId_);
        s = 37 * s + std::tr1::hash<__spl_class_type >()(__spl_class_);
        return s;
    }
    
    size_t getSerializedSize() const
    {
        size_t size = sizeof(SPL::int64)+sizeof(SPL::int64)+sizeof(SPL::int64)+sizeof(SPL::int64)+sizeof(SPL::int64);
           size += __spl_exportType_.getSerializedSize();
   size += __spl_topic_.getSerializedSize();
   size += __spl_topicLevels_.getSerializedSize();
   size += __spl_allowFilter_.getSerializedSize();
   size += __spl_class_.getSerializedSize();

        return size;

    }
    
    uint32_t getNumberOfAttributes() const 
        { return num_attributes; }

    TupleIterator getBeginIterator() 
        { return TupleIterator(*this, 0); }
    
    ConstTupleIterator getBeginIterator() const 
        { return ConstTupleIterator(*this, 0); }

    TupleIterator getEndIterator() 
        { return TupleIterator(*this, num_attributes); }

    ConstTupleIterator getEndIterator() const 
        { return ConstTupleIterator(*this, num_attributes); }
    
    TupleIterator findAttribute(const std::string & attrb)
    {
        std::tr1::unordered_map<std::string, uint32_t>::const_iterator it = mappings_->nameToIndex_.find(attrb);
        if ( it == mappings_->nameToIndex_.end() ) {
            return this->getEndIterator();
        }
        return TupleIterator(*this, it->second);
    }
    
    ConstTupleIterator findAttribute(const std::string & attrb) const
        { return const_cast<Self*>(this)->findAttribute(attrb); }
    
    TupleAttribute getAttribute(uint32_t index)
    {
        if (index >= num_attributes)
            invalidIndex (index, num_attributes);
        return TupleAttribute(mappings_->indexToName_[index], index, *this);
    }
    
    ConstTupleAttribute getAttribute(uint32_t index) const
        { return const_cast<Self*>(this)->getAttribute(index); }

    ValueHandle getAttributeValue(const std::string & attrb)
        { return getAttributeValueRaw(lookupAttributeName(*mappings_, attrb)->second); }


    ConstValueHandle getAttributeValue(const std::string & attrb) const
        { return const_cast<Self*>(this)->getAttributeValue(attrb); }

    ValueHandle getAttributeValue(uint32_t index) 
        { return getAttributeValueRaw(index); }

    ConstValueHandle getAttributeValue(uint32_t index) const
        { return const_cast<Self*>(this)->getAttributeValue(index); }

    Self & operator=(const Self & ot) 
    { 
        __spl_version_ = ot.__spl_version_;
        __spl_exportType_ = ot.__spl_exportType_;
        __spl_topic_ = ot.__spl_topic_;
        __spl_topicLevels_ = ot.__spl_topicLevels_;
        __spl_topicLevelCount_ = ot.__spl_topicLevelCount_;
        __spl_allowFilter_ = ot.__spl_allowFilter_;
        __spl_channel_ = ot.__spl_channel_;
        __spl_maxChannels_ = ot.__spl_maxChannels_;
        __spl_randomId_ = ot.__spl_randomId_;
        __spl_class_ = ot.__spl_class_; 
        assignPayload(ot);
        return *this; 
    }

    Self & operator=(const Tuple & ot) 
    { 
        assignFrom(ot); 
        return *this; 
    }

    void assign(Tuple const & tuple)
    {
        *this = static_cast<SELF const &>(tuple);
    }


    bool operator==(const Self & ot) const 
    {  
       return ( 
                __spl_version_ == ot.__spl_version_ && 
                __spl_exportType_ == ot.__spl_exportType_ && 
                __spl_topic_ == ot.__spl_topic_ && 
                __spl_topicLevels_ == ot.__spl_topicLevels_ && 
                __spl_topicLevelCount_ == ot.__spl_topicLevelCount_ && 
                __spl_allowFilter_ == ot.__spl_allowFilter_ && 
                __spl_channel_ == ot.__spl_channel_ && 
                __spl_maxChannels_ == ot.__spl_maxChannels_ && 
                __spl_randomId_ == ot.__spl_randomId_ && 
                __spl_class_ == ot.__spl_class_  
              ); 
    }
    bool operator==(const Tuple & ot) const { return equals(ot); }

    bool operator!=(const Self & ot) const { return !(*this == ot); }
    bool operator!=(const Tuple & ot) const { return !(*this == ot); }


    void swap(SELF & ot) 
    { 
        std::swap(__spl_version_, ot.__spl_version_);
        std::swap(__spl_exportType_, ot.__spl_exportType_);
        std::swap(__spl_topic_, ot.__spl_topic_);
        std::swap(__spl_topicLevels_, ot.__spl_topicLevels_);
        std::swap(__spl_topicLevelCount_, ot.__spl_topicLevelCount_);
        std::swap(__spl_allowFilter_, ot.__spl_allowFilter_);
        std::swap(__spl_channel_, ot.__spl_channel_);
        std::swap(__spl_maxChannels_, ot.__spl_maxChannels_);
        std::swap(__spl_randomId_, ot.__spl_randomId_);
        std::swap(__spl_class_, ot.__spl_class_);
      std::swap(payload_, ot.payload_);
    }

    void reset()
    { 
        *this = SELF(); 
    }

    void normalizeBoundedSetsAndMaps(); 

    const std::string & getAttributeName(uint32_t index) const
    {
        if (index >= num_attributes)
            invalidIndex (index, num_attributes);
        return mappings_->indexToName_[index];
    }

    const std::tr1::unordered_map<std::string, uint32_t> & getAttributeNames() const 
        { return mappings_->nameToIndex_; }

protected:

    ValueHandle getAttributeValueRaw(const uint32_t index)
    {
        if (index >= num_attributes)
            invalidIndex(index, num_attributes);
        const TypeOffset & t = mappings_->indexToTypeOffset_[index];
        return ValueHandle((char*)this + t.getOffset(), t.getMetaType(), &t.getTypeId());
    }

private:
    
    __spl_version_type __spl_version_;
    __spl_exportType_type __spl_exportType_;
    __spl_topic_type __spl_topic_;
    __spl_topicLevels_type __spl_topicLevels_;
    __spl_topicLevelCount_type __spl_topicLevelCount_;
    __spl_allowFilter_type __spl_allowFilter_;
    __spl_channel_type __spl_channel_;
    __spl_maxChannels_type __spl_maxChannels_;
    __spl_randomId_type __spl_randomId_;
    __spl_class_type __spl_class_;

    static TupleMappings* mappings_;
    static TupleMappings* initMappings();
};

inline VirtualByteBuffer & operator>>(VirtualByteBuffer & sbuf, SELF & tuple) 
    { tuple.deserialize(sbuf); return sbuf; }
inline VirtualByteBuffer & operator<<(VirtualByteBuffer & sbuf, SELF const & tuple) 
    { tuple.serialize(sbuf); return sbuf; }

template <class BufferType>
inline ByteBuffer<BufferType> & operator>>(ByteBuffer<BufferType> & sbuf, SELF & tuple) 
    { tuple.deserialize(sbuf); return sbuf; }
template <class BufferType>
inline ByteBuffer<BufferType> & operator<<(ByteBuffer<BufferType> & sbuf, SELF const & tuple) 
    { tuple.serialize(sbuf); return sbuf; }

inline NetworkByteBuffer & operator>>(NetworkByteBuffer & sbuf, SELF & tuple) 
    { tuple.deserialize(sbuf); return sbuf; }
inline NetworkByteBuffer & operator<<(NetworkByteBuffer & sbuf, SELF const & tuple) 
    { tuple.serialize(sbuf); return sbuf; }

inline NativeByteBuffer & operator>>(NativeByteBuffer & sbuf, SELF & tuple) 
    { tuple.deserialize(sbuf); return sbuf; }
inline NativeByteBuffer & operator<<(NativeByteBuffer & sbuf, SELF const & tuple) 
    { tuple.serialize(sbuf); return sbuf; }

template<>
inline std::ostream & serializeWithPrecision(std::ostream & ostr, SELF const & tuple) 
    { tuple.serializeWithPrecision(ostr); return ostr; }
inline std::ostream & operator<<(std::ostream & ostr, SELF const & tuple) 
    { tuple.serialize(ostr); return ostr; }
inline std::istream & operator>>(std::istream & istr, SELF & tuple) 
    { tuple.deserialize(istr); return istr; }
template<>
inline void deserializeWithSuffix(std::istream & istr, SELF  & tuple) 
{ tuple.deserialize(istr,true);  }
inline void deserializeWithNanAndInfs(std::istream & istr, SELF  & tuple, bool withSuffix = false) 
{ tuple.deserializeWithNanAndInfs(istr,withSuffix);  }



}  // namespace SPL

namespace std
{
    inline void swap(SPL::SELF & a, SPL::SELF & b)
    {
        a.swap(b);
    }
};

namespace std { 
    namespace tr1 {
        template <>
        struct hash<SPL::SELF> {
            inline size_t operator()(const SPL::SELF & self) const 
                { return self.hashCode(); }
        };
    }
}

#undef SELF
#endif // BEJXDJKEKAJEMRA9KVPQAA0LAPFSSOGELMAQ0CZY5VYTIEZFV8ED_1GAPCKSWVKLZUXKWDLP15Q9BISVD2GK7CASNICP3BO68SJKF4D5O9NEZLIVA_0FQLUYZE_1SZUFV81C29SVI5Y7A6SZLTIPD1NI_1QNUWUZA_H_ 



