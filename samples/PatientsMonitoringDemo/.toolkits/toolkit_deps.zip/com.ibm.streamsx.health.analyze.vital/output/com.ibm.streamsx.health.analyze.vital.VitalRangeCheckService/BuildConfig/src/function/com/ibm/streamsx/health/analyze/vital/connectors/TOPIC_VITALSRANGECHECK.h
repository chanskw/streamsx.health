#ifndef SPL_FUNCTION_com_ibm_streamsx_health_analyze_vital_connectors_TOPIC_VITALSRANGECHECK_h
#define SPL_FUNCTION_com_ibm_streamsx_health_analyze_vital_connectors_TOPIC_VITALSRANGECHECK_h

namespace com {
    namespace ibm {
        namespace streamsx {
            namespace health {
                namespace analyze {
                    namespace vital {
                        namespace connectors {
                            SPL::rstring TOPIC_VITALSRANGECHECK ();
                        }
                    }
                }
            }
        }
    }
}

#endif // SPL_FUNCTION_com_ibm_streamsx_health_analyze_vital_connectors_TOPIC_VITALSRANGECHECK_h
