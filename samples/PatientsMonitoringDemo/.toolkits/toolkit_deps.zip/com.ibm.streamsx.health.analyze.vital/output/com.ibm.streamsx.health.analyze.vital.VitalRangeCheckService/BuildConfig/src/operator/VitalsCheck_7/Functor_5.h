// eJzNkltvokAYhsM_1Mc1etEnDsSqapgkKtB7QItqqN2TQEcYyM5QZofrrdzx2t2l2k73awM28Cc_08PN_1HslTOYQo4ogSkzaa7IQtOc0mTVPEY0pUsK_0Ll2wwqLdgtU2Q6PWvteK1pqHVr1nv9o5wUJBk3LAdPX0pdHU8wuhs0ItOe2Z7qtrrWMlQ7iV4tnV5nsja7UEej8Suahmph1NP61ixbM8OOt2rD96Jp_1bFaEt3XG8FdiefjHMLXlyAqUkPFbe6H6h2JI5doi6Hv81UyX7VrIzm5_0r5nubb8Q08_0mr5PVjYKllahe0l_1OkHAfJq9iAqLx8IzrHFnPcvaRRD4bNbN_0jVtGazd6Wb_05HZDrU4EorqDE3NpW75bEyWe415a5oa_1qFbVkm6ingE5_12ANchdq88y16sFwaIeaY9uZ92753zXMvaC27Tsx2052g16ouV4w7g52zhvvsbeMsWTQD6rDsWPyVtw2Q7Usgz1mPxZJSSiGCuM5BJiBJUZEiRE_1Bx9yAkHKE4UBnKWQKc9ivJBw5lGCxHARiW2IqSJzStM3xJmyoFhGEZa_1AGQgdmK7g3KBOEiVJeBAIpTAfYf9gqCM5vyHKgXP_1Wbzf90OCUn50ZroTMOTC4lvhJp7RLihV0AMbyPhAgJSASnM_0e0xjzIbAcZpihaXJNieglVKwT4SqnI_0Ahx_0JrlVwHwPTRHj9xthVSh_1qGDImEjZ7SmpEIDh5ZBTijtkRU83sWyoX4gc4kwQ_0SaHDwfz9Kv5f9gmCQsxhpQdhXSW0qmJuEA7gs_1BZdJyDHl4cXh9czjv_1_0L6RjqIk04aPxnn4M_0Mw8cCclYk_1Wbuk3aIf_01WefgL_0Uy8vhHefgKPB57S



#ifndef SPL_OPER_INSTANCE_VITALSCHECK_7_FUNCTOR_5_H_
#define SPL_OPER_INSTANCE_VITALSCHECK_7_FUNCTOR_5_H_

#include <SPL/Runtime/Operator/Operator.h>
#include <SPL/Runtime/Operator/ParameterValue.h>
#include <SPL/Runtime/Operator/OperatorContext.h>
#include <SPL/Runtime/Operator/OperatorMetrics.h>
#include <SPL/Runtime/Operator/Port/AutoPortMutex.h>
#include <SPL/Runtime/Operator/State/StateHandler.h>
#include <SPL/Runtime/ProcessingElement/PE.h>
#include <SPL/Runtime/Type/SPLType.h>
#include <SPL/Runtime/Utility/CV.h>
using namespace UTILS_NAMESPACE;

#include "../../type/BeJwli8EKAjEMBX_1J6Aq7xwUvnhT9AEmXVw20TUmi4N9b8DYDM0FBJAd_0Ih25wEKIUj8Je2iRTWiX_0v37l7y8wBY3Dgy09QMbX7G5wn2Q29S4wmZTreeWVSbvl30mCtQ_04ngbFn1cOQQtfhZfC6R.h"
#include "../../type/BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ.h"
#include "../../type/BeJwrMS6yLEgsyUzNK_1FMSTJNzEktKskpsshNLS5OTE8tBgC8_0wwS.h"

#include <bitset>

#define MY_OPERATOR Functor_5$OP
#define MY_BASE_OPERATOR Functor_5_Base
#define MY_OPERATOR_SCOPE SPL::_Operator::VitalsCheck_7

namespace SPL {
namespace _Operator {
namespace VitalsCheck_7 {

class MY_BASE_OPERATOR : public Operator
{
public:
    
    typedef SPL::BeJwli8EKAjEMBX_1J6Aq7xwUvnhT9AEmXVw20TUmi4N9b8DYDM0FBJAd_0Ih25wEKIUj8Je2iRTWiX_0v37l7y8wBY3Dgy09QMbX7G5wn2Q29S4wmZTreeWVSbvl30mCtQ_04ngbFn1cOQQtfhZfC6R IPort0Type;
    typedef SPL::BeJwrMS6yLEgsyUzNK_1FMSTJNzEktKskpsshNLS5OTE8tBgC8_0wwS OPort0Type;
    
    MY_BASE_OPERATOR();
    
    ~MY_BASE_OPERATOR();
    
    inline void tupleLogic(Tuple const & tuple, uint32_t port);
    void processRaw(Tuple const & tuple, uint32_t port);
    
    inline void punctLogic(Punctuation const & punct, uint32_t port);
    void processRaw(Punctuation const & punct, uint32_t port);
    void punctPermitProcessRaw(Punctuation const & punct, uint32_t port);
    void punctNoPermitProcessRaw(Punctuation const & punct, uint32_t port);
    
    inline void submit(Tuple & tuple, uint32_t port)
    {
        Operator::submit(tuple, port);
    }
    inline void submit(Punctuation const & punct, uint32_t port)
    {
        Operator::submit(punct, port);
    }
    
    
    
    
    
protected:
    Mutex $svMutex;
    typedef std::bitset<2> OPortBitsetType;
    OPortBitsetType $oportBitset;
    Mutex $fpMutex;
    void checkpointStateVariables(NetworkByteBuffer & opstate) const;
    void restoreStateVariables(NetworkByteBuffer & opstate);
    void checkpointStateVariables(Checkpoint & ckpt);
    void resetStateVariables(Checkpoint & ckpt);
    void resetStateVariablesToInitialState();
    bool hasStateVariables() const;
    void resetToInitialStateRaw();
    void checkpointRaw(Checkpoint & ckpt);
    void resetRaw(Checkpoint & ckpt);
private:
    static bool globalInit_;
    static bool globalIniter();
    ParameterMapType paramValues_;
    ParameterMapType& getParameters() { return paramValues_;}
    void addParameterValue(std::string const & param, ConstValueHandle const& value)
    {
        ParameterMapType::iterator it = paramValues_.find(param);
        if (it == paramValues_.end())
            it = paramValues_.insert (std::make_pair (param, ParameterValueListType())).first;
        it->second.push_back(&ParameterValue::create(value));
    }
    void addParameterValue(std::string const & param)
    {
        ParameterMapType::iterator it = paramValues_.find(param);
        if (it == paramValues_.end())
            it = paramValues_.insert (std::make_pair (param, ParameterValueListType())).first;
        it->second.push_back(&ParameterValue::create());
    }
};


class MY_OPERATOR : public MY_BASE_OPERATOR
{
public:
   MY_OPERATOR() {}
  
   void process(Tuple const & tuple, uint32_t port);
   void process(Punctuation const & punct, uint32_t port);
   
}; 

} // namespace VitalsCheck_7
} // namespace _Operator
} // namespace SPL

#undef MY_OPERATOR_SCOPE
#undef MY_BASE_OPERATOR
#undef MY_OPERATOR
#endif // SPL_OPER_INSTANCE_VITALSCHECK_7_FUNCTOR_5_H_

