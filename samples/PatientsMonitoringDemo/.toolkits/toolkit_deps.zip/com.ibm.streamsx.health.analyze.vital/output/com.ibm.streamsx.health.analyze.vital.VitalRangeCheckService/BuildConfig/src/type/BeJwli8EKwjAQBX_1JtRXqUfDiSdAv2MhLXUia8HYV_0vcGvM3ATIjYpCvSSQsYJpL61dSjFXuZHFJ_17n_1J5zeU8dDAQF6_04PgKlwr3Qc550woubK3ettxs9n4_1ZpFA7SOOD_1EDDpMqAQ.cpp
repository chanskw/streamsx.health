// t11i3ageb5alerti11bpDiastolici10bpSystolicf9heartRatef9hrAveragelr8messagesr4namer8roomInfoi4spO2f11temperature


#include "BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ.h"
#include <sstream>

#define SELF BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ

using namespace SPL;

TupleMappings* SELF::mappings_ = SELF::initMappings();

static void addMapping(TupleMappings & tm, TypeOffset & offset,
                       std::string const & name, uint32_t index)
{
    tm.nameToIndex_.insert(std::make_pair(name, index)); 
    tm.indexToName_.push_back(name);
    tm.indexToTypeOffset_.push_back(offset);    
}

static Tuple * initer() { return new SELF(); }

TupleMappings* SELF::initMappings()
{
    instantiators_.insert(std::make_pair("tuple<int32 age,boolean alert,int32 bpDiastolic,int32 bpSystolic,float32 heartRate,float32 hrAverage,list<ustring> messages,ustring name,ustring roomInfo,int32 spO2,float32 temperature>",&initer));
    TupleMappings * tm = new TupleMappings();
#define MY_OFFSETOF(member, base) \
    ((uintptr_t)&reinterpret_cast<Self*>(base)->member) - (uintptr_t)base
   
    // initialize the mappings 
    
    {
        std::string s("age");
        TypeOffset t(MY_OFFSETOF(age_, tm), 
                     Meta::Type::typeOf<SPL::int32 >(), 
                     &typeid(SPL::int32));
        addMapping(*tm, t, s, 0);
    }
    
    {
        std::string s("alert");
        TypeOffset t(MY_OFFSETOF(alert_, tm), 
                     Meta::Type::typeOf<SPL::boolean >(), 
                     &typeid(SPL::boolean));
        addMapping(*tm, t, s, 1);
    }
    
    {
        std::string s("bpDiastolic");
        TypeOffset t(MY_OFFSETOF(bpDiastolic_, tm), 
                     Meta::Type::typeOf<SPL::int32 >(), 
                     &typeid(SPL::int32));
        addMapping(*tm, t, s, 2);
    }
    
    {
        std::string s("bpSystolic");
        TypeOffset t(MY_OFFSETOF(bpSystolic_, tm), 
                     Meta::Type::typeOf<SPL::int32 >(), 
                     &typeid(SPL::int32));
        addMapping(*tm, t, s, 3);
    }
    
    {
        std::string s("heartRate");
        TypeOffset t(MY_OFFSETOF(heartRate_, tm), 
                     Meta::Type::typeOf<SPL::float32 >(), 
                     &typeid(SPL::float32));
        addMapping(*tm, t, s, 4);
    }
    
    {
        std::string s("hrAverage");
        TypeOffset t(MY_OFFSETOF(hrAverage_, tm), 
                     Meta::Type::typeOf<SPL::float32 >(), 
                     &typeid(SPL::float32));
        addMapping(*tm, t, s, 5);
    }
    
    {
        std::string s("messages");
        TypeOffset t(MY_OFFSETOF(messages_, tm), 
                     Meta::Type::typeOf<SPL::list<SPL::ustring > >(), 
                     &typeid(SPL::list<SPL::ustring >));
        addMapping(*tm, t, s, 6);
    }
    
    {
        std::string s("name");
        TypeOffset t(MY_OFFSETOF(name_, tm), 
                     Meta::Type::typeOf<SPL::ustring >(), 
                     &typeid(SPL::ustring));
        addMapping(*tm, t, s, 7);
    }
    
    {
        std::string s("roomInfo");
        TypeOffset t(MY_OFFSETOF(roomInfo_, tm), 
                     Meta::Type::typeOf<SPL::ustring >(), 
                     &typeid(SPL::ustring));
        addMapping(*tm, t, s, 8);
    }
    
    {
        std::string s("spO2");
        TypeOffset t(MY_OFFSETOF(spO2_, tm), 
                     Meta::Type::typeOf<SPL::int32 >(), 
                     &typeid(SPL::int32));
        addMapping(*tm, t, s, 9);
    }
    
    {
        std::string s("temperature");
        TypeOffset t(MY_OFFSETOF(temperature_, tm), 
                     Meta::Type::typeOf<SPL::float32 >(), 
                     &typeid(SPL::float32));
        addMapping(*tm, t, s, 10);
    }
    
    return tm;
}

void SELF::deserialize(std::istream & istr, bool withSuffix)
{
   std::string s;
   char c;

   istr >> c; if (!istr) { return; }
   if (c != '{') { istr.setstate(std::ios_base::failbit); return; }
   
   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "age") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, age_);
   else
     istr >> age_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "alert") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, alert_);
   else
     istr >> alert_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "bpDiastolic") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, bpDiastolic_);
   else
     istr >> bpDiastolic_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "bpSystolic") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, bpSystolic_);
   else
     istr >> bpSystolic_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "heartRate") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, heartRate_);
   else
     istr >> heartRate_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "hrAverage") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, hrAverage_);
   else
     istr >> hrAverage_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "messages") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, messages_);
   else
     istr >> messages_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "name") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, name_);
   else
     istr >> name_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "roomInfo") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, roomInfo_);
   else
     istr >> roomInfo_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "spO2") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, spO2_);
   else
     istr >> spO2_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "temperature") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, temperature_);
   else
     istr >> temperature_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   
   if (c != '}') { istr.setstate(std::ios_base::failbit); return; }
}

void SELF::deserializeWithNanAndInfs(std::istream & istr, bool withSuffix)
{
   std::string s;
   char c;

   istr >> c; if (!istr) { return; }
   if (c != '{') { istr.setstate(std::ios_base::failbit); return; }
   
   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "age") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, age_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "alert") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, alert_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "bpDiastolic") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, bpDiastolic_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "bpSystolic") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, bpSystolic_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "heartRate") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, heartRate_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "hrAverage") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, hrAverage_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "messages") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, messages_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "name") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, name_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "roomInfo") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, roomInfo_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "spO2") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, spO2_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "temperature") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, temperature_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   
   if (c != '}') { istr.setstate(std::ios_base::failbit); return; }
}

void SELF::serialize(std::ostream & ostr) const
{
    ostr << '{'
         << "age=" << get_age()  << ","
         << "alert=" << get_alert()  << ","
         << "bpDiastolic=" << get_bpDiastolic()  << ","
         << "bpSystolic=" << get_bpSystolic()  << ","
         << "heartRate=" << get_heartRate()  << ","
         << "hrAverage=" << get_hrAverage()  << ","
         << "messages=" << get_messages()  << ","
         << "name=" << get_name()  << ","
         << "roomInfo=" << get_roomInfo()  << ","
         << "spO2=" << get_spO2()  << ","
         << "temperature=" << get_temperature()  
         << '}';
}

void SELF::serializeWithPrecision(std::ostream & ostr) const
{
    ostr << '{';
    SPL::serializeWithPrecision(ostr << "age=", get_age()) << ",";
    SPL::serializeWithPrecision(ostr << "alert=", get_alert()) << ",";
    SPL::serializeWithPrecision(ostr << "bpDiastolic=", get_bpDiastolic()) << ",";
    SPL::serializeWithPrecision(ostr << "bpSystolic=", get_bpSystolic()) << ",";
    SPL::serializeWithPrecision(ostr << "heartRate=", get_heartRate()) << ",";
    SPL::serializeWithPrecision(ostr << "hrAverage=", get_hrAverage()) << ",";
    SPL::serializeWithPrecision(ostr << "messages=", get_messages()) << ",";
    SPL::serializeWithPrecision(ostr << "name=", get_name()) << ",";
    SPL::serializeWithPrecision(ostr << "roomInfo=", get_roomInfo()) << ",";
    SPL::serializeWithPrecision(ostr << "spO2=", get_spO2()) << ",";
    SPL::serializeWithPrecision(ostr << "temperature=", get_temperature()) ;
    ostr << '}';
}

SELF& SELF::clear()
{
    get_age() = 0;
    get_alert() = false;
    get_bpDiastolic() = 0;
    get_bpSystolic() = 0;
    get_heartRate() = 0;
    get_hrAverage() = 0;
    if (get_messages().size() < 1024) {
        get_messages().clear();
    }
    else {
        SPL::list<SPL::ustring >().swap(get_messages());
    }
    get_name().remove();
    get_roomInfo().remove();
    get_spO2() = 0;
    get_temperature() = 0;

    return *this;
}

void SELF::normalizeBoundedSetsAndMaps()
{
    SPL::normalizeBoundedSetsAndMaps(*this);
}


