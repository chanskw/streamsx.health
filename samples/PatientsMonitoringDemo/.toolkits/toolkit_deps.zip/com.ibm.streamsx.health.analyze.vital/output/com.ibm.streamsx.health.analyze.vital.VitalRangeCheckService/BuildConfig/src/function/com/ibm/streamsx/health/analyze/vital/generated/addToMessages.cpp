#include "SPL/Runtime/Function/SPLFunctions.h"
#include "./addToMessages.h"
namespace com { namespace ibm { namespace streamsx { namespace health { namespace analyze { namespace vital { namespace generated { 
void addToMessages (SPL::BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ& obj, const SPL::ustring& arg0)
{
    ::SPL::Functions::Collections::appendM(obj.get_messages(), arg0);
}
} } } } } } } 
