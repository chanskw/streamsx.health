// t11i3ageb5alerti11bpDiastolici10bpSystolicf9heartRatef9hrAveragelr8messagesr4namer8roomInfoi4spO2f11temperature


#ifndef BEJWLI8EKWJAQBX_1JTRXQUFDISDAV2MHLXUIA8HYV_0VCGVM3ATIJYPCVSSQSYJPL61DSJFXUZHFJ_17N_1J5ZEU8DDAQF6_04PGKLWR3QC550WOUBK3ETTXS9N4_1ZPFA7SOOD_1EDDPMQAQ_H_
#define BEJWLI8EKWJAQBX_1JTRXQUFDISDAV2MHLXUIA8HYV_0VCGVM3ATIJYPCVSSQSYJPL61DSJFXUZHFJ_17N_1J5ZEU8DDAQF6_04PGKLWR3QC550WOUBK3ETTXS9N4_1ZPFA7SOOD_1EDDPMQAQ_H_

#include <SPL/Runtime/Type/Tuple.h>
#include <SPL/Runtime/Type/PrimitiveType.h>
#include <SPL/Runtime/Type/CollectionType.h>
#include <SPL/Runtime/Serialization/NetworkByteBuffer.h>
#include <SPL/Runtime/Serialization/NativeByteBuffer.h>
#include <SPL/Runtime/Serialization/VirtualByteBuffer.h>



#define SELF BeJwli8EKwjAQBX_1JtRXqUfDiSdAv2MhLXUia8HYV_0vcGvM3ATIjYpCvSSQsYJpL61dSjFXuZHFJ_17n_1J5zeU8dDAQF6_04PgKlwr3Qc550woubK3ettxs9n4_1ZpFA7SOOD_1EDDpMqAQ

namespace SPL {

class SELF : public Tuple
{
public:
    static const bool facade = false;

    typedef SELF Self;
    
    typedef SPL::int32 age_type;
    typedef SPL::boolean alert_type;
    typedef SPL::int32 bpDiastolic_type;
    typedef SPL::int32 bpSystolic_type;
    typedef SPL::float32 heartRate_type;
    typedef SPL::float32 hrAverage_type;
    typedef SPL::list<SPL::ustring > messages_type;
    typedef SPL::ustring name_type;
    typedef SPL::ustring roomInfo_type;
    typedef SPL::int32 spO2_type;
    typedef SPL::float32 temperature_type;

    enum { num_attributes = 11 } ;
    
    SELF() : Tuple(), age_(), alert_(), bpDiastolic_(), bpSystolic_(), heartRate_(), hrAverage_(), messages_(), name_(), roomInfo_(), spO2_(), temperature_() {}
    SELF(const Self & ot) : Tuple(), age_(ot.age_), alert_(ot.alert_), bpDiastolic_(ot.bpDiastolic_), bpSystolic_(ot.bpSystolic_), heartRate_(ot.heartRate_), hrAverage_(ot.hrAverage_), messages_(ot.messages_), name_(ot.name_), roomInfo_(ot.roomInfo_), spO2_(ot.spO2_), temperature_(ot.temperature_) 
      { constructPayload(ot); }
    SELF(const age_type & _age, const alert_type & _alert, const bpDiastolic_type & _bpDiastolic, const bpSystolic_type & _bpSystolic, const heartRate_type & _heartRate, const hrAverage_type & _hrAverage, const messages_type & _messages, const name_type & _name, const roomInfo_type & _roomInfo, const spO2_type & _spO2, const temperature_type & _temperature) : Tuple(), age_(_age), alert_(_alert), bpDiastolic_(_bpDiastolic), bpSystolic_(_bpSystolic), heartRate_(_heartRate), hrAverage_(_hrAverage), messages_(_messages), name_(_name), roomInfo_(_roomInfo), spO2_(_spO2), temperature_(_temperature) { }
    SELF(const Tuple & ot, bool typesafe = true) : Tuple() { assignFrom(ot, typesafe); }
    SELF(const ConstValueHandle & ot) : Tuple() { const Tuple & o = ot; assignFrom(o); }

    virtual ~SELF() {}
    
    age_type & get_age() { return age_; }
    const age_type & get_age() const { return age_; }
    void set_age(const age_type & _age) { age_ = _age; }
    
    alert_type & get_alert() { return alert_; }
    const alert_type & get_alert() const { return alert_; }
    void set_alert(const alert_type & _alert) { alert_ = _alert; }
    
    bpDiastolic_type & get_bpDiastolic() { return bpDiastolic_; }
    const bpDiastolic_type & get_bpDiastolic() const { return bpDiastolic_; }
    void set_bpDiastolic(const bpDiastolic_type & _bpDiastolic) { bpDiastolic_ = _bpDiastolic; }
    
    bpSystolic_type & get_bpSystolic() { return bpSystolic_; }
    const bpSystolic_type & get_bpSystolic() const { return bpSystolic_; }
    void set_bpSystolic(const bpSystolic_type & _bpSystolic) { bpSystolic_ = _bpSystolic; }
    
    heartRate_type & get_heartRate() { return heartRate_; }
    const heartRate_type & get_heartRate() const { return heartRate_; }
    void set_heartRate(const heartRate_type & _heartRate) { heartRate_ = _heartRate; }
    
    hrAverage_type & get_hrAverage() { return hrAverage_; }
    const hrAverage_type & get_hrAverage() const { return hrAverage_; }
    void set_hrAverage(const hrAverage_type & _hrAverage) { hrAverage_ = _hrAverage; }
    
    messages_type & get_messages() { return messages_; }
    const messages_type & get_messages() const { return messages_; }
    void set_messages(const messages_type & _messages) { messages_ = _messages; }
    
    name_type & get_name() { return name_; }
    const name_type & get_name() const { return name_; }
    void set_name(const name_type & _name) { name_ = _name; }
    
    roomInfo_type & get_roomInfo() { return roomInfo_; }
    const roomInfo_type & get_roomInfo() const { return roomInfo_; }
    void set_roomInfo(const roomInfo_type & _roomInfo) { roomInfo_ = _roomInfo; }
    
    spO2_type & get_spO2() { return spO2_; }
    const spO2_type & get_spO2() const { return spO2_; }
    void set_spO2(const spO2_type & _spO2) { spO2_ = _spO2; }
    
    temperature_type & get_temperature() { return temperature_; }
    const temperature_type & get_temperature() const { return temperature_; }
    void set_temperature(const temperature_type & _temperature) { temperature_ = _temperature; }
    
    virtual bool equals(const Tuple & ot) const
    {

        if (typeid(*this) != typeid(ot)) { return false; }
        const SELF & o = static_cast<const SELF &>(ot);
        return (*this == o);

    }

    virtual SELF& clear();

    Tuple* clone() const { return new Self(*this); }
    
    void serialize(VirtualByteBuffer & buf) const
    {
        buf << age_ << alert_ << bpDiastolic_ << bpSystolic_ << heartRate_ << hrAverage_ << messages_ << name_ << roomInfo_ << spO2_ << temperature_;
    }

    template <class BufferType>
    void serialize(ByteBuffer<BufferType> & buf) const
    {        
        buf << age_ << alert_ << bpDiastolic_ << bpSystolic_ << heartRate_ << hrAverage_ << messages_ << name_ << roomInfo_ << spO2_ << temperature_;
    } 
    
    void serialize(NativeByteBuffer & buf) const
    {
        this->serialize<NativeByteBuffer>(buf);
    }

    void serialize(NetworkByteBuffer & buf) const
    {
        this->serialize<NetworkByteBuffer>(buf);
    }
    
    void deserialize(VirtualByteBuffer & buf)
    {
        buf >> age_ >> alert_ >> bpDiastolic_ >> bpSystolic_ >> heartRate_ >> hrAverage_ >> messages_ >> name_ >> roomInfo_ >> spO2_ >> temperature_;
    }

    template <class BufferType>
    void deserialize(ByteBuffer<BufferType> & buf)
    {        
        buf >> age_ >> alert_ >> bpDiastolic_ >> bpSystolic_ >> heartRate_ >> hrAverage_ >> messages_ >> name_ >> roomInfo_ >> spO2_ >> temperature_;
    } 

    void deserialize(NativeByteBuffer & buf)
    {
        this->deserialize<NativeByteBuffer>(buf);
    }    

    void deserialize(NetworkByteBuffer & buf)
    {
        this->deserialize<NetworkByteBuffer>(buf);
    }    

    void serialize(std::ostream & ostr) const;

    void serializeWithPrecision(std::ostream & ostr) const;

    void deserialize(std::istream & istr, bool withSuffix = false);
    
    void deserializeWithNanAndInfs(std::istream & istr, bool withSuffix = false);
    
    size_t hashCode() const
    {
        size_t s = 17;
        s = 37 * s + std::tr1::hash<age_type >()(age_);
        s = 37 * s + std::tr1::hash<alert_type >()(alert_);
        s = 37 * s + std::tr1::hash<bpDiastolic_type >()(bpDiastolic_);
        s = 37 * s + std::tr1::hash<bpSystolic_type >()(bpSystolic_);
        s = 37 * s + std::tr1::hash<heartRate_type >()(heartRate_);
        s = 37 * s + std::tr1::hash<hrAverage_type >()(hrAverage_);
        s = 37 * s + std::tr1::hash<messages_type >()(messages_);
        s = 37 * s + std::tr1::hash<name_type >()(name_);
        s = 37 * s + std::tr1::hash<roomInfo_type >()(roomInfo_);
        s = 37 * s + std::tr1::hash<spO2_type >()(spO2_);
        s = 37 * s + std::tr1::hash<temperature_type >()(temperature_);
        return s;
    }
    
    size_t getSerializedSize() const
    {
        size_t size = sizeof(SPL::int32)+sizeof(SPL::boolean)+sizeof(SPL::int32)+sizeof(SPL::int32)+sizeof(SPL::float32)+sizeof(SPL::float32)+sizeof(SPL::int32)+sizeof(SPL::float32);
           size += messages_.getSerializedSize();
   size += name_.getSerializedSize();
   size += roomInfo_.getSerializedSize();

        return size;

    }
    
    uint32_t getNumberOfAttributes() const 
        { return num_attributes; }

    TupleIterator getBeginIterator() 
        { return TupleIterator(*this, 0); }
    
    ConstTupleIterator getBeginIterator() const 
        { return ConstTupleIterator(*this, 0); }

    TupleIterator getEndIterator() 
        { return TupleIterator(*this, num_attributes); }

    ConstTupleIterator getEndIterator() const 
        { return ConstTupleIterator(*this, num_attributes); }
    
    TupleIterator findAttribute(const std::string & attrb)
    {
        std::tr1::unordered_map<std::string, uint32_t>::const_iterator it = mappings_->nameToIndex_.find(attrb);
        if ( it == mappings_->nameToIndex_.end() ) {
            return this->getEndIterator();
        }
        return TupleIterator(*this, it->second);
    }
    
    ConstTupleIterator findAttribute(const std::string & attrb) const
        { return const_cast<Self*>(this)->findAttribute(attrb); }
    
    TupleAttribute getAttribute(uint32_t index)
    {
        if (index >= num_attributes)
            invalidIndex (index, num_attributes);
        return TupleAttribute(mappings_->indexToName_[index], index, *this);
    }
    
    ConstTupleAttribute getAttribute(uint32_t index) const
        { return const_cast<Self*>(this)->getAttribute(index); }

    ValueHandle getAttributeValue(const std::string & attrb)
        { return getAttributeValueRaw(lookupAttributeName(*mappings_, attrb)->second); }


    ConstValueHandle getAttributeValue(const std::string & attrb) const
        { return const_cast<Self*>(this)->getAttributeValue(attrb); }

    ValueHandle getAttributeValue(uint32_t index) 
        { return getAttributeValueRaw(index); }

    ConstValueHandle getAttributeValue(uint32_t index) const
        { return const_cast<Self*>(this)->getAttributeValue(index); }

    Self & operator=(const Self & ot) 
    { 
        age_ = ot.age_;
        alert_ = ot.alert_;
        bpDiastolic_ = ot.bpDiastolic_;
        bpSystolic_ = ot.bpSystolic_;
        heartRate_ = ot.heartRate_;
        hrAverage_ = ot.hrAverage_;
        messages_ = ot.messages_;
        name_ = ot.name_;
        roomInfo_ = ot.roomInfo_;
        spO2_ = ot.spO2_;
        temperature_ = ot.temperature_; 
        assignPayload(ot);
        return *this; 
    }

    Self & operator=(const Tuple & ot) 
    { 
        assignFrom(ot); 
        return *this; 
    }

    void assign(Tuple const & tuple)
    {
        *this = static_cast<SELF const &>(tuple);
    }


    bool operator==(const Self & ot) const 
    {  
       return ( 
                age_ == ot.age_ && 
                alert_ == ot.alert_ && 
                bpDiastolic_ == ot.bpDiastolic_ && 
                bpSystolic_ == ot.bpSystolic_ && 
                heartRate_ == ot.heartRate_ && 
                hrAverage_ == ot.hrAverage_ && 
                messages_ == ot.messages_ && 
                name_ == ot.name_ && 
                roomInfo_ == ot.roomInfo_ && 
                spO2_ == ot.spO2_ && 
                temperature_ == ot.temperature_  
              ); 
    }
    bool operator==(const Tuple & ot) const { return equals(ot); }

    bool operator!=(const Self & ot) const { return !(*this == ot); }
    bool operator!=(const Tuple & ot) const { return !(*this == ot); }


    void swap(SELF & ot) 
    { 
        std::swap(age_, ot.age_);
        std::swap(alert_, ot.alert_);
        std::swap(bpDiastolic_, ot.bpDiastolic_);
        std::swap(bpSystolic_, ot.bpSystolic_);
        std::swap(heartRate_, ot.heartRate_);
        std::swap(hrAverage_, ot.hrAverage_);
        std::swap(messages_, ot.messages_);
        std::swap(name_, ot.name_);
        std::swap(roomInfo_, ot.roomInfo_);
        std::swap(spO2_, ot.spO2_);
        std::swap(temperature_, ot.temperature_);
      std::swap(payload_, ot.payload_);
    }

    void reset()
    { 
        *this = SELF(); 
    }

    void normalizeBoundedSetsAndMaps(); 

    const std::string & getAttributeName(uint32_t index) const
    {
        if (index >= num_attributes)
            invalidIndex (index, num_attributes);
        return mappings_->indexToName_[index];
    }

    const std::tr1::unordered_map<std::string, uint32_t> & getAttributeNames() const 
        { return mappings_->nameToIndex_; }

protected:

    ValueHandle getAttributeValueRaw(const uint32_t index)
    {
        if (index >= num_attributes)
            invalidIndex(index, num_attributes);
        const TypeOffset & t = mappings_->indexToTypeOffset_[index];
        return ValueHandle((char*)this + t.getOffset(), t.getMetaType(), &t.getTypeId());
    }

private:
    
    age_type age_;
    alert_type alert_;
    bpDiastolic_type bpDiastolic_;
    bpSystolic_type bpSystolic_;
    heartRate_type heartRate_;
    hrAverage_type hrAverage_;
    messages_type messages_;
    name_type name_;
    roomInfo_type roomInfo_;
    spO2_type spO2_;
    temperature_type temperature_;

    static TupleMappings* mappings_;
    static TupleMappings* initMappings();
};

inline VirtualByteBuffer & operator>>(VirtualByteBuffer & sbuf, SELF & tuple) 
    { tuple.deserialize(sbuf); return sbuf; }
inline VirtualByteBuffer & operator<<(VirtualByteBuffer & sbuf, SELF const & tuple) 
    { tuple.serialize(sbuf); return sbuf; }

template <class BufferType>
inline ByteBuffer<BufferType> & operator>>(ByteBuffer<BufferType> & sbuf, SELF & tuple) 
    { tuple.deserialize(sbuf); return sbuf; }
template <class BufferType>
inline ByteBuffer<BufferType> & operator<<(ByteBuffer<BufferType> & sbuf, SELF const & tuple) 
    { tuple.serialize(sbuf); return sbuf; }

inline NetworkByteBuffer & operator>>(NetworkByteBuffer & sbuf, SELF & tuple) 
    { tuple.deserialize(sbuf); return sbuf; }
inline NetworkByteBuffer & operator<<(NetworkByteBuffer & sbuf, SELF const & tuple) 
    { tuple.serialize(sbuf); return sbuf; }

inline NativeByteBuffer & operator>>(NativeByteBuffer & sbuf, SELF & tuple) 
    { tuple.deserialize(sbuf); return sbuf; }
inline NativeByteBuffer & operator<<(NativeByteBuffer & sbuf, SELF const & tuple) 
    { tuple.serialize(sbuf); return sbuf; }

template<>
inline std::ostream & serializeWithPrecision(std::ostream & ostr, SELF const & tuple) 
    { tuple.serializeWithPrecision(ostr); return ostr; }
inline std::ostream & operator<<(std::ostream & ostr, SELF const & tuple) 
    { tuple.serialize(ostr); return ostr; }
inline std::istream & operator>>(std::istream & istr, SELF & tuple) 
    { tuple.deserialize(istr); return istr; }
template<>
inline void deserializeWithSuffix(std::istream & istr, SELF  & tuple) 
{ tuple.deserialize(istr,true);  }
inline void deserializeWithNanAndInfs(std::istream & istr, SELF  & tuple, bool withSuffix = false) 
{ tuple.deserializeWithNanAndInfs(istr,withSuffix);  }



}  // namespace SPL

namespace std
{
    inline void swap(SPL::SELF & a, SPL::SELF & b)
    {
        a.swap(b);
    }
};

namespace std { 
    namespace tr1 {
        template <>
        struct hash<SPL::SELF> {
            inline size_t operator()(const SPL::SELF & self) const 
                { return self.hashCode(); }
        };
    }
}

#undef SELF
#endif // BEJWLI8EKWJAQBX_1JTRXQUFDISDAV2MHLXUIA8HYV_0VCGVM3ATIJYPCVSSQSYJPL61DSJFXUZHFJ_17N_1J5ZEU8DDAQF6_04PGKLWR3QC550WOUBK3ETTXS9N4_1ZPFA7SOOD_1EDDPMQAQ_H_ 



