// eJzNkltvokAYhsM_1Mc1etEnDsSqapgkKtB7QItqqN2TQEcYyM5QZofrrdzx2t2l2k73awM28Cc_08PN_1HslTOYQo4ogSkzaa7IQtOc0mTVPEY0pUsK_0Ll2wwqLdgtU2Q6PWvteK1pqHVr1nv9o5wUJBk3LAdPX0pdHU8wuhs0ItOe2Z7qtrrWMlQ7iV4tnV5nsja7UEej8Suahmph1NP61ixbM8OOt2rD96Jp_1bFaEt3XG8FdiefjHMLXlyAqUkPFbe6H6h2JI5doi6Hv81UyX7VrIzm5_0r5nubb8Q08_0mr5PVjYKllahe0l_1OkHAfJq9iAqLx8IzrHFnPcvaRRD4bNbN_0jVtGazd6Wb_05HZDrU4EorqDE3NpW75bEyWe415a5oa_1qFbVkm6ingE5_12ANchdq88y16sFwaIeaY9uZ92753zXMvaC27Tsx2052g16ouV4w7g52zhvvsbeMsWTQD6rDsWPyVtw2Q7Usgz1mPxZJSSiGCuM5BJiBJUZEiRE_1Bx9yAkHKE4UBnKWQKc9ivJBw5lGCxHARiW2IqSJzStM3xJmyoFhGEZa_1AGQgdmK7g3KBOEiVJeBAIpTAfYf9gqCM5vyHKgXP_1Wbzf90OCUn50ZroTMOTC4lvhJp7RLihV0AMbyPhAgJSASnM_0e0xjzIbAcZpihaXJNieglVKwT4SqnI_0Ahx_0JrlVwHwPTRHj9xthVSh_1qGDImEjZ7SmpEIDh5ZBTijtkRU83sWyoX4gc4kwQ_0SaHDwfz9Kv5f9gmCQsxhpQdhXSW0qmJuEA7gs_1BZdJyDHl4cXh9czjv_1_0L6RjqIk04aPxnn4M_0Mw8cCclYk_1Wbuk3aIf_01WefgL_0Uy8vhHefgKPB57S


#include "./Functor_5.h"
using namespace SPL::_Operator::VitalsCheck_7;

#include <SPL/Runtime/Function/SPLFunctions.h>
#include <SPL/Runtime/Operator/Port/Punctuation.h>

#include <string>

#define MY_OPERATOR_SCOPE SPL::_Operator::VitalsCheck_7
#define MY_BASE_OPERATOR Functor_5_Base
#define MY_OPERATOR Functor_5$OP




void MY_OPERATOR_SCOPE::MY_OPERATOR::process(Tuple const & tuple, uint32_t port) 
{
   IPort0Type const & iport$0 = static_cast<IPort0Type const&>(tuple);
   if (! (1) ) 
       return;
   { OPort0Type otuple(iport$0.get_o_Patient().get_name(), static_cast<SPL::boolean>(iport$0.get_o_Patient().get_alert()), iport$0.get_o_Patient().get_messages()); submit (otuple, 0);
 }
   
}

void MY_OPERATOR_SCOPE::MY_OPERATOR::process(Punctuation const & punct, uint32_t port) 
{
   forwardWindowPunctuation(punct);
}

static SPL::Operator * initer() { return new MY_OPERATOR_SCOPE::MY_OPERATOR(); }
bool MY_BASE_OPERATOR::globalInit_ = MY_BASE_OPERATOR::globalIniter();
bool MY_BASE_OPERATOR::globalIniter() {
    instantiators_.insert(std::make_pair("VitalsCheck_7::Functor_5",&initer));
    return true;
}

template<class T> static void initRTC (SPL::Operator& o, T& v, const char * n) {
    SPL::ValueHandle vh = v;
    o.getContext().getRuntimeConstantValue(vh, n);
}

MY_BASE_OPERATOR::MY_BASE_OPERATOR()
 : Operator() {
    uint32_t index = getIndex();
    (void) getParameters(); // ensure thread safety by initializing here
    $oportBitset = OPortBitsetType(std::string("01"));
}
MY_BASE_OPERATOR::~MY_BASE_OPERATOR()
{
    for (ParameterMapType::const_iterator it = paramValues_.begin(); it != paramValues_.end(); it++) {
        const ParameterValueListType& pvl = it->second;
        for (ParameterValueListType::const_iterator it2 = pvl.begin(); it2 != pvl.end(); it2++) {
            delete *it2;
        }
    }
}

void MY_BASE_OPERATOR::tupleLogic(Tuple const & tuple, uint32_t port) {
}


void MY_BASE_OPERATOR::processRaw(Tuple const & tuple, uint32_t port) {
    tupleLogic (tuple, port);
    static_cast<MY_OPERATOR_SCOPE::MY_OPERATOR*>(this)->MY_OPERATOR::process(tuple, port);
}


void MY_BASE_OPERATOR::punctLogic(Punctuation const & punct, uint32_t port) {
}

void MY_BASE_OPERATOR::punctPermitProcessRaw(Punctuation const & punct, uint32_t port) {
    {
        punctNoPermitProcessRaw(punct, port);
    }
}

void MY_BASE_OPERATOR::punctNoPermitProcessRaw(Punctuation const & punct, uint32_t port) {
    switch(punct) {
    case Punctuation::WindowMarker:
        punctLogic(punct, port);
        process(punct, port);
        break;
    case Punctuation::FinalMarker:
        punctLogic(punct, port);
        
        if (punct == Punctuation::FinalMarker) {
            process(punct, port);
            bool forward = false;
            {
                AutoPortMutex $apm($fpMutex, *this);
                $oportBitset.reset(port);
                if ($oportBitset.none()) {
                    $oportBitset.set(1);
                    forward=true;
                }
            }
            if(forward)
                submit(punct, 0);
            return;
        }
        process(punct, port);
        break;
    case Punctuation::DrainMarker:
    case Punctuation::ResetMarker:
    case Punctuation::ResumeMarker:
        break;
    case Punctuation::SwitchMarker:
        break;
    default:
        break;
    }
}

void MY_BASE_OPERATOR::processRaw(Punctuation const & punct, uint32_t port) {
    switch(port) {
    case 0:
        punctNoPermitProcessRaw(punct, port);
        break;
    }
}



void MY_BASE_OPERATOR::checkpointStateVariables(NetworkByteBuffer & opstate) const {
}

void MY_BASE_OPERATOR::restoreStateVariables(NetworkByteBuffer & opstate) {
}

void MY_BASE_OPERATOR::checkpointStateVariables(Checkpoint & ckpt) {
}

void MY_BASE_OPERATOR::resetStateVariables(Checkpoint & ckpt) {
}

void MY_BASE_OPERATOR::resetStateVariablesToInitialState() {
}

bool MY_BASE_OPERATOR::hasStateVariables() const {
    return false;
}

void MY_BASE_OPERATOR::resetToInitialStateRaw() {
    AutoMutex $apm($svMutex);
    StateHandler *sh = getContext().getStateHandler();
    if (sh != NULL) {
        sh->resetToInitialState();
    }
    resetStateVariablesToInitialState();
}

void MY_BASE_OPERATOR::checkpointRaw(Checkpoint & ckpt) {
    AutoMutex $apm($svMutex);
    StateHandler *sh = getContext().getStateHandler();
    if (sh != NULL) {
        sh->checkpoint(ckpt);
    }
    checkpointStateVariables(ckpt);
}

void MY_BASE_OPERATOR::resetRaw(Checkpoint & ckpt) {
    AutoMutex $apm($svMutex);
    StateHandler *sh = getContext().getStateHandler();
    if (sh != NULL) {
        sh->reset(ckpt);
    }
    resetStateVariables(ckpt);
}



