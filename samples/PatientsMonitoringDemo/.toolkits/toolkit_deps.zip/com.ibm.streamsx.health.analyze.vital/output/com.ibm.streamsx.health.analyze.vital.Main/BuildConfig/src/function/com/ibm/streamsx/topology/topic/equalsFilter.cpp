#include "SPL/Runtime/Function/SPLFunctions.h"
#include "./equalsFilter.h"
namespace com { namespace ibm { namespace streamsx { namespace topology { namespace topic { 
SPL::rstring equalsFilter (const SPL::rstring& name, const SPL::rstring& value)
{
    return ((((SPL::rstring("(") + name) + SPL::rstring("==")) + ::SPL::Functions::String::makeRStringLiteral(value)) + SPL::rstring(")"));
}
} } } } } 
