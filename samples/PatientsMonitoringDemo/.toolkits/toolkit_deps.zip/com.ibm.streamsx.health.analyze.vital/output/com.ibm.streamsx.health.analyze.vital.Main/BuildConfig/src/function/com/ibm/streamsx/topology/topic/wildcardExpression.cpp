#include "SPL/Runtime/Function/SPLFunctions.h"
#include "./wildcardExpression.h"
#include "../../../../../../type/BeJyrNI03TS0qyi8yKU8syjPJzEvLN01JTSpNNy0pSkxOBQC5eQu5.h"
namespace com { namespace ibm { namespace streamsx { namespace topology { namespace topic { 
SPL::rstring wildcardExpression (const SPL::rstring& exportType, const SPL::rstring& filter)
{
    ::SPL::Functions::Utility::appTrc(SPL::BeJyrNI03TS0qyi8yKU8syjPJzEvLN01JTSpNNy0pSkxOBQC5eQu5::debug, (SPL::rstring("Wildcard topic filter:") + filter), SPL::rstring("/opt/ibm/InfoSphere_Streams/4.2.0.0/toolkits/com.ibm.streamsx.topology/com.ibm.streamsx.topology.topic/topics.spl"), SPL::uint32(176U));
    const SPL::list<SPL::rstring > id$tokens = ::SPL::Functions::String::tokenize(filter, SPL::rstring("/"), (SPL::boolean)true);
    const SPL::boolean id$hasHash = (::SPL::Functions::String::findFirst(filter, SPL::rstring("#")) != SPL::int32(-1));
    SPL::rstring id$tw = ((SPL::rstring("( ( __spl_exportType ==") + ::SPL::Functions::String::makeRStringLiteral(exportType)) + SPL::rstring(" )"));
    if (SPL::boolean(!id$hasHash)) 
        {
            id$tw += ((SPL::rstring("&& ( __spl_topicLevelCount == ") + ::SPL::spl_cast<SPL::rstring, SPL::int32 >::cast(::SPL::Functions::Collections::size(id$tokens))) + SPL::rstring(" )"));
        }
    if (((filter == SPL::rstring("+")) || (filter == SPL::rstring("#")))) 
        {
            id$tw += SPL::rstring(")");
            return id$tw;
        }
    if (id$hasHash) 
        {
            id$tw += ((SPL::rstring("&& ( __spl_topicLevelCount >= ") + ::SPL::spl_cast<SPL::rstring, SPL::int32 >::cast(SPL::int32(::SPL::Functions::Collections::size(id$tokens) - SPL::int32(1)))) + SPL::rstring(" )"));
        }
    {
        SPL::int32 temp$i$l = id$tokens.size();
        for (SPL::int32 id$i = 0; id$i < temp$i$l; id$i++) {
            {
                const SPL::rstring id$level = id$tokens.at(id$i);
                if ((id$level == SPL::rstring("+"))) 
                    continue;
                if ((id$level == SPL::rstring("#"))) 
                    break;
                id$tw += SPL::rstring(" && ");
                if (id$hasHash) 
                    {
                        id$tw += SPL::rstring("( ");
                        id$tw += ((SPL::rstring("( __spl_topicLevelCount > ") + ::SPL::spl_cast<SPL::rstring, SPL::int32 >::cast(id$i)) + SPL::rstring(" )"));
                        id$tw += SPL::rstring(" && ");
                    }
                id$tw += ((((SPL::rstring("( __spl_topicLevels[") + ::SPL::spl_cast<SPL::rstring, SPL::int32 >::cast(id$i)) + SPL::rstring("] == ")) + ::SPL::Functions::String::makeRStringLiteral(id$level)) + SPL::rstring(" )"));
                if (id$hasHash) 
                    {
                        id$tw += SPL::rstring(" )");
                    }
            }
        }
    }
    id$tw += SPL::rstring(" )");
    return id$tw;
}
} } } } } 
