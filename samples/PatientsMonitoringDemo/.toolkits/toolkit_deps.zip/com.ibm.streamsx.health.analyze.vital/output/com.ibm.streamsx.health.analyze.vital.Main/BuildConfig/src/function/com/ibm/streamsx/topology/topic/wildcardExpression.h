#ifndef SPL_FUNCTION_com_ibm_streamsx_topology_topic_wildcardExpression_h
#define SPL_FUNCTION_com_ibm_streamsx_topology_topic_wildcardExpression_h

namespace com {
    namespace ibm {
        namespace streamsx {
            namespace topology {
                namespace topic {
                    SPL::rstring wildcardExpression (const SPL::rstring& exportType, const SPL::rstring& filter);
                }
            }
        }
    }
}

#endif // SPL_FUNCTION_com_ibm_streamsx_topology_topic_wildcardExpression_h
