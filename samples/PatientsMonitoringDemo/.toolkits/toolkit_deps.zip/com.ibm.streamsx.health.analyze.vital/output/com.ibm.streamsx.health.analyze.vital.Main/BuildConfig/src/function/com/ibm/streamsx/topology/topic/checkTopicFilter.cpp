#include "SPL/Runtime/Function/SPLFunctions.h"
#include "./checkTopicFilter.h"
#include "../../../../../../function/com/ibm/streamsx/topology/topic/checkNoNul.h"
namespace com { namespace ibm { namespace streamsx { namespace topology { namespace topic { 
SPL::boolean checkTopicFilter (const SPL::rstring& topic)
{
    if (SPL::boolean(!::com::ibm::streamsx::topology::topic::checkNoNul(topic))) 
        return false;
    if ((::SPL::Functions::String::findFirst(topic, SPL::rstring("#")) != SPL::int32(-1))) 
        {
            if ((topic == SPL::rstring("#"))) 
                return true;
            if ((::SPL::Functions::String::findFirst(topic, SPL::rstring("#")) != SPL::int32(::SPL::Functions::String::length(topic) - SPL::int32(1)))) 
                return false;
            if ((::SPL::Functions::String::findFirst(topic, SPL::rstring("/#")) != SPL::int32(::SPL::Functions::String::length(topic) - SPL::int32(2)))) 
                return false;
        }
    if ((::SPL::Functions::String::findFirst(topic, SPL::rstring("+")) == SPL::int32(-1))) 
        return true;
    if ((topic == SPL::rstring("+"))) 
        return true;
    const SPL::list<SPL::rstring > id$tokens = ::SPL::Functions::String::tokenize(topic, SPL::rstring("/"), (SPL::boolean)false);
    {
        for (SPL::list<SPL::rstring >::const_iterator it$token = id$tokens.begin(); it$token != id$tokens.end(); it$token++) {
            const SPL::rstring& id$token = *it$token;
            {
                if ((id$token == SPL::rstring("+"))) 
                    continue;
                if ((::SPL::Functions::String::findFirst(id$token, SPL::rstring("+")) != SPL::int32(-1))) 
                    return false;
            }
        }
    }
    return true;
}
} } } } } 
