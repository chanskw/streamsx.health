#ifndef SPL_FUNCTION_com_ibm_streamsx_topology_topic_getTopicSubscription_h
#define SPL_FUNCTION_com_ibm_streamsx_topology_topic_getTopicSubscription_h

namespace com {
    namespace ibm {
        namespace streamsx {
            namespace topology {
                namespace topic {
                    /* stateful */ SPL::rstring getTopicSubscription (const SPL::rstring& topic);
                    /* stateful */ SPL::rstring getTopicSubscription (const SPL::rstring& exportType, const SPL::rstring& topic);
                }
            }
        }
    }
}

#endif // SPL_FUNCTION_com_ibm_streamsx_topology_topic_getTopicSubscription_h
