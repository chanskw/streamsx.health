#include "SPL/Runtime/Function/SPLFunctions.h"
#include "./addUDPSubscription.h"
namespace com { namespace ibm { namespace streamsx { namespace topology { namespace topic { 
SPL::rstring addUDPSubscription (const SPL::rstring& subscription)
{
    SPL::rstring id$udpSub = (subscription + SPL::rstring(" && ( "));
    const SPL::rstring id$maxChan = ::SPL::spl_cast<SPL::rstring, SPL::int32 >::cast(::SPL::Functions::Utility::getMaxChannels());
    const SPL::rstring id$chan = ::SPL::spl_cast<SPL::rstring, SPL::int32 >::cast(::SPL::Functions::Utility::getChannel());
    id$udpSub = (id$udpSub + SPL::rstring("((__spl_maxChannels <= 1) && "));
    if ((::SPL::Functions::Utility::getChannel() == SPL::int32(0))) 
        id$udpSub = (id$udpSub + SPL::rstring("( "));
    id$udpSub = (((((id$udpSub + SPL::rstring(" ((__spl_version >= 3) && (__spl_randomId % ")) + id$maxChan) + SPL::rstring(" == ")) + id$chan) + SPL::rstring("))"));
    if ((::SPL::Functions::Utility::getChannel() == SPL::int32(0))) 
        id$udpSub = (id$udpSub + SPL::rstring(" ||  (__spl_version == 2))"));
    id$udpSub = (id$udpSub + SPL::rstring(")"));
    id$udpSub = (((((id$udpSub + SPL::rstring(" || ((__spl_maxChannels >=2) && (__spl_channel % ")) + id$maxChan) + SPL::rstring(" == ")) + id$chan) + SPL::rstring("))"));
    id$udpSub = (id$udpSub + SPL::rstring(")"));
    return id$udpSub;
}
} } } } } 
