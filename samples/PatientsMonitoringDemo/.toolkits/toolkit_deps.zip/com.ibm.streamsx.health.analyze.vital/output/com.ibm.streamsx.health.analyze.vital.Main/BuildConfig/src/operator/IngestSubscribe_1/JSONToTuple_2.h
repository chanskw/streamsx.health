// eJzNVFtzojAYHf6J4_0xDO9sBsY61zk5nsOh6AbwAtfXFiZBiBBJNggq_1foPYm7W7_07Y78JBAzvnOyXcSj8QyWsQy4xSCmO3lFSO42ezbQ8shTrKOoKRKFfHUpbIsK_0Ll6RoqLdjfUdOuVdNwt7ZWY5KhBrfDmrWx9z1jMevZ9rXhtG9UR2trpOsO9LW8LJ_0jINVBvcaMEFuGM_0tn4W2_1NdYqTvB0_1SWgqOn0Uvd2aJjYzOaqZWrjlj7bLbIvULuqZQabjDUMA_0FB1mZd7Z4utSk9v_165XRmgMDknz3LGzA5VM_1X2hl4Pmd11M8PdmgO3wi10Y2U7VyM_1G5P75Bw1X3XYMMg0szWYq_06op1e19WPq2I3xfgIGLb2DuvYk0WuPjYzVGaTTXTxtQVa3ydTdBBivRui5MzMarY5Wj2h7M0nQ41ztpjiYqw9IX1mk7qaZA8lcXQcd3_0er3Whwf72zn_0IhuP05r8zV68kNTnHrIdp09_025Crg_0CnOpeZclZUliqBzTAPwYYSVAXHmNxxKCiC8VBmIRDaaMAEcQc2YSjDihCAc6jIkic0KiEHGmeKf5KghkgEGUZlDeIg4ixQccSJhgWJGqkhcBxiwQ58mzR0azSQVYMAt576cX5U_1ceXbld9EtX0oaF4sXCYcdCmFBbaAFBTQVlU7YLw7zToI9jghmzabLUYR42mwGkDuFIx1R6Amn6cVfaClfXpa_0lz4uVJDYOSVCi89bc5C_1AlTATnT_1E6Ffa_1QI3kLKIWXn5eY3BloTyr8dW_1anQyghiRb5E9i8hF1YfbGcE5JTwv_10KEmx8FKTfLhFHpR4nsMfRx8l5F_09DCPigbx7Pf9OmFsX56jnS29dFjvui5FNEvo7Inb474gL5vVTUbtgPrIc8Qjzeq3E2dVHOpYyDuNXvEd8eFc6Ig_1MzxEBOXILouStTkJiUUI05xfsdh_1e

#include <SPL/Toolkit/JavaOp.h>


#ifndef SPL_OPER_INSTANCE_INGESTSUBSCRIBE_1_JSONTOTUPLE_2_H_
#define SPL_OPER_INSTANCE_INGESTSUBSCRIBE_1_JSONTOTUPLE_2_H_

#include <SPL/Runtime/Operator/Operator.h>
#include <SPL/Runtime/Operator/ParameterValue.h>
#include <SPL/Runtime/Operator/OperatorContext.h>
#include <SPL/Runtime/Operator/OperatorMetrics.h>
#include <SPL/Runtime/Operator/Port/AutoPortMutex.h>
#include <SPL/Runtime/Operator/State/StateHandler.h>
#include <SPL/Runtime/ProcessingElement/PE.h>
#include <SPL/Runtime/Type/SPLType.h>
#include <SPL/Runtime/Utility/CV.h>
using namespace UTILS_NAMESPACE;

#include "../../type/BeJwrMS42ykwpNjQozi8tSk4NqSxILbZISS3LTE71TAEAoHUKDp.h"
#include "../../type/BeJwrMSo2K64sLknNLTZJzk9JBQA0TgY3.h"
#include "../../type/BeJwrMSo2ykwpNjTIyU9OLMnMz_1NMAQBDZwbz.h"
#include "../../type/BeJwrMSw2NMgqzs8LLinKzEsHACrhAWr.h"
#include "../../type/BeJwrMfE0KikuMSo2K64sLknNLTZJzk9JNTQsSk1MycxLD6ksSHUzLUvMKU0tNi7NzwUAoG8RCu.h"
#include "../../type/BeJwtjFsOgzAMBK_1UPID2ApXyTS8QxRaKBDFiHSRuD4X8zs6serWwmWBes6SoWUqgnnjPifFZL8BFA6lrEqRuiX_1Hyng_1ViDjNo6UyzTeo_1pgFddtjwPKC3wSYmOa9G_0_13R7nynBVlqHxE_1atDPk.h"

#include <bitset>

#define MY_OPERATOR JSONToTuple_2$OP
#define MY_BASE_OPERATOR JSONToTuple_2_Base
#define MY_OPERATOR_SCOPE SPL::_Operator::IngestSubscribe_1

namespace SPL {
namespace _Operator {
namespace IngestSubscribe_1 {

class MY_BASE_OPERATOR : public Operator
{
public:
    
    typedef SPL::BeJwrMSw2NMgqzs8LLinKzEsHACrhAWr IPort0Type;
    typedef SPL::BeJwtjFsOgzAMBK_1UPID2ApXyTS8QxRaKBDFiHSRuD4X8zs6serWwmWBes6SoWUqgnnjPifFZL8BFA6lrEqRuiX_1Hyng_1ViDjNo6UyzTeo_1pgFddtjwPKC3wSYmOa9G_0_13R7nynBVlqHxE_1atDPk OPort0Type;
    
    MY_BASE_OPERATOR();
    
    ~MY_BASE_OPERATOR();
    
    inline void tupleLogic(Tuple const & tuple, uint32_t port);
    void processRaw(Tuple const & tuple, uint32_t port);
    
    inline void punctLogic(Punctuation const & punct, uint32_t port);
    void processRaw(Punctuation const & punct, uint32_t port);
    void punctPermitProcessRaw(Punctuation const & punct, uint32_t port);
    void punctNoPermitProcessRaw(Punctuation const & punct, uint32_t port);
    virtual void javaopInternalAction(Punctuation const & punct, uint32_t port) = 0;
    
    inline void submit(Tuple & tuple, uint32_t port)
    {
        Operator::submit(tuple, port);
    }
    inline void submit(Punctuation const & punct, uint32_t port)
    {
        Operator::submit(punct, port);
    }
    
    
    
    
    
protected:
    Mutex $svMutex;
    typedef std::bitset<2> OPortBitsetType;
    OPortBitsetType $oportBitset;
    Mutex $fpMutex;
    SPL::rstring param$className$0;
    SPL::rstring param$classLibrary$0;
    SPL::rstring param$classLibrary$1;
    void checkpointStateVariables(NetworkByteBuffer & opstate) const;
    void restoreStateVariables(NetworkByteBuffer & opstate);
    void checkpointStateVariables(Checkpoint & ckpt);
    void resetStateVariables(Checkpoint & ckpt);
    void resetStateVariablesToInitialState();
    bool hasStateVariables() const;
    void resetToInitialStateRaw();
    void checkpointRaw(Checkpoint & ckpt);
    void resetRaw(Checkpoint & ckpt);
private:
    static bool globalInit_;
    static bool globalIniter();
    ParameterMapType paramValues_;
    ParameterMapType& getParameters() { return paramValues_;}
    void addParameterValue(std::string const & param, ConstValueHandle const& value)
    {
        ParameterMapType::iterator it = paramValues_.find(param);
        if (it == paramValues_.end())
            it = paramValues_.insert (std::make_pair (param, ParameterValueListType())).first;
        it->second.push_back(&ParameterValue::create(value));
    }
    void addParameterValue(std::string const & param)
    {
        ParameterMapType::iterator it = paramValues_.find(param);
        if (it == paramValues_.end())
            it = paramValues_.insert (std::make_pair (param, ParameterValueListType())).first;
        it->second.push_back(&ParameterValue::create());
    }
};


class MY_OPERATOR : public MY_BASE_OPERATOR 
{
public:
  // constructor
  MY_OPERATOR();

  // destructor
  virtual ~MY_OPERATOR(); 

  // notify port readiness
  void allPortsReady(); 

  // notify termination
  void prepareToShutdown(); 

  // processing for source and threaded operators   
  void process(uint32_t idx);
    
  // tuple processing for mutating ports 
  void process(Tuple & tuple, uint32_t port);
    
  // tuple processing for non-mutating ports
  void process(Tuple const & tuple, uint32_t port);

  // punctuation processing
  void process(Punctuation const & punct, uint32_t port);
private:
  void setupStateHandler();

  // members
  
  /** How we invoke actions on the Java Operator implementation */
  SPL::JNI::JNIBridgeInvoker* _bi;
  
  /* The instance of the JNIBridge used to wrap the Java Operator implementation */
  jobject _bridge;

  typedef void (*FP)(SPL::JNI::JNIBridgeInvoker&, jobject, NativeByteBuffer &, uint32_t);
  FP _fp;
  
  bool hasTupleLogic;
  
  std::tr1::shared_ptr<SPL::StateHandler> _stateHandler;

public:
  virtual void javaopInternalAction(Punctuation const & punct, uint32_t port)
  {
     _bi->action(_bridge, punct, port);
  }
    
  // handle byte buffers being send as is
  virtual void processRaw(NativeByteBuffer & buffer, uint32_t port)
  {
     (*_fp)(*_bi, _bridge, buffer, port);
  }
  
  //Java operators handle byte buffers directly
  virtual bool sendRawBufferData() { return !hasTupleLogic; }

  // Requests the blocking of a consistent region permit
  virtual void blockConsistentRegionPermit() {
      _bi->blockConsistentRegionPermit(_bridge);
  }
}; 

} // namespace IngestSubscribe_1
} // namespace _Operator
} // namespace SPL

#undef MY_OPERATOR_SCOPE
#undef MY_BASE_OPERATOR
#undef MY_OPERATOR
#endif // SPL_OPER_INSTANCE_INGESTSUBSCRIBE_1_JSONTOTUPLE_2_H_

