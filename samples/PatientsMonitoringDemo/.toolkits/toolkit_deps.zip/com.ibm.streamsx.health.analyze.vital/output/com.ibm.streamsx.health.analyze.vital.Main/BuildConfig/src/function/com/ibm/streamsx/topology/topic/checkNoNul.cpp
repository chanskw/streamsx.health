#include "SPL/Runtime/Function/SPLFunctions.h"
#include "./checkNoNul.h"
namespace com { namespace ibm { namespace streamsx { namespace topology { namespace topic { 
SPL::boolean checkNoNul (const SPL::rstring& topic)
{
    return ((::SPL::Functions::String::findFirst(topic, SPL::rstring("\0", 1)) == SPL::int32(-1)) && (::SPL::Functions::String::length(topic) != SPL::int32(0)));
}
} } } } } 
