#ifndef SPL_FUNCTION_com_ibm_streamsx_topology_topic_equalsFilter_h
#define SPL_FUNCTION_com_ibm_streamsx_topology_topic_equalsFilter_h

namespace com {
    namespace ibm {
        namespace streamsx {
            namespace topology {
                namespace topic {
                    SPL::rstring equalsFilter (const SPL::rstring& name, const SPL::rstring& value);
                }
            }
        }
    }
}

#endif // SPL_FUNCTION_com_ibm_streamsx_topology_topic_equalsFilter_h
