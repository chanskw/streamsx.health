// t4t2s2ids10locationId6devices9patientIdt3s2ids10sourceTypes8deviceId13readingSourcet4I2tst2s6systems4code11readingTypeF5values3uom7reading


#include "BeJwtjFsOgzAMBK_1UPID2ApXyTS8QxRaKBDFiHSRuD4X8zs6serWwmWBes6SoWUqgnnjPifFZL8BFA6lrEqRuiX_1Hyng_1ViDjNo6UyzTeo_1pgFddtjwPKC3wSYmOa9G_0_13R7nynBVlqHxE_1atDPk.h"
#include <sstream>

#define SELF BeJwtjFsOgzAMBK_1UPID2ApXyTS8QxRaKBDFiHSRuD4X8zs6serWwmWBes6SoWUqgnnjPifFZL8BFA6lrEqRuiX_1Hyng_1ViDjNo6UyzTeo_1pgFddtjwPKC3wSYmOa9G_0_13R7nynBVlqHxE_1atDPk

using namespace SPL;

TupleMappings* SELF::mappings_ = SELF::initMappings();

static void addMapping(TupleMappings & tm, TypeOffset & offset,
                       std::string const & name, uint32_t index)
{
    tm.nameToIndex_.insert(std::make_pair(name, index)); 
    tm.indexToName_.push_back(name);
    tm.indexToTypeOffset_.push_back(offset);    
}

static Tuple * initer() { return new SELF(); }

TupleMappings* SELF::initMappings()
{
    instantiators_.insert(std::make_pair("tuple<tuple<rstring id,rstring locationId> device,rstring patientId,tuple<rstring id,rstring sourceType,rstring deviceId> readingSource,tuple<int64 ts,tuple<rstring system,rstring code> readingType,float64 value,rstring uom> reading>",&initer));
    TupleMappings * tm = new TupleMappings();
#define MY_OFFSETOF(member, base) \
    ((uintptr_t)&reinterpret_cast<Self*>(base)->member) - (uintptr_t)base
   
    // initialize the mappings 
    
    {
        std::string s("device");
        TypeOffset t(MY_OFFSETOF(device_, tm), 
                     Meta::Type::typeOf<SPL::BeJwrMSo2ykwpNjTIyU9OLMnMz_1NMAQBDZwbz >(), 
                     &typeid(SPL::BeJwrMSo2ykwpNjTIyU9OLMnMz_1NMAQBDZwbz));
        addMapping(*tm, t, s, 0);
    }
    
    {
        std::string s("patientId");
        TypeOffset t(MY_OFFSETOF(patientId_, tm), 
                     Meta::Type::typeOf<SPL::rstring >(), 
                     &typeid(SPL::rstring));
        addMapping(*tm, t, s, 1);
    }
    
    {
        std::string s("readingSource");
        TypeOffset t(MY_OFFSETOF(readingSource_, tm), 
                     Meta::Type::typeOf<SPL::BeJwrMS42ykwpNjQozi8tSk4NqSxILbZISS3LTE71TAEAoHUKDp >(), 
                     &typeid(SPL::BeJwrMS42ykwpNjQozi8tSk4NqSxILbZISS3LTE71TAEAoHUKDp));
        addMapping(*tm, t, s, 2);
    }
    
    {
        std::string s("reading");
        TypeOffset t(MY_OFFSETOF(reading_, tm), 
                     Meta::Type::typeOf<SPL::BeJwrMfE0KikuMSo2K64sLknNLTZJzk9JNTQsSk1MycxLD6ksSHUzLUvMKU0tNi7NzwUAoG8RCu >(), 
                     &typeid(SPL::BeJwrMfE0KikuMSo2K64sLknNLTZJzk9JNTQsSk1MycxLD6ksSHUzLUvMKU0tNi7NzwUAoG8RCu));
        addMapping(*tm, t, s, 3);
    }
    
    return tm;
}

void SELF::deserialize(std::istream & istr, bool withSuffix)
{
   std::string s;
   char c;

   istr >> c; if (!istr) { return; }
   if (c != '{') { istr.setstate(std::ios_base::failbit); return; }
   
   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "device") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, device_);
   else
     istr >> device_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "patientId") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, patientId_);
   else
     istr >> patientId_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "readingSource") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, readingSource_);
   else
     istr >> readingSource_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "reading") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   if (withSuffix)
     SPL::deserializeWithSuffix(istr, reading_);
   else
     istr >> reading_;
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   
   if (c != '}') { istr.setstate(std::ios_base::failbit); return; }
}

void SELF::deserializeWithNanAndInfs(std::istream & istr, bool withSuffix)
{
   std::string s;
   char c;

   istr >> c; if (!istr) { return; }
   if (c != '{') { istr.setstate(std::ios_base::failbit); return; }
   
   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "device") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, device_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "patientId") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, patientId_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "readingSource") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, readingSource_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   if (c != ',') { istr.setstate(std::ios_base::failbit); return; }

   if (!readAttributeIdentifier(istr, s)) { return; }
   if (s != "reading") { istr.setstate(std::ios_base::failbit); return; }
   istr >> c; if (!istr) { return; }
   if (c != '=') { istr.setstate(std::ios_base::failbit); return; }
   SPL::deserializeWithNanAndInfs(istr, reading_, withSuffix);
   if (!istr) { return; }  
   istr >> c; if (!istr) { return; }
   
   if (c != '}') { istr.setstate(std::ios_base::failbit); return; }
}

void SELF::serialize(std::ostream & ostr) const
{
    ostr << '{'
         << "device=" << get_device()  << ","
         << "patientId=" << get_patientId()  << ","
         << "readingSource=" << get_readingSource()  << ","
         << "reading=" << get_reading()  
         << '}';
}

void SELF::serializeWithPrecision(std::ostream & ostr) const
{
    ostr << '{';
    SPL::serializeWithPrecision(ostr << "device=", get_device()) << ",";
    SPL::serializeWithPrecision(ostr << "patientId=", get_patientId()) << ",";
    SPL::serializeWithPrecision(ostr << "readingSource=", get_readingSource()) << ",";
    SPL::serializeWithPrecision(ostr << "reading=", get_reading()) ;
    ostr << '}';
}

SELF& SELF::clear()
{
    get_device().clear();
    SPL::rstring().swap(get_patientId());
    get_readingSource().clear();
    get_reading().clear();

    return *this;
}

void SELF::normalizeBoundedSetsAndMaps()
{
    SPL::normalizeBoundedSetsAndMaps(*this);
}


