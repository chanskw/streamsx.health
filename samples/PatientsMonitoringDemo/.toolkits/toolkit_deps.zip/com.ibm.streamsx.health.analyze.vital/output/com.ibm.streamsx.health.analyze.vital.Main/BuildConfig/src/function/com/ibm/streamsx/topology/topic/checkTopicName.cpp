#include "SPL/Runtime/Function/SPLFunctions.h"
#include "./checkTopicName.h"
#include "../../../../../../function/com/ibm/streamsx/topology/topic/checkNoNul.h"
namespace com { namespace ibm { namespace streamsx { namespace topology { namespace topic { 
SPL::boolean checkTopicName (const SPL::rstring& topic)
{
    if (SPL::boolean(!::com::ibm::streamsx::topology::topic::checkNoNul(topic))) 
        return false;
    if ((::SPL::Functions::String::findFirst(topic, SPL::rstring("+")) != SPL::int32(-1))) 
        return false;
    if ((::SPL::Functions::String::findFirst(topic, SPL::rstring("#")) != SPL::int32(-1))) 
        return false;
    return true;
}
} } } } } 
