#include "SPL/Runtime/Function/SPLFunctions.h"
#include "./getTopicSubscription.h"
#include "../../../../../../type/BeJyrNI03TS0qyi8yKU8syjPJzEvLN01JTSpNNy0pSkxOBQC5eQu5.h"
#include "../../../../../../type/BeJyrNI43TS0qyi8yKU8syjPJzEvLBwBGbAc3.h"
#include "../../../../../../function/com/ibm/streamsx/topology/topic/checkTopicFilter.h"
#include "../../../../../../function/com/ibm/streamsx/topology/topic/getTopicSubscription.h"
#include "../../../../../../function/com/ibm/streamsx/topology/topic/wildcardExpression.h"
namespace com { namespace ibm { namespace streamsx { namespace topology { namespace topic { 
/* stateful */ SPL::rstring getTopicSubscription (const SPL::rstring& topic)
{
    return ::com::ibm::streamsx::topology::topic::getTopicSubscription(SPL::rstring("topic"), topic);
}
/* stateful */ SPL::rstring getTopicSubscription (const SPL::rstring& exportType, const SPL::rstring& topic)
{
    ::SPL::Functions::Utility::appTrc(SPL::BeJyrNI03TS0qyi8yKU8syjPJzEvLN01JTSpNNy0pSkxOBQC5eQu5::debug, (SPL::rstring("Topic filter:") + topic), SPL::rstring("/opt/ibm/InfoSphere_Streams/4.2.0.0/toolkits/com.ibm.streamsx.topology/com.ibm.streamsx.topology.topic/topics.spl"), SPL::uint32(150U));
    if (SPL::boolean(!::com::ibm::streamsx::topology::topic::checkTopicFilter(topic))) 
        {
            ::SPL::Functions::Utility::appLog(SPL::BeJyrNI43TS0qyi8yKU8syjPJzEvLBwBGbAc3::error, (SPL::rstring("Topic filter is invalid:") + topic), SPL::rstring("/opt/ibm/InfoSphere_Streams/4.2.0.0/toolkits/com.ibm.streamsx.topology/com.ibm.streamsx.topology.topic/topics.spl"), SPL::uint32(152U));
            ::SPL::Functions::Utility::Assert((SPL::boolean)true, (SPL::rstring("Topic filter is invalid:") + topic), SPL::rstring("/opt/ibm/InfoSphere_Streams/4.2.0.0/toolkits/com.ibm.streamsx.topology/com.ibm.streamsx.topology.topic/topics.spl"), SPL::uint32(153U));
            ::SPL::Functions::Utility::abort(SPL::rstring("/opt/ibm/InfoSphere_Streams/4.2.0.0/toolkits/com.ibm.streamsx.topology/com.ibm.streamsx.topology.topic/topics.spl"), SPL::uint32(154U));
            return (SPL::rstring("invalid topic filter:") + topic);
        }
    if (((::SPL::Functions::String::findFirst(topic, SPL::rstring("+")) != SPL::int32(-1)) || (::SPL::Functions::String::findFirst(topic, SPL::rstring("#")) != SPL::int32(-1)))) 
        {
            return ::com::ibm::streamsx::topology::topic::wildcardExpression(exportType, topic);
        }
    return ((((SPL::rstring("( __spl_exportType == ") + ::SPL::Functions::String::makeRStringLiteral(exportType)) + SPL::rstring(") && ( __spl_topic == ")) + ::SPL::Functions::String::makeRStringLiteral(topic)) + SPL::rstring(" )"));
}
} } } } } 
