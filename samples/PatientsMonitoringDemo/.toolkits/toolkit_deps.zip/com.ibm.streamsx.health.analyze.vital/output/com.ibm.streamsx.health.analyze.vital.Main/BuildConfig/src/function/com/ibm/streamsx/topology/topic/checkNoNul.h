#ifndef SPL_FUNCTION_com_ibm_streamsx_topology_topic_checkNoNul_h
#define SPL_FUNCTION_com_ibm_streamsx_topology_topic_checkNoNul_h

namespace com {
    namespace ibm {
        namespace streamsx {
            namespace topology {
                namespace topic {
                    SPL::boolean checkNoNul (const SPL::rstring& topic);
                }
            }
        }
    }
}

#endif // SPL_FUNCTION_com_ibm_streamsx_topology_topic_checkNoNul_h
