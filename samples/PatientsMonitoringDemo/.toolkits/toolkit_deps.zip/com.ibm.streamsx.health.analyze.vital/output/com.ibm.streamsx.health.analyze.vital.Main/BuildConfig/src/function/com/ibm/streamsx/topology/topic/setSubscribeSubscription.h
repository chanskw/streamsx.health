#ifndef SPL_FUNCTION_com_ibm_streamsx_topology_topic_setSubscribeSubscription_h
#define SPL_FUNCTION_com_ibm_streamsx_topology_topic_setSubscribeSubscription_h

namespace com {
    namespace ibm {
        namespace streamsx {
            namespace topology {
                namespace topic {
                    /* stateful */ SPL::int32 setSubscribeSubscription (const SPL::rstring& subscription);
                }
            }
        }
    }
}

#endif // SPL_FUNCTION_com_ibm_streamsx_topology_topic_setSubscribeSubscription_h
