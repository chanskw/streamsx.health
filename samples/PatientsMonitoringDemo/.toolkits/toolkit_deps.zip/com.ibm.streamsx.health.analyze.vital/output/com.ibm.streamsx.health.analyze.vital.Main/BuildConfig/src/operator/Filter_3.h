// eJzVVX9vojAYDt_1EWy6LJgvIZpxrliU6dDqRqcB_0_1dN00mkFWqRFhU9_1FXWbm7ncLrvLXfiHvvA_0P_1o_0FB4FaowDJAijKACgRQKBY0VXyvKqKgeqqok0wloDXy_1inl05Tv1FZE0HLCM1YfsVa2YvO_0bTY8e2T0yneao79Wadtd2uEamTgw_197LhbrXDTp5bpPF5n_1tl1Y1AvO_0OHk_11vr9mcTuqe3Zg92sugbvXqg4bxuHjK9rQ8N8td4if7iCxnwG1f76WjpWlUfW633cx0572uWxYWObWyhVtnV7XhZfIBV0xb_1Gac1XuNLtTdfsc4rkf3qWPXBssh6jaMFmnbw8So3NcyXuU4vluEdw3Mqza7c2djSqd98tx6NGuNVr0axM3ZMCH3UG_0ndAz1W2JMLVZ108zBDOrRuOV5Yrrody9PFvZDeIPOrmAZ6ifDU5rSxm0way_0bUEfC6Psrned234TXVqeV0NFqhhyOWAjJUwi5iDEK_0RJOMArEBBI6xlzAlSkOY8xZMMexOrnIJ61oExZibdODvJBQbUzEtrBU1yAaR2EUYK71ZWAwFbzHKBEsltgGDpmmCsYCnwiuSRWqVKG_0A1CRTFmaYXVOBAo0DwmkUEZxWSbueRs9aQmAJ4mEEZXaim_1XxW8A5Ou3ngGQdABIPgC2hACsGWU5Nw5A7hyArfUcB_07CED7EPCIxkp7SIRK4SCIWi_09ldYyF3DTkSbBi6e3Kkaibyoh58rZUKhweFv6m5ubllSnFdH5LbElpLiOJzyVa_1tlvQNZT_0IfTrxAlXmdXqSgenpMRVkQi03key_12UZgvEO9reBmyUH3Ed70KJ1tnteMrmqbLZHZsl8c9AeP58tYcvpTXvCnWDsekmVFQrBcGPdsF4ygUOX7pXM7govJnN0XPA0KpzjoLklSVh4UU_0G_1Y_1zeZzU9G3H_16vnf2vQc3TvGYqlvYM9wV4W9jtfGmQzV_0Rg_1c_0PvPHfCdtR86rvD8ZsR3tX_1Iz3e_0pWJJx_1gGI3ugc




#ifndef SPL_OPER_INSTANCE_FILTER_3_H_
#define SPL_OPER_INSTANCE_FILTER_3_H_

#include <SPL/Runtime/Operator/Operator.h>
#include <SPL/Runtime/Operator/ParameterValue.h>
#include <SPL/Runtime/Operator/OperatorContext.h>
#include <SPL/Runtime/Operator/OperatorMetrics.h>
#include <SPL/Runtime/Operator/Port/AutoPortMutex.h>
#include <SPL/Runtime/Operator/State/StateHandler.h>
#include <SPL/Runtime/ProcessingElement/PE.h>
#include <SPL/Runtime/Type/SPLType.h>
#include <SPL/Runtime/Utility/CV.h>
using namespace UTILS_NAMESPACE;

#include "../type/BeJwrMS42ykwpNjQozi8tSk4NqSxILbZISS3LTE71TAEAoHUKDp.h"
#include "../type/BeJwrMSo2K64sLknNLTZJzk9JBQA0TgY3.h"
#include "../type/BeJwrMSo2ykwpNjTIyU9OLMnMz_1NMAQBDZwbz.h"
#include "../type/BeJwrMfE0KikuMSo2K64sLknNLTZJzk9JNTQsSk1MycxLD6ksSHUzLUvMKU0tNi7NzwUAoG8RCu.h"
#include "../type/BeJwtjFsOgzAMBK_1UPID2ApXyTS8QxRaKBDFiHSRuD4X8zs6serWwmWBes6SoWUqgnnjPifFZL8BFA6lrEqRuiX_1Hyng_1ViDjNo6UyzTeo_1pgFddtjwPKC3wSYmOa9G_0_13R7nynBVlqHxE_1atDPk.h"
#include <SPL_JNIFunctions_com_ibm_streamsx_health_ingest_types_resolver.h>

#include <bitset>

#define MY_OPERATOR Filter_3$OP
#define MY_BASE_OPERATOR Filter_3_Base
#define MY_OPERATOR_SCOPE SPL::_Operator

namespace SPL {
namespace _Operator {

class MY_BASE_OPERATOR : public Operator
{
public:
    
    typedef SPL::BeJwtjFsOgzAMBK_1UPID2ApXyTS8QxRaKBDFiHSRuD4X8zs6serWwmWBes6SoWUqgnnjPifFZL8BFA6lrEqRuiX_1Hyng_1ViDjNo6UyzTeo_1pgFddtjwPKC3wSYmOa9G_0_13R7nynBVlqHxE_1atDPk IPort0Type;
    typedef SPL::BeJwtjFsOgzAMBK_1UPID2ApXyTS8QxRaKBDFiHSRuD4X8zs6serWwmWBes6SoWUqgnnjPifFZL8BFA6lrEqRuiX_1Hyng_1ViDjNo6UyzTeo_1pgFddtjwPKC3wSYmOa9G_0_13R7nynBVlqHxE_1atDPk OPort0Type;
    
    MY_BASE_OPERATOR();
    
    ~MY_BASE_OPERATOR();
    
    inline void tupleLogic(Tuple const & tuple, uint32_t port);
    void processRaw(Tuple const & tuple, uint32_t port);
    
    inline void punctLogic(Punctuation const & punct, uint32_t port);
    void processRaw(Punctuation const & punct, uint32_t port);
    void punctPermitProcessRaw(Punctuation const & punct, uint32_t port);
    void punctNoPermitProcessRaw(Punctuation const & punct, uint32_t port);
    
    
    
    
    
protected:
    Mutex $svMutex;
    typedef std::bitset<2> OPortBitsetType;
    OPortBitsetType $oportBitset;
    Mutex $fpMutex;
    void checkpointStateVariables(NetworkByteBuffer & opstate) const;
    void restoreStateVariables(NetworkByteBuffer & opstate);
    void checkpointStateVariables(Checkpoint & ckpt);
    void resetStateVariables(Checkpoint & ckpt);
    void resetStateVariablesToInitialState();
    bool hasStateVariables() const;
    void resetToInitialStateRaw();
    void checkpointRaw(Checkpoint & ckpt);
    void resetRaw(Checkpoint & ckpt);
private:
    static bool globalInit_;
    static bool globalIniter();
    ParameterMapType paramValues_;
    ParameterMapType& getParameters() { return paramValues_;}
    void addParameterValue(std::string const & param, ConstValueHandle const& value)
    {
        ParameterMapType::iterator it = paramValues_.find(param);
        if (it == paramValues_.end())
            it = paramValues_.insert (std::make_pair (param, ParameterValueListType())).first;
        it->second.push_back(&ParameterValue::create(value));
    }
    void addParameterValue(std::string const & param)
    {
        ParameterMapType::iterator it = paramValues_.find(param);
        if (it == paramValues_.end())
            it = paramValues_.insert (std::make_pair (param, ParameterValueListType())).first;
        it->second.push_back(&ParameterValue::create());
    }
};


class MY_OPERATOR : public MY_BASE_OPERATOR
{
public:
   MY_OPERATOR() {}
  
   void process(Tuple const & tuple, uint32_t port);
   void process(Punctuation const & punct, uint32_t port);
   
}; 

} // namespace _Operator
} // namespace SPL

#undef MY_OPERATOR_SCOPE
#undef MY_BASE_OPERATOR
#undef MY_OPERATOR
#endif // SPL_OPER_INSTANCE_FILTER_3_H_

