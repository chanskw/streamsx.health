#include "SPL/Runtime/Function/SPLFunctions.h"
#include "./setSubscribeSubscription.h"
#include "../../../../../../type/BeJyrNI43TS0qyi8yKU8syjPJzEvLBwBGbAc3.h"
#include "../../../../../../function/com/ibm/streamsx/topology/topic/addUDPSubscription.h"
namespace com { namespace ibm { namespace streamsx { namespace topology { namespace topic { 
/* stateful */ SPL::int32 setSubscribeSubscription (const SPL::rstring& subscription)
{
    SPL::rstring id$actualSub = SPL::rstring("");
    if (((::SPL::Functions::Utility::getMaxChannels() == SPL::int32(0)) || (::SPL::Functions::Utility::getMaxChannels() == SPL::int32(1)))) 
        id$actualSub = subscription;
    else
        id$actualSub = ::com::ibm::streamsx::topology::topic::addUDPSubscription(subscription);
    const SPL::int32 id$rc = ::SPL::Functions::Utility::setInputPortImportSubscription(id$actualSub, SPL::uint32(0U));
    if ((id$rc != SPL::int32(0))) 
        {
            ::SPL::Functions::Utility::appLog(SPL::BeJyrNI43TS0qyi8yKU8syjPJzEvLBwBGbAc3::error, (((SPL::rstring("Failed subscription (") + ::SPL::spl_cast<SPL::rstring, SPL::int32 >::cast(id$rc)) + SPL::rstring("):")) + id$actualSub), SPL::rstring("/opt/ibm/InfoSphere_Streams/4.2.0.0/toolkits/com.ibm.streamsx.topology/com.ibm.streamsx.topology.topic/topics.spl"), SPL::uint32(312U));
            ::SPL::Functions::Utility::Assert((SPL::boolean)(id$rc != SPL::int32(0)), (((SPL::rstring("Failed subscription (") + ::SPL::spl_cast<SPL::rstring, SPL::int32 >::cast(id$rc)) + SPL::rstring("):")) + id$actualSub), SPL::rstring("/opt/ibm/InfoSphere_Streams/4.2.0.0/toolkits/com.ibm.streamsx.topology/com.ibm.streamsx.topology.topic/topics.spl"), SPL::uint32(314U));
            ::SPL::Functions::Utility::abort(SPL::rstring("/opt/ibm/InfoSphere_Streams/4.2.0.0/toolkits/com.ibm.streamsx.topology/com.ibm.streamsx.topology.topic/topics.spl"), SPL::uint32(315U));
        }
    return id$rc;
}
} } } } } 
