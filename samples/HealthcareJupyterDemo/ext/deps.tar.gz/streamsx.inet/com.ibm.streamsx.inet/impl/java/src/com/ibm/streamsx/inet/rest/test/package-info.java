/**
 * 
 */
/**
 *
 */
package com.ibm.streamsx.inet.rest.test;
