package com.ibm.streamsx.inet.http;

public class CopyrightClass {

}
